/********************************************************************
 ************ COPYRIGHT (c) 2014 by ke0ff, Taylor, TX   *************
 *
 *  File name: cmd_fn.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  CLI Command Interpreter
 *  
 *******************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
//#include <intrins.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions

#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "srec.h"
#include "version.h"
#include "adc.h"
#include "I2C0.h"
#include "io.h"
#include "eeprom.h"
#include "tiwords_fem01.h"

//=============================================================================
// local registers

U16	device_eprom_start;					// device parameter regs
U16	device_eprom_end;
U16	device_eeprom_start;
U16	device_eeprom_end;
U16	string_addr;						// string-parse next empty address
U16 sernum;								// serial number utility register
S8	device_eprom;
S8	device_eeprom;
U8	device_type;
S8	boot_len_fixed;
U16	device_max_bootlen;
U16	device_pprog;
char device_valid;
#define MAX_PRESP_BUF 80
char bcmd_resp_buf[MAX_PRESP_BUF + 10];
char* bcmd_resp_ptr;
U32	op_freq;

// enum error message ID
enum err_enum{ no_response, no_device, target_timeout };

// enum list of command numerics
//	each enum corresponds to a command from the above list (lastcmd corresponds
//	with the last entry, 0xff)
enum cmd_enum{ ant_up,ant_dn,ant_sel,ant_stop,ant_tune,adc_tst,civ_tst,fan_cntl,log_data,mtr_cntl,mem_wr,
				pwr_off,tst_tempa,tst_temph,tstuart1,tstuart2,hib_data,timer_tst,help1,help2,vers,
				lastcmd,helpcmd };

#define	cmd_type	char	// define as char for list < 255, else define as int

//=============================================================================
// local Fn declarations

U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U16 params[ARG_MAX]);
cmd_type cmd_srch(char* string);
char do_cmd_help(U8 cmd_id);
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str);
void parse_ehex(char * sptr);
void disp_error(U8 errnum);
void disp_fail(char* buf, char* s, U16 c, U16 d);
void disp_wait_addr(char* buf);
U16 boot_se(U8* bptr, U16 start, U16 end, U16 ppaddr);
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a);
void disp_error_log(U8* lbuf, U16 len);
void do_help(void);
void disp_esc(char flag);
void set_relay(char cmd);
U32 get_civ_freq(char* sptr);

//=============================================================================
// CLI cmd processor entry point
//	Uses number of args (nargs) and arg pointer array (args[]) to lookup
//	command and execute.
//	offset is srecord offset value which is maintianed in main() and passed
//	forward to srecord functions (upload)
//=============================================================================

int x_cmdfn(U8 nargs, char* args[ARG_MAX], U16* offset){

#define	OBUF_LEN 110				// buffer length
#define	MAX_LOG_ERRS (OBUF_LEN / 4)	// max number of errors logged by verify cmd
	char	obuf[OBUF_LEN];			// gp output buffer
	char	abuf[30];				// temp string buffer
	char	bbuf[6];				// temp string buffer
	U16		params[ARG_MAX];		// holding array for numeric params
	char	c;						// char temp
//	char	d;						// char temp
	char	pc = FALSE;				// C flag (set if "C" found in args)
	char	pw = FALSE;				// W flag (set if "W" found in args)
	char	px = FALSE;				// X flag (set if "X" found in args)
	char	pm = FALSE;				// minus flag (set if <wsp>-<wsp> found in args)
	char	pv = FALSE;				// V flag (set if <wsp>V<wsp> found in args)
	char	pf = FALSE;				// F flag (set if <wsp>F<wsp> found in args)
	int		cmd_found = TRUE;		// default to true, set to false if no valid cmd identified
	char*	q;						// char temp pointer
	char*	s;						// char temp pointer
	char*	t;						// char temp pointer
	char	cmd_id;					// command enumerated id
	U8		g;						// temp
	U8		h;						// temp
	U8		i;						// temp
	U8		j;						// temp
//	U8*		ptr0;					// U8 mem pointer
	U16		k;						// U16 temp
	U16		adc_buf[8];				// adc buffer
	U16*	ip;						// U16 pointer
	U16		tadc_buf[8];			// adc buffer
	uint32_t ii;
	uint32_t jj;
	volatile uint32_t* pii;					// u32 pointer
	S32		si;
	float	fa;

	bchar = '\0';																// clear global escape
    if (nargs > 0){
		for(i = 0; i <= nargs; i++){											//upcase all args
			s = args[i];
			str_toupper(s);
		}
		t = args[0];															// point to first arg (cmd)
		cmd_id = cmd_srch(t);													// search for command
		s = args[1];															// point to 2nd arg (1st param)
		if(*s == '?'){
			if((cmd_id == help1) || (cmd_id == help2)){
				do_help();														// set to list all cmd helps
				puts0("");
				for(i = 0; i < lastcmd; i++){
					if(do_cmd_help(i)) puts0("");
				}
			}else{
				do_cmd_help(cmd_id);											// do help for cmd only
			}
		}else{
			c = parm_srch(nargs, args, "/");									// capture minus floater
			if(c){
				pm = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "V");									// capture v-flag floater
			if(c){
				pv = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "C");									// capture c-flag floater
			if(c){
				pc = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "W");									// capture w-flag floater
			if(c){
				pw = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "X");									// capture x-flag select floater
			if(c){
				px = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "F");									// capture f-flag select floater
			if(c){
				pf = TRUE;
				nargs--;
			}
			gas_gage(2);														// init gas gauge to disabled state
			switch(cmd_id){														// dispatch command
				case help1:
				case help2:														// MAIN HELP
					do_help();
					break;

				case vers:														// SW VERSION CMD
					dispSWvers();
					break;

				case timer_tst:
					puts0("Timer test (esc to exit)...");
					do{
						GPIO_PORTD_DATA_R ^= PORTD_SPR4;
						wait(100);
					}while(bchar != ESC);
					break;

				case mtr_cntl:													// meter = hi pwr setting
					if(*args[1]){
						if(*args[1] == 'P') meter_mode(METER_PEPON);
						if(*args[1] == 'A') meter_mode(METER_PEPOFF);
						if((*args[1] == '1') || (*args[1] == 'H')) meter_mode(METER_HI);
						if((*args[1] == '0') || (*args[1] == 'L')) meter_mode(METER_LO);
					}
					if((meter_mode(METER_ITG) & METER_HI)) putss("Meter = HIGH power (150W FWD/50W REF)");
					else putss("Meter = low power (15W FWD/5W REF)");
					if((meter_mode(METER_ITG) & METER_PEPON)) puts0(" (PEP)");
					else puts0(" (AVE)");
					break;

				case hib_data:
					if(pw){
						pii = &HIB_DATA_R;
						for(i=0; i<16; i++){
							while(~HIB_CTL_R & HIB_CTL_WRC);					// pause until HIBRAM is ready
							*pii++ = 0x55aaaa55 + i;
						}
					}
					pii = &HIB_DATA_R;
					for(i=0; i<16; i++){
						sprintf(obuf,"%02x: %08x", i,*pii);
						puts0(obuf);
						pii += 1;
					}
					break;

				case tst_temph:
					i = 0;														// default resolution = 0.5C
					if(*args[1]){												// 0 = 0.5, 1 = 0.25, 2 = 0.125, 3 = 0.0625
						i = (*args[1]) & 0x03;
					}
					putss("tsense heatsink:");
					disp_esc(pw);												// display "press esc to exit" if pw is true
					fa = get_temp(1, i);
					do{
						switch(i){
						default:
						case 0:
							sprintf(obuf,"%.1f C",fa);
							break;

						case 0x20:
							sprintf(obuf,"%.2f C",fa);
							break;

						case 0x40:
							sprintf(obuf,"%.3f C",fa);
							break;

						case 0x60:
							sprintf(obuf,"%.4f C",fa);
							break;
						}
						puts0(obuf);
						wait(500);
					}while(pw && (bchar != ESC));
					break;

				case tst_tempa:
					i = 0;														// default resolution = 0.5C
					if(*args[1]){												// 0 = 0.5, 1 = 0.25, 2 = 0.125, 3 = 0.0625
						i = (*args[1]) & 0x03;
					}
					k = (75 << i) + 75;											// tmeas(max) = 75 * 2^i (ms)
					i <<= 5;
					I2C_Send2(ADDR_TSENS0, PTR_CONFIG, i);
					I2C_Send1(ADDR_TSENS0, PTR_TSENSE);
					putss("tsense ambient:");
					disp_esc(pw);												// display "press esc to exit" if pw is true
					wait(k);													// wait for 1st measurement to be ready
					do{
						k = I2C_Recv2(ADDR_TSENS0);								// get temp sense data
						switch(i){
						default:
						case 0:
							sprintf(obuf,"%.1f C",temp_float(k));
							break;

						case 0x20:
							sprintf(obuf,"%.2f C",temp_float(k));
							break;

						case 0x40:
							sprintf(obuf,"%.3f C",temp_float(k));
							break;

						case 0x60:
							sprintf(obuf,"%.4f C",temp_float(k));
							break;
						}
						puts0(obuf);
						wait(500);
					}while(pw && (bchar != ESC));
					break;

				case adc_tst:													// CIV test cmd
					if(pw){
						// "W" displays peripheral properties reg
						ii = ADC0_PP_R;
						sprintf(obuf,"ADC0_PP: 0x%08x",ii);
						puts0(obuf);
					}
					if(!pc){
						// normal exec is one line (no "C")
						ip = adc_buf;
						i = adc_in(ip);
						sprintf(obuf,"#samps: %u,  S0: %u,  S1: %u,  S2: %u,  S3: %u",i,adc_buf[1],adc_buf[3],adc_buf[5],adc_buf[7]);
						puts0(obuf);
						if(px){
							// if "X", display status bits
							sprintf(obuf,"stats:     s0: %04x, s1: %04x, s2: %04x, s3: %04x",adc_buf[0],adc_buf[2],adc_buf[4],adc_buf[6]);
							puts0(obuf);
						}
					}else{
						// if "C", display milti-line (until ESC)
						do{														// display ascii version of msg
							ip = adc_buf;
							i = adc_in(ip);
							sprintf(obuf,"#samps: %u,  S0: %u,  S1: %u,  S2: %u,  S3: %u",i,adc_buf[1],adc_buf[3],adc_buf[5],adc_buf[7]);
							puts0(obuf);
							if(px){
								// if "X", display status bits
								sprintf(obuf,"stats:     s0: %04x, s1: %04x, s2: %04x, s3: %04x",adc_buf[0],adc_buf[2],adc_buf[4],adc_buf[6]);
								puts0(obuf);
							}
							waitpio(100);
						}while(bchar != ESC);
					}
					break;

				case civ_tst:													// CIV test cmd
					q = obuf;
					*q++ = CIV_PREA;											// assemble CIV message
					*q++ = CIV_PREA;
					*q++ = CIV_RADDR;											// radio addr
					*q++ = CIV_HADDR;											// cntlr addr
					c = (asc_hex(*args[1]++) << 4) | asc_hex(*args[1]); 		// cmd
					*q++ = c;
					if(*args[2] && (*args[2] != '-')){
						c = (asc_hex(*args[2]++) << 4) | asc_hex(*args[2]); 	// sub-cmd
						*q++ = c;
					}
					if(pv){														// data is frequency (VFO)
						t = args[3];											// format data, lil'endian
						s = t;
						while(*s++);											// find end of arg
						s -= 2;
						while(s >= t){
							c = asc_hex(*s--);									 // data byte
							c |= asc_hex(*s--) << 4;
							*q++ = c;
						}
					}else{
						while(*args[3]){
							c = (asc_hex(*args[3]++) << 4);						// data
							c |= asc_hex(*args[3]++);
							*q++ = c;
						}
					}
					*q++ = 0xfd;												// end of message
					puts2(obuf);												// send message
					s = obuf;
					putss("SENT: ");
					do{															// display ascii version of msg
						puthex(*s);
					}while(*s++ != CIV_EOM);
//					wait(30);
					gets2(obuf);												// get sent + rcvd
					puts0("");
					putss("RCVD: ");
					do{															// display ascii version of msg
						puthex(*s);
					}while(*s++ != CIV_EOM);
					puts0("");
					break;

				case ant_up:													// set ant up
					sprintf(obuf,"Ant UP pos = %d",get_antpos(0));				// disp pos
					puts0(obuf);
					params[0] = 0;
					get_Dargs(1, nargs, args, &params[0]);						// parse param numerics into params[] array
					if(params[0] != 0){
						si = (S32)params[0] * 10;
						set_antmatch(si);
						sprintf(obuf,"Match pos = %d",si);						// disp pos to match
						puts0(obuf);
					}
					set_ant(ANT_UP);
					break;

				case ant_dn:													// set ant down
					sprintf(obuf,"Ant DN pos = %d",get_antpos(0));				// disp pos
					puts0(obuf);
					params[0] = 0;
					get_Dargs(1, nargs, args, &params[0]);						// parse param numerics into params[] array
					if(params[0] != 0){
						si = (S32)params[0] * 10;
						set_antmatch(si);
						sprintf(obuf,"Match pos = %d",si);						// disp pos to match
						puts0(obuf);
					}
					set_ant(ANT_DN);
					break;

				case ant_stop:													// set ant stop
//					puts0("ANT STOP.");
					set_ant(ANT_OFF);
					wait(250);
					get_antpos(pv);												// clear pos to 0 if "V" opt
					sprintf(obuf,"Ant STOP pos = %d",get_antpos(0));			// disp pos
					puts0(obuf);
					break;

				case ant_tune:													// tune ant to current HF freq
					// auto-tune test loop
					//	"V" clears ant position on entry
					//	"W" displays status when ant stopped
					//	"C" runs band cal ("R" just reads eeprom) if non-0, 1st param sets start point in list.
					//		If non-0, 2nd param sets length of list or if 0, goes to end of list.  If 3rd param
					//		is non-0, sets the 1KR/F value for the tune threshold, else uses default
					//		performs an antenna tune sweep and stores freq/pos data into EEPROM table:
					//		 - puts radio into tune mode (uses alt save/restore)
					//		 - moves ant to down-limit
					//		 - sets radio to 1st freq in list
					//			- does tune
					//			- save pos to EEPROM
					//		 - repeat until list finished
					//		 - return ant to bottom stop
					//		 - restore radio config
					//	manual switches control up/dn
					params[0] = 0;
					params[1] = 0;
					params[2] = 55;
					get_Dargs(1, nargs, args, &params[0]);						// parse param numerics into params[] array
					get_antpos(pv);												// clear ant pos iff "V" param detected
					sprintf(obuf,"Current pos: %d",get_antpos(0));				// disp pos
					puts0(obuf);
					if(pc){
						if(*args[1] != 'R'){									// do cal if NOT read only
							putss("Band Cal. Moving to down stop...");
							mode_ic7k(IC7K_SAV);								// save radio status
							stack_ic7k(CIV_AUXPUSH);							// push config
							set_ant(ANT_DN);
							g = 0;
							do{
								j = adc_in(tadc_buf);							// get ADC values
								if(tadc_buf[1] > IM_LOCK) g++;					// capture motor if locked
								else g = 0;
								if(g > IM_LOCK_LIM){
									set_ant(ANT_OFF);							// stop ant
									i = ATUNE_DONE;
								}
								wait(100);										// samp rate pacing
							}while((i != ATUNE_DONE) && (bchar != ESC));		// until exit criteria met
							set_ant(ANT_OFF);
							wait(250);											// let things settle
							get_antpos(TRUE);									// clear ant pos
							puts0("DONE.");
							j = (U16)cal_table(0xff) * NEXT_FRQ;				// get end of freq list
							i = 0;												// set start of freq list
							if((params[0] != 0) && (params[1] < j)){			// user params allow limited list to be executed
								i = params[0];
								if((params[1] != 0) && (params[1] > i)) j = params[1];
							}
							while((i < j) && (bchar != ESC)){
								ii = cal_table(i);								// get freq
								sprintf(obuf,"Tune freq: %u...",ii);			// disp status msg
								putss(obuf);
								putmsg2(obuf, CIV_SFREQ, 0xff, ii);				// set radio = new freq
								h = tune_ant(ATUNE_UP,params[2]);				// do tune Fn
								if(h == ATUNE_DONE) puts0("DONE.");				// disp "DONE" or "ERR" status
								else puts0("ERR.");
								wait(500);
								// get ant pos...save to EEPROM
								si = get_antpos(0);								// get pos
								eewr(i, ii);									// write freq
								eewr(i + THIS_POS, si);							// write pos
								i += NEXT_FRQ;
							}
							stack_ic7k(CIV_AUXPULL);							// pull config
							ii = freq_ic7k();
							putmsg2(obuf, CIV_SFREQ, 0xff, ii);					// restore orig freq
							mode_ic7k(IC7K_RES);								// restore radio status
						}
						puts0("ANT-CAL EEPROM Contents:");						// display EEPROM
						j = (U16)cal_table(0xff) * NEXT_FRQ;					// get end of freq list
						if((*args[1] == 'R') && (px)){							// perform dry-lab cal
							puts0("PRESET:");									// display preset option
							for(i=0, h=0; i<j; i+=NEXT_FRQ, h++){
								si = 1000 + ((U32)(h) * 5400);					// calc faux pos
								eewr(i + THIS_POS, si);							// write pos
								eewr(i, cal_table(h));							// write freq
							}
							eewr(i + THIS_POS, MAX_ANTPOS);						// write max pos
							eewr(i, 0);											// write 0 freq
						}
						for(i=0, h=0; i<j+1; i+=2, h++){
							sprintf(obuf,"%2u: freq: %10u: pos: %5u", h,eerd(i),eerd(i + THIS_POS));
							puts0(obuf);
						}
						if(*args[1] != 'R'){									// do move if NOT read only
							putss("Return ANT to 1st tune freq location...");
							ii = eerd(0);										// get 1st freq
							if(tune_blind(ii,TCLI)){							// do blind tune
								puts0("OK");
							}else{
								puts0("Error");
							}
						}
					}else{	// not cal...
						if(*args[1] == 'B'){									// do blind tune if 'B' param
							putss("BLIND-TUNE..");
							ii = (U32)params[1] * 1000L;
							if(tune_blind(ii,TCLI)){							// do blind tune
								putss("Error");
							}else{
								putss("OK");
							}
							sprintf(obuf,"  pos = %d",get_antpos(0));			// disp pos
							puts0(obuf);
						}else{
							puts0("AUTO-TUNE..");
							do{
								process_IO(0);									// process manual switches
								j = set_ant(ANT_QRY);							// querry ant status
								if((j != ANT_OFF) || pw){						// only run display if ant running, or "W" switch enabled
									ip = adc_buf;								// set pointer for ADC buffer
									i = adc_in(ip);								// get adc data
									si = get_antpos(0);							// get pos
									k = adc_buf[3];								// get FWD pwr
									if(k == 0) k = 1;							// save from div/0
									ii = ((U32)adc_buf[5]*1000)/(U32)k;			// calc 1000R/F
									fa = (float)adc_buf[1]*3.3/4096.0;
									if(px){										// "X" selects alt display
										sprintf(obuf,"pos0: %d, Im(A): %0.2f,  1K*R/F: %u",si,fa,ii);
									}else{
										sprintf(obuf,"pos0: %d, #samps: %u,  Im: %u,  FWD: %u,  REF: %u,  Tj: %u",si,i,adc_buf[1],adc_buf[3],adc_buf[5],adc_buf[7]);
									}
									puts0(obuf);
								}
								if(pw && (j == ANT_OFF)) wait(500);				// delay depends on ant stat if W enabled
								else wait(100);
							}while(bchar != ESC);
						}
					}
					break;

				case ant_sel:													// select ant relay setting (main or aux)
					if(*args[1]){												// params (any case): "6" or "H", "V" or "U", or "R" (reset)
						set_relay(*args[1]);
/*						switch(*args[1]){
						case '6':
							GPIO_PORTA_DATA_R &= ~N6MON;						// set 6M
							break;

						case 'h':
						case 'H':
							GPIO_PORTA_DATA_R |= N6MON;							// set HF
							break;

						case 'u':
						case 'U':
							GPIO_PORTA_DATA_R &= ~NUHFON;						// set UHF
							break;

						case 'v':
						case 'V':
							GPIO_PORTA_DATA_R |= NUHFON;						// set VHF
							break;

						case 'r':
						case 'R':
							GPIO_PORTA_DATA_R |= N6MON | NUHFON;				// reset = 6M/VHF
							break;
						}*/
					}
					if(pv){														// "V" gets trapped before we get args, so test for it this way
						GPIO_PORTA_DATA_R |= NUHFON;							// set VHF
					}
					if(GPIO_PORTA_DATA_R & N6MON){								// construct HF/6M status string
						strcpy(abuf,"HF");
					}else{
						strcpy(abuf,"6M");
					}
					if(GPIO_PORTA_DATA_R & NUHFON){								// construct VHF/UHF status string
						strcpy(bbuf,"VHF");
					}else{
						strcpy(bbuf,"UHF");
					}
					sprintf(obuf,"RF Relays:  %s  %s",abuf,bbuf);				// display relay status
					puts0(obuf);
					break;

				case fan_cntl:													// fan on/off
					// Test FAN:  F ?/1/0/W to loop
					if(*args[1]){
						if(*args[1] == '0'){
							GPIO_PORTA_DATA_R &= ~FANON;						// set fan off
						}else{
							get_fanrpm(1);										// init rpm sense
							GPIO_PORTA_DATA_R |= FANON;							// set fan on
						}
					}
					if(GPIO_PORTA_DATA_R & FANON){
						putss("Fan = ON.");
						disp_esc(pw);											// display "press esc to exit" if pw is true
						do{
							ii = get_fanrpm(0);
							fa = 30.0 * (float)SYSCLK / (float)ii;
							// ii = 30 * SYSCLK / RPM
							// 1153846 = 30 * 50000000 / 1300
							sprintf(obuf,"RPM = %.0f",fa);
							puts0(obuf);
							wait(200);
						}while(pw && (bchar != ESC));
					}else{
						puts0("Fan = off");
					}
					break;

				case log_data:													// log data to com port
					// display log data:  F ?/t ms per sample (1000 default)
					// log continuous if "W" param included
					j = 0;
					k = 0;
					do{
						if(j == 0){
							puts0("SAMP#, FAN RPM, TA, TH, TJ, IM, PF, PR");	// put up banner every 50 lines
							j = 50;
						}
						j -= 1;
						k += 1;
						ii = get_fanrpm(0);
						fa = 30.0 * (float)SYSCLK / (float)ii;
						sprintf(obuf,"%u, %.0f,",k, fa);						// samp#, fan rpm
						putss(obuf);
						fa = get_temp(0, i);
						sprintf(obuf," %.4f,",fa);								// TA
						putss(obuf);
						fa = get_temp(1, i);
						sprintf(obuf," %.4f,",fa);								// TH
						putss(obuf);
						ip = adc_buf;
						i = adc_in(ip);
						//	TJ = (-75 * ((rawADC * 3.3 / 4096) - 2.7)) - 55
						fa = -75.0 * ((adc_buf[7]) * 3.3 / 4096.0);
						fa += 147.5;
						sprintf(obuf," %.4f,",fa);								// TJ
						putss(obuf);
						sprintf(obuf," %u, %u, %u",adc_buf[1],adc_buf[3],adc_buf[5]);	// IM, PF, PF as raw unsigned
						puts0(obuf);
						waitpio(1000);											// wait with process update
					}while(pw && (bchar != ESC));
					break;

				case pwr_off:													// pwr-off (sleep)
					puts0("Power-off..");
					sprintf(obuf,"HIBCTL = %08x",HIB_CTL_R);
					puts0(obuf);
					wait(10);													// give the UART time to finish
					HIB_CTL_R |= HIB_CTL_HIBREQ;								// initiate hibernate
					for(ii = 545 * 10000;ii!=0;ii--);							// delay abt 2 sec to give PS time to discharge
					sprintf(obuf,"HIBCTLx = %08x",HIB_CTL_R);
					puts0(obuf);
					wait(200);
					puts0("..failed.");											// if we get here, it didn't work
					break;

				case tstuart1:													// HOST MEM WR CMD
					// Test Uart1:  TSTU1 ?/<string>/W to loop
					ii = 1;
					putss("UART1 (CCMD) loop test.");
					disp_esc(pw);												// display "press esc to exit" if pw is true
					parse_ehex(args[1]);										// parse control chrs
					do{
						if(ii != 0){											// if string is ready,
					    	putss("Sent: ");									// display sent string..
							putsN(args[1]);										// ..with hex expanded
							puts1_dle(args[1],strlen(args[1]));					// send test string to CCMD bus
							ii = 0;												// clear string ready flag
							t = args[1];										// point to start of param string
						}
						if(gotmsgn1()){
							s = gets1(obuf);									// get recvd data
							*s = '\0';											// add EOS
							putss("Rcvd: ");									// display rcvd string
							putsN(obuf);										// display with hex expanded
						}
						if(gotchr()){
							c = getchr();
							*t++ = c;											// re-fill buffer
							if((c == '\n') || (c == '\r')){
								ii = 1;											// if EOL, set string valid
								*t = '\0';										// null term
							}
						}
					}while(pw && (bchar != ESC));								// if "W" for loop, repeat until ESC
					if(pw) puts0("");
					s = (char*)WTHE;
				    sprintf(obuf,"%x",*s);										// combine string and count
					break;

				case tstuart2:													// HOST MEM WR CMD
					// Test Uart2:  TSTU2 ?/<string>/W to loop
					if(pf){
					    sprintf(obuf,"oprfreq = %d",op_freq);					// read last operating frequency
						puts0(obuf);
					}
					ii = 1;
					putss("UART2 (CIV) loop test.");
					disp_esc(pw);												// display "press esc to exit" if pw is true
					do{
				    	putss("Sent: ");										// display sent string
					    sprintf(obuf,"%s [%u]%c",args[1],ii++,CIV_EOM);			// combine string and count
						puts0(obuf);
						puts2(obuf);
						wait(500);												// pace test
						sprintf(obuf,"xoxoxoxo");								// make sure obuf data is cleansed
//						s = gets2(obuf);										// get recvd data
						i = getmsg2(obuf);
//						*s = '\0';												// add EOS
						putss("Rcvd: ");										// display rcvd string
						putsx0(obuf, i);
					}while(pw && (bchar != ESC));								// if "W" for loop, repeat until ESC
					if(pw) puts0("");
					break;

				case mem_wr:													// HOST MEM WR CMD
					// Motor move test:  M ?/<distance to move>/W(tst1)/X(tst2)/Clear pos count/
					//				If no parms, reads current value
					params[0] = 10000;											// default move distance
					get_Dargs(1, nargs, args, &params[0]);						// parse param numerics into params[] array
					if(pm) ii = 0;
					if(pw){
						si = get_antpos(pc);									// get pos (clear if pc == true)
						set_ant(ANT_UP);
						wait(1500);
						set_ant(ANT_OFF);
						wait(1500);
						set_ant(ANT_DN);
						ant_poswait(0);
						set_ant(ANT_OFF);
						wait(500);
						si = get_antpos(0);										// get pos
						sprintf(obuf,"pos0 = %d",si);
						puts0(obuf);
						wait(10000);
						set_ant(ANT_UP);
						ant_poswait(29091*2);
						set_ant(ANT_OFF);
						wait(500);
						si = get_antpos(0);										// get pos
						sprintf(obuf,"pos29091 = %d",si);
						puts0(obuf);
						wait(10000);
						set_ant(ANT_DN);
						ant_poswait(0);
						set_ant(ANT_OFF);
						wait(500);
						si = get_antpos(0);										// get pos
						sprintf(obuf,"pos0 = %d",si);
						puts0(obuf);
						wait(10000);
						set_ant(ANT_UP);
						ant_poswait(29091*2);
						set_ant(ANT_OFF);
						wait(500);
						si = get_antpos(0);										// get pos
						sprintf(obuf,"pos29091 = %d",si);
						puts0(obuf);
						wait(10000);
						set_ant(ANT_DN);
						ant_poswait(14545*2);
						set_ant(ANT_OFF);
						wait(500);
						si = get_antpos(0);										// get pos
						sprintf(obuf,"pos14545 = %d",si);
						puts0(obuf);
						wait(10000);
						set_ant(ANT_DN);
						ant_poswait(0);
						set_ant(ANT_OFF);
						wait(500);
					}
					if(px){
						si = get_antpos(TRUE);									// get pos (clear if pc == true)
						set_ant(ANT_UP);
						wait(1500);
						set_ant(ANT_OFF);
						wait(1500);
						set_ant(ANT_DN);
						ant_poswait(0);
						set_ant(ANT_OFF);
						for(i=0;i<10;i++){
							wait(500);
							si = get_antpos(0);										// get pos
							sprintf(obuf,"cycle %d,   pos0 = %d",i,si);
							puts0(obuf);
							wait(10000);
							set_ant(ANT_UP);
							si = get_antpos(TRUE);										// get pos
							ant_poswait(params[0]);
							set_ant(ANT_OFF);
							wait(500);
							si = get_antpos(0);										// get pos
							sprintf(obuf,"cycle %d, posX = %d",i,si);
							puts0(obuf);
							wait(10000);
							set_ant(ANT_DN);
							ant_poswait(248);
							set_ant(ANT_OFF);
						}
					}
					si = get_antpos(0);											// get final pos
					sprintf(obuf,"posF0 = %d",si);
					puts0(obuf);
					ii = TIMER0_TAR_R;
					jj = TIMER0_TAPR_R;
					sprintf(obuf,"AR = %08x  PR = %08x",ii,jj);
					puts0(obuf);
					ii = TIMER0_CTL_R;
					jj = TIMER0_IMR_R;
					sprintf(obuf,"CT = %08x  IM = %08x",ii,jj);
					puts0(obuf);


/*					params[0] = 0x0000;											// pre-set addr
					params[1] = 0xFF00;											// pre-set data invalid
					get_Dargs(1, nargs, args, params);							// parse numerics
					ptr0 = dut_xdata + params[0] - RAM_START;					// set addr ptr
					if((params[1] < 0x100) && (params[0] >= RAM_START)){		// valid params detected, do write
						*ptr0 = (U8)params[1];
					}
					sprintf(obuf,"pgmr mem: %04x %02x",params[0], (U16)*ptr0 & 0xff);
					puts0(obuf);
					break;*/

				default:
				case lastcmd:													// not valid cmd
					cmd_found = FALSE;
					break;
			}
		}
    }
	if(bchar == ESC) while(gotchr()) getchr();									// if ESC, clear CLI input chrs
	return cmd_found;
}

//=============================================================================
// do_help() displays main help screen
//=============================================================================
void do_help(void){

	puts0("ke0ff HF Bridge CMD List:");
	puts0("\tPower off\tpgmr software VERSion\n");
	puts0("Syntax: <cmd> <arg1> <arg2> ... args are optional depending on cmd.");
	puts0("\t<arg> order is critical except for floaters.");
	puts0("\"?\" as first <arg> gives cmd help, \"? ?\" lists all cmd help lines. When");
	puts0("selectively entering <args>, use \"-\" for <args> that keep default value.");
	puts0("\"=\" must precede decimal values w/o spaces. Floating <args>: these non-number");
	puts0("<args> can appear anywhere in <arg> list: \"W\" = wait for operator");
	puts0("\tTSTU1 (CCMD Test UART1) (W to loop)");
	puts0("\tTSTU2 (CIV Test UART2) (W to loop)");
	puts0("\tAUp, ADn, AStop (/V), ATune (various), ASElect (/6/H/U/V)");
	puts0("\tAdc test, hibNVram test");
	puts0("\tMEter: 'A' set AVE,   'H' set meter to low (15W)");
	puts0("\t       'P' set PEP,   'L' set meter to hi (150W)");
	puts0("\tCIV test");
	puts0("\tPower off");
	puts0("\tFan on/off (W to loop)");
	puts0("\tTA: temp ambient, TH: temp heatsink (W to loop)");
	puts0("\tM: ant cycle test, TImer test (toggles PE4 @200ms period)");
	puts0("Supports baud rates of 115.2, 57.6, 38.4, 19.2, and 9.6 kb.  Press <Enter>");
	puts0("as first character after reset at the desired baud rate.");
}

//=============================================================================
// do_cmd_help() displays individual cmd help using cmd_id enum
//=============================================================================
char do_cmd_help(U8 cmd_id){

	char c = TRUE;
	
	switch(cmd_id){														// dispatch help line
		case ant_tune:													// UART1 tst CMD
			// Auto Tune:  AT ?/V/W/C/<F#start>/<F#end>/<1KR/F lim>
			puts0("Auto Tune: ?/V/W/C/<F#start>/<F#end>/<1KR/F lim>");
			puts0("\tV = clear ant pos, W = disp status while stopped");
			puts0("\tC = run cal loop (start/end/limit values apply)");
			puts0("\t\tR = reaq EEPROM cal data");
			puts0("\t\t'X R' writes test pattern to cal table");
			puts0("\tB = do blind tune to rig freq or <F#start> * 1000");
			puts0("\t(ESC) to exit.");
			break;

		case ant_stop:													// set ant stop
			puts0("Ant Stop: ?/V");
			puts0("\tV = clear ant pos after stop");
			break;

		case tstuart1:													// UART1 tst CMD
			// Test UART1:  TSTU1 ?/<string>/W: loop output of <string>
			puts0("TSTU1 (Test UART1): ?/<string>/W (loop until ESC)");
			break;

		case tstuart2:													// UART2 tst CMD
			// Test UART2:  TSTU1 ?/<string>/W: loop output of <string>
			puts0("TSTU2 (Test UART2): ?/<string>/W (loop until ESC)");
			break;

		case adc_tst:													// ADC tst CMD
			// Test ADC:  Adc test ?
			puts0("Adc test: ?");
			break;

		case mtr_cntl:													// mtr pep/ave
			// set meter to hi/low pwr, set meter to PEP/AVE
			// ?/A,P,1,0
			puts0("MEter mode (ext. DIAWA meter): ?/A,P,H,L");
			break;

		case civ_tst:													// CIV tst CMD
			// Test CIV:  CIV ?/<cmd>/<subcmd>/<data>
			puts0("CIV test: ?/<cmd>/<subcmd>/<data>/V for vfo");
			puts0("\tcntlr = $E0, radio = $70");
			break;

		case pwr_off:													// CIV tst CMD
			// Turn off power:  P ?
			puts0("Power off: ?");
			break;

		case mem_wr:													// HOST MEM WR CMD
			// pgmr Mem write:  M ?/addr/data
			//				If no parms, reads current value
			puts0("pgmr Mem write: ?/addr/data");
			break;

		default:
			c = FALSE;
			break;
	}
	return c;
}
/*
//=============================================================================
// disp_error() displays standard error messages & device off status
//=============================================================================
void disp_error(U8 errnum){

	do_red_led(LED_BLINK);
	switch(errnum){
		case no_response:
			puts0("!! ERR !! No response from DUT.");
			break;

		case no_device:
			puts0("!! ERR !! No DUT selected.");
			break;

		case target_timeout:
			puts0("!! ERR !! DUT timeout.");
			break;

		default:
			break;
	}
	if(!dut_pwr(TARGET_STAT)) puts0("DEVICE OFF");		// signal device off
}*/
/*
//=============================================================================
// disp_fail() displays pgm/read error message with params
//	this is a debug function that displays the HC11 fn comms status
//	Also, this fn sets the status LED to blink to indicate a failure was encountered
//=============================================================================
void disp_fail(char* buf, char* s, U16 c, U16 d){

	do_red_led(LED_BLINK);
	sprintf(buf,"%s Failed!! errs: %02x %02x", s, (U16)c, (U16)d);
	puts0(buf);
}*/

//=============================================================================
// disp_wait_addr() dead code
//=============================================================================
void disp_wait_addr(char* buf){

	sprintf(buf,"disp_wait_addr = dead code\n");
	puts0(buf);
}

//=============================================================================
// exec_bcmd() dead code
//=============================================================================
void exec_bcmd(char* bcmdbuf_ptr, char* obuf, U16* offset){

}

//***********************//
// bcmd functions follow //
//***********************//

//******************************//
// hosekeeping functions follow //
//******************************//


//=============================================================================
// get numeric params from command line args
//	argsrt specifies the first item to be searched and aligns argsrt with params[0]
//	for multi-arg cmds, fields must be entered in order.
//=============================================================================
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U16 params[8]){

	char*	s;
	int		var;
	U8		i;
	int		count = 0;

	if(argsrt < nargs){											// test for start in limit (abort if not)
		for(i = argsrt; i < nargs; i++){						// convert strings to values
			s = args[i];										// set pointers to array items
			switch(*s){
				case '-':										// skip if user specified default
				case '\0':										// or if arg is empty
					break;

				default:
					count += sscanf(s,"%u",&var);				// get decimal value
					params[i - argsrt] = var;
					break;

				case '$':
					s++;
					count += sscanf(s,"%x",&var);				// get hex decimal if leading "$"
					params[i - argsrt] = var;
					break;
			}
		}
	}
	return (U8)count;
}

//=============================================================================
// search for command keywords, return cmd ID if found
//	uses the cmd_list[] array which is constructed as an array of null terminated
//	strings compressed into a single string definition.  Commands are added by
//	placing the minimum required text from the command name with a '\0' terminating
//	null.  cmd_list[] is terminated by an $ff after all of the command names.
//	cmd_enum{} holds an enumerated, named list of all valid commands.  The enum
//	definition must be at the top of this file, so the commented-out version shown
//	below must be copied and pasted to the top of the file whan any changes are
//	made (commands added or deleted).
//
//	Some thought must be put into the order of command names.  Shorter matching
//	names (e.g., single chr entries) must follow longer names to allow the algortihm
//	to properly trap the shorter cmd name.
//	
//=============================================================================
cmd_type cmd_srch(char* string){
// dummy end of list, used to break out of search loop
const char end_list[] = {0xff};
// list of minimum length command words. cmd words are separated by '\0' and list terminated with 0xff
const char cmd_list[] = {"AU\0AD\0ASE\0AS\0AT\0A\0CIV\0F\0LOG\0ME\0M\0P\0TA\0TH\0TSTU1\0TSTU2\0NV\0TI\0?\0H\0VERS\0\xff"};
//enum cmd_enum{ ant_up,ant_dn,ant_stop,ant_tune,ant_sel,adc_tst,civ_tst,fan_cntl,log_data,mtr_hi,mtr_low,mtr_pep,mem_wr,pwr_off,tst_tempa,tst_temph,tstuart1,tstuart2,hib_data,timer_tst,help1,help2,vers,lastcmd,helpcmd };
//!!! make changes to cmd_enum here, move them to top of file, then un-comment !!!

	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = (char*)cmd_list;												// start at beginning of serach list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid 
			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = (char*)end_list;										// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}

//=============================================================================
// parm_srch() looks for a match of parm_str in any non-empty args[] strings
//	if found, remove the args entry from param list and return 1st chr of parm_str,
//	else return '\0'
//=============================================================================
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str){

	U8		i;								// counter temp
	char	c = '\0';						// first chr of matched parm_str (first time thru loop, there is no match)
	static char null_str[] = "";			// null string that persists

//	if(nargs > 1){
	    for(i = 1; i <= nargs; i++){							// search starting with first args[] item
			if(c){												// if(c!=null)...
				args[i] = args[i+1];							// if there was a match, move the subsequent pointers down one
			}else{
				if(strlen(parm_str) == strlen(args[i])){		// in order to match, the lengths have to be equal...
					if(strncmp(args[i], parm_str, strlen(parm_str)) == 0){ // look for match
						c = *parm_str;							// if match, capture 1st chr in matched string
						i--;									// back-up one to edit this item out of the list
					}
				}
			}
	    }
//	}
 	if(c != '\0'){
		args[ARG_MAX - 1] = null_str;							// if there was a match, the last pointer goes to null
		
	}
	return c;													// return first chr in matched string, or null if no match
}

//=============================================================================
// disp_esc() if param true, display "Press esc to exit" msg
//=============================================================================
void disp_esc(char flag){

	if(flag){
		putss("  Press <ESC> to exit.");
	}
	puts0("");
}

//=============================================================================
// convert all chrs in string to upper case
//=============================================================================
void str_toupper(char *string){

    while(*string != '\0'){
        *string++ = toupper(*string);
    }
}

//=============================================================================
// parse string for delimited arguments
//  on exit, the args[] array holds each delimited argument from the command string input:
//  args[0] holds first arg (command)
//  args[1] holds next arg
//  args[2] etc...
//  up to args[ARG_MAX]
//
//  nargs holds number of arguments collected.  i.e., nargs = 3 specifies that args[0] .. args[3]
//      all hold arguments (three total, including the command).
//=============================================================================
int parse_args(char* cmd_string, char* args[ARG_MAX]){
	int i;
	char quote_c = 0;
	static char null_string[2] = "";

    // clear args pointers
    for (i=0; i<ARG_MAX; i++){
        args[i] = null_string;
    }
    i = 0;
    do{
        if(quotespace(*cmd_string, 0)){         // process quotes until end quote or end of string
            quote_c = *cmd_string;              // close quote must = open quote
            args[i++] = ++cmd_string;               // start args with 1st char after quote
            while(!quotespace(*cmd_string,quote_c)){
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                cmd_string++;
            }
            *cmd_string++ = '\0';               // replace end quote with null
        }
        if(*cmd_string == '\0'){
            return i;                           // end of cmd string, exit
        }
        if(!whitespace(*cmd_string)){
            args[i++] = cmd_string++;			// when non-whitespace encountered, assign arg[] pointer
            if(i > ARG_MAX){
                return i;						// until all args used up
            }
            do{
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                if(whitespace(*cmd_string)){
                    *cmd_string = '\0';			// then look for next whitespace and delimit (terminate) the arg[] string
                    break;
                }
                cmd_string++;					// loop until end of cmd_string or next whitespace
            } while (1);
        }
        cmd_string++;							// loop...
    } while (1);
}

//=============================================================================
// parse_ehex() for embeded hex ($$) arguments
//  on exit, the string holds the original text with %xx replaced by a single
//	hex byte.
//=============================================================================
void parse_ehex(char * sptr){
	char* tptr;
	U8	i;

	while(*sptr){
		if((*sptr == '$') && (*(sptr+1) == '$')){
			i = asc_hex(*(sptr+2)) << 4;
			i |= asc_hex(*(sptr+3));
			*sptr++ = i;
			tptr = sptr;
			do{
				*tptr = *(tptr+3);
				tptr++;
			}while(*(tptr+2));
		}else{
			sptr++;
		}
	}
}
//=============================================================================
// test characer for whitespace
//=============================================================================
int whitespace(char c){

    switch (c){					// These are all valid whitespace:
        case '\n':          	// newline
        case '\r':          	// cr
        case '\t':          	// tab
        case 0x20:{         	// space
		case '/':				// slash is also wsp
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// test characer for quote
//=============================================================================
int quotespace(char c, char qu_c){

    if(qu_c == '\0'){
        switch (c){				// if qu_c is null, these are valid quotes:
            case '\'':          // newline
            case '\"':          // cr
            case '\t':          // tab
                return TRUE;
            }
    } else {
        if(c == qu_c){			// else, only qu_c results in a TRUE match
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// gas_gage() display up to 16 "*" chrs based on count rate.
//	Gauge appearance:
//	[****************]	all OK
//	[***.............]	errors detected
//
//	"len" cmds:
//	0: process gauge counter/display
//	1: set gauge error character = "."
//	2: disable gage counter/display (set clen = 0)
//	all others: set creset = count = len/16, display initial gauge characters
//	This calculation identifies how many bytes are in 1/16th of the total
//	byte count (len).  For count events (len == 0), this Fn decrements count, &
//	displays a gauge chr when count == 0.  count is then reloaded with creset.
//	process continues until 16 gauge chrs have been displayed.  After this,
//	any further count eventss result in no further change to the display.
//=============================================================================
U8 gas_gage(U16 len){

#define LENCMD_MAX 2		// max # of gas-gage() cmds

	static U16	creset;		// holding reg for data counter reset value
	static U16	count;		// data counter
	static U8	clen;		// gage chr counter
	static U8	gchr;		// gage chr storage
		   U8	c = 0;		// gage printed flag

	if(len <= LENCMD_MAX){
		if(!len && clen){
			if(--count == 0){ 
				putchar(gchr);					// disp gage chr
				count = creset;					// reset loop counters
				clen--;
				if(clen == 0) putchar(']');		// if end of gage, print end bracket
				c = 1;
			}
		}else{
			if(len == 1) gchr = '.';			// if error flag, change gauge chr to err mode
			if(len == 2) clen = 0;				// disable gauge
		}
	}else{
		creset = count = len >> 4;				// init count & count reset (creset) = len/16
		if(creset == 0) creset = 1;				// if overall length too short, set 1:1
		clen = 16;								// 16 gage chrs max
		gchr = '*';								// set * as gage chr
		putchar('[');							// print start bracket
		for(c = 0; c < 16; c++) putchar(' ');
		putchar(']');							// place end bracket for scale
		for(c = 0; c < 17; c++) putchar('\b');	// backspace to start of scale
		c = 1;
	}
	return c;
}

//=============================================================================
// log_error_byte() places error data into log buffer.  Log format is:
//	(device) (host) (addrH) (addrL).  Called by target verify fns to allow
//	a limited number of errors to be trapped (limit is the buffer used to
//	hold the error log).
//	returns updated pointer to next available log entry
//=============================================================================
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a){

	*lbuf++ = d;								// store device data
	*lbuf++ = h;								// store host data
	*lbuf++ = (U8)(a >> 8);						// store addr
	*lbuf++ = (U8)(a & 0xff);
	return lbuf;								// return updated pointer
}

//=============================================================================
// disp_error_log() displays errors logged into error string.  Log format is:
//	(device) (host) (addrH) (addrL)
//	Display format is:
//	nn: Dev ($xx) != $xx @$xxxx\n = 28 printed chrs
//	nn = err number (ordinal)
//	xx = data bytes
//	xxxx = error address
//=============================================================================
void disp_error_log(U8* lbuf, U16 len){

	char obuf[32];				// local buffer
	// use U16 type to simplify sprintf variable list
	U16  i;						// loop counter
	U16  d;						// device data
	U16  h;						// host data
	U16  a;						// addr

	len++;										// add 1 to end so that we can start loop at "1"
	for(i = 1; i < len; i++){					// loop from 1 to len+1 entries
		d = (U16)*lbuf++ & 0xff;				// format device data
		h = (U16)*lbuf++ & 0xff;				// format host data
		a = ((U16)*lbuf++ & 0xff) << 8;			// format addr
		a |= (U16)*lbuf++ & 0xff;
		sprintf(obuf,"%02u: Dev ($%02x) != $%02x @$%04x", i, d, h, a); // display err line
		puts0(obuf);
	}
}

//=============================================================================
// bcmd_resp_init() inits bcmd_resp_ptr
//=============================================================================
void bcmd_resp_init(void){

	bcmd_resp_ptr = bcmd_resp_buf;
	*bcmd_resp_ptr = '\0';
}

//=============================================================================
// asc_hex() converts ascii chr to 4-bit hex.  Returns 0xff if error
//=============================================================================
U8 asc_hex(S8 c){

	U8 i;

	if((c >= '0') && (c <= '9')){			// if decimal digit,
		i = (U8)(c - '0');					// subtract ASCII '0' to get hex nybble
	}else{
		if((c >= 'A') && (c <= 'F')){		// if hex digit,
			i = (U8)(c - 'A' + 0x0A);		// subtract ASCII 'A', then add 0x0A to get hex nybble
		}else{
			i = 0xff;						// if not valid hex digit, set error return
		}
	}
	return i;	
}

//=============================================================================
// temp_float() converts MCP9800 binary temp to a float (degrees C)
//=============================================================================
float temp_float(U16 k){
	U8		i;			// temp
	U8		j = 0;		// temp sign
	float	fa;			// temp float

	if(k & 0x8000){												// if negative,
		j = 1;													// preserve sign and
		k = ~k + 1;												// convert value to positive
	}
	i = k >> 8;													// get integer portion
	fa = (float)i;												// convert to float
	if(k & 0x0080) fa += 0.5;									// add fractional portion
	if(k & 0x0040) fa += 0.25;
	if(k & 0x0020) fa += 0.125;
	if(k & 0x0010) fa += 0.0625;
	if(j){														// if negative, convert
		fa *= -1;
	}
	return fa;
}

//=============================================================================
// set_relay() sets on/off status of the RF relays
//=============================================================================
void set_relay(char cmd){

	switch(cmd){
	case '6':
		GPIO_PORTA_DATA_R &= ~N6MON;						// set 6M
		break;

	case 'h':
	case 'H':
		GPIO_PORTA_DATA_R |= N6MON;							// set HF
		break;

	case 'u':
	case 'U':
		GPIO_PORTA_DATA_R &= ~NUHFON;						// set UHF
		break;

	case 'v':
	case 'V':
		GPIO_PORTA_DATA_R |= NUHFON;						// set VHF
		break;

	case 'r':
	case 'R':
		GPIO_PORTA_DATA_R |= N6MON | NUHFON;				// reset = 6M/VHF
		break;
	}
	return;
}

//=============================================================================
// Process_CIV() handles open-loop civ input data
//=============================================================================
#define	CIVLEN	32

U8 Process_CIV(U8 cmd){
	char	cbuf[CIVLEN];
	U8		chg = 0;			// change flag
	U8		i;					// temps

	if(cmd == IPL_CMD){
		// put frequency query to CIV
		i = putmsg2(cbuf, CIV_RDFREQ, CIV_NOSCMD, CIV_NOFREQ);
		if(validmsg2(cbuf, i) && (i == 11) && ((cbuf[4] == CIV_SNDFREQ) || (cbuf[4] == CIV_RDFREQ))){
			op_freq = get_civ_freq(cbuf);
			chg = 1;					// enable update of relays
		}else{
			op_freq = 1000;				// not a valid freq
			// hf relay off
			set_relay('h');
			// v/u relay off
			set_relay('v');
		}
	}
	if(gotmsg2()){
		i = getmsg2(cbuf);
		if(validmsg2(cbuf, i) && (i == 11) && (cbuf[4] == 0)){
			op_freq = get_civ_freq(cbuf);
			chg = 1;
		}
	}
	if(chg){
		// update RF relays
		if(op_freq < 100000000L){
			if(op_freq > 40000000L){
				// hf relay = on
				set_relay('6');
			}else{
				// hf relay off
				set_relay('h');
			}
		}else{
			if(op_freq > 200000000L){
				// v/u relay = on
				set_relay('u');
			}else{
				// v/u relay off
				set_relay('v');
			}
		}
	}
	return 0;
}

//=============================================================================
// get_civ_freq() converts BCD freq msg to (U32)
//=============================================================================
U32 get_civ_freq(char* sptr){
	char	c;
	U8		j;
	U32		ff;					// BCD to int temps
	U32		fact = 1L;

	for(j=5, ff=0; j<10; j++){
		c = sptr[j];
		ff += (U32)(c & 0xf) * fact;
		fact *= 10;
		c >>= 4;
		ff += (U32)(c) * fact;
		fact *= 10;
	}
	return ff;
}
