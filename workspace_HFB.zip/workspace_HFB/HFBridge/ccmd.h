/********************************************************************
 ************ COPYRIGHT (c) 2015 by ke0ff, Taylor, TX   *************
 *
 *  File name: ccmd.h
 *
 *  Module:    Control
 *
 *  Summary:
 *  CCMD Command Interpreter header
 *
 *******************************************************************/

#ifndef CCMD_H_
#define CCMD_H_

//=============================================================================
// Global defines
// LRU address-IDs
#define	BCAST_ID	'Z'
#define	ACU_ID		'A'
#define	HFB_ID		'H'
#define	UX89_ID		'U'
#define	DRX_ID		'D'
//Non-RS-485 LRUs (included here for reference)
//		KPU_ID		'K'
//		LEDU_ID		'L'
//		RPi_ID		'R'
//		iDECK_ID	'I'
//		ASW_ID		's'
//		ALEV_ID		'a'
//		TONE_ID		't'
//		CWS_ID		'c'
//		SPEAK_ID	'w'

// HFB ccmd IDs
#define	SWRESET_CCMD	'r'			// soft restart, "eset" must follow
#define	VERSION_CCMD	'V'			// send SW version
#define	ANTCNTL_CCMD	'A'			// antenna control and status (u/d/s/i) (reads pos and im)..
									// .. "T" follows is tune subcmd: antenna tune (u/d/b/a)
#define	FANCNTL_CCMD	'F'			// fan control (1/0/i)
#define	RLYCNTL_CCMD	'R'			// v/u & h/6 relay cntl (v/u/h/6/a)
#define	TEMPRD_CCMD		'T'			// read temp (h/a/j)
#define	PWROFF_CCMD		'P'			// power force-off
#define	STATUS_CCMD		'S'			// read status, detailed or basic (b/d)
#define	CIV_TELNET_CCMD	'C'			// civ telnet I/O
#define	WD_CCMD			'W'			// watchdog reset
#define	POFF_CCMD		'O'			// force power off, "FF" must follow
#define	METER_CCMD		'M'			// read/set RF meter mode

//=============================================================================
// public command fn declarations

void process_CCMD(U8 cmd);

#endif /* CCMD_H_ */
