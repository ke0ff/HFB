/*********************************************************************
 ************ COPYRIGHT (c) 2015 by ke0ff, Taylor, TX   **************
 *
 *  File name: io.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This file encapsulates the I/O drivers and high level functions
 *	for the HF Bridge SW.
 *
 *  Project scope revision history:
 *    03-22-15 jmh:  creation date
 *
 *******************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions

#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "adc.h"
#include "I2C0.h"
#include "io.h"
#include "eeprom.h"

//=============================================================================
// local registers
char	civbuf[100];					// civ I/O buffer
U16		tadc_buf[8];					// adc buffer
U8		icsave_meter;					// saved RF meter mode
U8		icsave_mode;					// saved IC7K modulation mode
U16		icsave_pwr;						// saved IC7K tx power setting
U32		icsave_freq;					// saved IC7K operating frequency

//=============================================================================
// local Fn declarations


//=============================================================================
// meter_mode() sets/itgs the meter mode (hi/lo and pephi/peplo
//=============================================================================
U8 meter_mode(U8 mtrcmd){
	U8	i;			// temp return

	switch(mtrcmd){
		case METER_PEPON:										// meter = hi pwr setting
			GPIO_PORTB_DATA_R |= PEPM;
			break;

		case METER_PEPOFF:										// meter = hi pwr setting
			GPIO_PORTB_DATA_R &= ~PEPM;
			break;

		case METER_HI:											// meter = hi pwr setting
			GPIO_PORTD_DATA_R &= ~LOWRG;
			break;

		case METER_LO:											// meter = low pwr setting
			GPIO_PORTD_DATA_R |= LOWRG;
			break;
	}
	// capture state of meter settings
	if(GPIO_PORTB_DATA_R & PEPM) i = METER_PEPON;
	else i = 0;
	if(GPIO_PORTD_DATA_R & LOWRG) i |= METER_LO;
	else i |= METER_HI;
	return i;
 }

//-----------------------------------------------------------------------------
// set_ant() sets ant to move up, dn, or off
//	does motor reversal to effect stop.
//-----------------------------------------------------------------------------
U8 set_ant(U8 cmd){
	U8	i = cmd;			// temp return

	switch(cmd){
	default:
	case ANT_OFF:
		if((GPIO_PORTA_DATA_R & ANTON) == ANTON){				// don't stop if already stopped
			mot_stop = NANTDN;									// set stop flag (feeds timer int)
			GPIO_PORTA_DATA_R = GPIO_PORTA_DATA_R ^ NANTDN;		// reverse motor
//			wait(STOP_TIME);									// wait stop time
			antstop_timer = STOP_TIME;							// set stop timer
			while(antstop_timer);								// wait here until done (timer intr stops motor)
//			GPIO_PORTA_DATA_R &= ~ANTON;						// turn off motor
//			mot_stop = 0;										// clear stop flag
			antposhib = antpos;									// update HIBRAM storage
			antaccumhib = antaccum;
		}
		break;

	case ANT_DN:
		GPIO_PORTF_DATA_R &= ~ANT_STOP;							// turn off stop GPIO
		GPIO_PORTA_DATA_R |= NANTDN;							// set down direction
		wait(20);												// wait for relay to settle
		GPIO_PORTA_DATA_R |= ANTON;								// turn on motor
		break;

	case ANT_UP:
		GPIO_PORTF_DATA_R &= ~ANT_STOP;							// turn off stop GPIO
		GPIO_PORTA_DATA_R &= ~NANTDN;							// set up direction
		wait(20);												// wait for relay to settle
		GPIO_PORTA_DATA_R |= ANTON;								// turn on motor
		break;

	case ANT_QRY:
		if(!(GPIO_PORTA_DATA_R & ANTON)){
			i = ANT_OFF;										// ant off
		}else{
			if(GPIO_PORTA_DATA_R & NANTDN){
				i = ANT_UP;										// ant up
			}else{
				i = ANT_DN;										// ant dn
			}
		}
		break;
	}
	return i;
}

//-----------------------------------------------------------------------------
// ant_poswait() waits until and position = specified value
//-----------------------------------------------------------------------------
void ant_poswait(S32 pos)
{
	S32 postemp;		// temp var

	if(GPIO_PORTA_DATA_R & ANTON){								// only enter loop if ant motor is on
		if(GPIO_PORTA_DATA_R & NANTDN){							// if UP
			postemp = pos - SKID_UP;							// set trap pos to be less than target
			while(antpos > postemp);							// wait for target position..
		}else{													// if DN
			postemp = pos + SKID_DN;							// set trap pos to be greater than target
			while(antpos < postemp);							// wait for target position..
		}
	}
}

//-----------------------------------------------------------------------------
// tune_ant() performs an auto-tune of the antenna
//	capture IC-7000 pwr/mode/frq settings
//	capture RF meter settings
//	set IC-7000 to RTTY, 15% pwr
//	set RF meter to LOWRG, no PEP
//	compare antpos to IC-7K freq
//	determine tune direction from antpos & freqpos
//	set timeout
//	key tx (use CIV cmd)
//	measure PR (PRsave = PRlim = PR)
//	start ant move
//		loop{
//			measure PR
//			if PR < PRlim, PR lim = PR
//			if PR > PRsave + deadband, reverse ant dir
//			if PR < low limit, exit loop
//			if timeout, exit loop
//		}
//	stop ant
//	TX = off
//	restore RF PWR and IC-7K settings
//		NOTES: 2:1 SWR is about 10% reflected power
//
//-----------------------------------------------------------------------------
#define	POS_DEADBAND 2000		// @approx 122.7u-in per step, 2000 steps = 0.24 in

U8 tune_ant(U8 tunecmd, U16 pwr_thresh){
	char	cbuf[15];			// temp buffer for BCD conv
	U8		dir;				// direction
	U8		i = 0xff;			// temp rtrn
	U8		im;					// motor current counter
	U8		pm;					// R/F counter
	U8		prt;				// port temp
	U8		firstpass = FALSE;	// first pass flag
	U8		pctr;				// pwr thresh counter
	U16		k;					// temp
	U16		p;					// temp
	U16		pt;					// temp
	U32		ii;					// temp
//	S32		post;				// target pos
	S32		posc;				// current pos
	U32		fop;				// fop
	S32		fpos;				// freq(pos)
//	U32		delp;				// delta pos
	S32		poslow = MAX_ANTPOS; // lower (freq) band pos
	S32		posup = 0;			// upper (freq) band pos
	U32		pmem;				// low reflpwr reg
	U32		lmem;				// low reflpwr pos reg

	bchar = 0;													// pre-clear escape flag
	fop = getfreq_ic7k(civbuf, cbuf);							// read fop
	// if freq is out-of-range or screw-driver is not selected, err
	if((hfant_sel(0) == '6') || fop > eerd(0)){
		i = ATUNE_ERR;
	// do tune operation...
	}else{
		dir = tunecmd;
		// pt = power-ratio threshold (0 input sets default)
		if(pwr_thresh == 0) pt = MINPWR_STOP;
		else pt = pwr_thresh;
		if(dir == ATUNE_AUTO){
			//determine tune direction, set i = ATUNE_UP or ATUNE_DN.
			posc = get_antpos(0);								// get current pos
			fpos = f_pos(posc);									// calc f(pos)
//			post = pos_f(fop);									// calc target pos
			if(fpos > fop){
				dir = ATUNE_DN;									// set to tune down
//				delp = posc - post;								// calc delta position
			}else{
				dir = ATUNE_UP;									// set to tune up
//				delp = post - posc;								// calc delta position
			}
			poslow = poslower(fop) + POS_DEADBAND;
			posup = posupper(fop) - POS_DEADBAND;
			if((posc > poslow) && (posc < posup)){				// new freq is out-of-band
				if(dir == ATUNE_UP){
					// move pos to posup
					set_ant(ANT_UP);
					do{
						adc_in(tadc_buf);						// get raw ADC values
						if(tadc_buf[1] > IM_LOCK) im++;			// capture motor if locked
						else im = 0;
						if(im > IM_LOCK_LIM){
							set_ant(ANT_OFF);					// stop ant
							i = ATUNE_ERR;						// set error
						}
					}while((antpos > poslow) && (i != ATUNE_ERR));	// wait for trap to spring
				}else{
					// move pos to poslow
					set_ant(ANT_DN);
					do{
						adc_in(tadc_buf);						// get ADC values
						if(tadc_buf[1] > IM_LOCK) im++;			// capture motor if locked
						else im = 0;
						if(im > IM_LOCK_LIM){
							set_ant(ANT_OFF);					// stop ant
							i = ATUNE_ERR;						// set error
						}
					}while((antpos < posup) && (i != ATUNE_ERR));	// wait for trap to spring
				}
				set_ant(ANT_OFF);
				wait(ANT_SETTLE);
			}
		}
		if(i != ATUNE_ERR){
			mode_ic7k(IC7K_SAV);								// save IC7K, update mode/pwr
			do{
				ptt_ic7k(IC7K_PTT1);							// key radio
				ic7ktimer = MINPWR_WAIT;						// set wait timeout
				do{
					adc_in(tadc_buf);							// get ADC values
					p = tadc_buf[3];							// get fwd pwr
				}while((ic7ktimer) && (p < MINPWR_FWD));		// until timer expires or pwr > limit
				if(ic7ktimer){									// if timer != 0, pwr is OK
					switch(dir){
					case ATUNE_UP:								// start ant moving up
						set_ant(ANT_UP);
						break;

					case ATUNE_DN:								// start ant moving down
						set_ant(ANT_DN);
						break;
					}
					pmem = RPWR_MAX;							// init dip-detect regs
					lmem = 0;
					pctr = 0;
					do{											// main tune loop...
						adc_in(tadc_buf);						// get ADC values
						if(tadc_buf[1] > IM_LOCK) im++;			// capture motor if locked
						else im = 0;
						if(im > IM_LOCK_LIM){
							ptt_ic7k(IC7K_PTT0);				// unkey radio
							set_ant(ANT_OFF);					// stop ant
							i = ATUNE_ERR;						// set error
						}
//test patch
						sprintf(civbuf,"im = %u  ",tadc_buf[1]);
						putss(civbuf);
//
						k = tadc_buf[3];						// get FWD pwr
						if(k == 0) k = 1;						// save from div/0
						ii = ((U32)tadc_buf[5]*1000)/(U32)k;	// calc 1000R/F

						//if(ii < (U32)pt) pm ++;
						//else pm = 0;

						if((ii < pmem) && (ii < (U32)pt)){
							pctr = 0;							// new min, set regs
							pmem = ii;
							lmem = antpos;
						}
						if(ii > (pmem + MIN_HYST)){				// look for other side of dip (increment counter until it reaches limit)
							pctr++;
						}
						if(pm > MINPWR_CNT_LIM){
							set_ant(ANT_OFF);					// stop ant
							i = ATUNE_DONE;						// set OK
						}
						if(dir == ATUNE_UP){
							if(antpos > poslow){				// if position crosses band edge
								if(firstpass){
									firstpass = FALSE;			// set second pass
									dir = ATUNE_DN;				// change direction flag
									set_ant(ANT_OFF);			// stop ant
									wait(ANT_SETTLE);			// pause
									set_ant(ANT_DN);			// change direction
								}else{
									i = ATUNE_ERR;
								}
							}
						}
						if(dir == ATUNE_DN){
							if(antpos < posup){					// if position crosses band edge
								if(firstpass){
									firstpass = FALSE;			// set second pass
									dir = ATUNE_UP;				// change direction flag
									set_ant(ANT_OFF);			// stop ant
									wait(ANT_SETTLE);			// pause
									set_ant(ANT_UP);			// change direction
								}else{
									i = ATUNE_ERR;
								}
							}
						}
//test patch
						sprintf(civbuf,"R/F = %u",ii);
						puts0(civbuf);
//
						wait(50);								// pace at 50ms/samp
						prt = (~GPIO_PORTD_DATA_R & (NMANTA | NMANTB)) >> 1; // get man port
						if(prt == MANDN){
							i = ATUNE_ERR;
							set_ant(ANT_OFF);					// stop ant
							ptt_ic7k(IC7K_PTT0);				// unkey radio
							do{									// wait for man input to go away
								prt = (~GPIO_PORTD_DATA_R & (NMANTA | NMANTB)) >> 1; // get man port
							}while(prt == MANDN);
						}
						if(prt == MANUP){
							i = ATUNE_DONE;
							set_ant(ANT_OFF);					// stop ant
							ptt_ic7k(IC7K_PTT0);				// unkey radio
							do{									// wait for man input to go away
								prt = (~GPIO_PORTD_DATA_R & (NMANTA | NMANTB)) >> 1; // get man port
							}while(prt == MANUP);
						}
						if(pctr > PCT_MAX){						// if dip detected as passed...
							i = ATUNE_DONE;
							set_ant(ANT_OFF);					// stop ant
							ptt_ic7k(IC7K_PTT0);				// unkey radio
						}
					}while((i != ATUNE_ERR) && (i != ATUNE_DONE) && (bchar != ESC));	// until exit criteria met
				}else{
					i = ATUNE_ERR;
				}
				if(bchar == ESC) i = ATUNE_ERR;
				ptt_ic7k(IC7K_PTT0);							// unkey radio
			}while((i != ATUNE_DONE) && (i != ATUNE_ERR) && (bchar != ESC));
			set_ant(ANT_OFF);									// stop ant (failsafe)
			mode_ic7k(IC7K_RES);								// restore IC7K
		}
	}
	if(pctr <= PCT_MAX){
		lmem = antpos;											// if no dip determined, use current position
	}
	if(i != ATUNE_ERR){
		wrwhib_ram(fop,&last_tunef);
//		while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
//		last_tunef = fop;
		wrwhib_ram(lmem,&last_tunep);							// save last values
//		while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
//		last_tunep = antpos;
	}else{
		wrwhib_ram(0,&last_tunef);
//		while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
//		last_tunef = 0;											// set "not tuned" values
		wrwhib_ram(ANT_MATCH_DISABLE,&last_tunep);				// save "not tuned" values
//		while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
//		last_tunep = 0;
	}
	return i;
}

//-----------------------------------------------------------------------------
// tune_blind() moves ant w/o TX using radio fop and cal table interpolation
//	force_freq allows radio setting to be overridden (is 0 otherwise)
//	origin = CLI or switches (if CLI, ignore switch settings)
//-----------------------------------------------------------------------------
U8 tune_blind(U32 force_freq, U8 origin){
	char	cbuf[15];			// temp buffer for BCD conv
	U8		dir;				// direction
	U8		i = ATUNE_DONE;		// temp rtrn
	volatile U8		im;			// motor current counter
	S32		post;				// target pos
	S32		posc;				// current pos
	U32		fop;				// fop
	S32		fpos;				// freq(pos)

	bchar = 0;													// pre-clear escape flag
	if(force_freq){
		fop = force_freq;
	}else{
		fop = getfreq_ic7k(civbuf, cbuf);						// read fop
	}
	if((hfant_sel(0) == '6') || fop > eerd(0)){					// if 6M relay or fop > max cal freq, set error
		i = ATUNE_ERR;
	}else{
		//determine tune direction, set i = ATUNE_UP or ATUNE_DN.
		posc = get_antpos(0);									// get current pos
		fpos = f_pos(posc);										// calc f(pos)
		post = pos_f(fop);										// calc target pos
		if(fpos > fop){											// if fpos > fop, need to muve ant down
			dir = ATUNE_UP;										// set to tune down
		}else{
			dir = ATUNE_DN;										// set to tune up
		}
		im = 0;
		if(dir == ATUNE_UP){
			post -= SKID_UP;									// account for braking distance
			if(post <= antpos){

			}else{
				// move pos to posup
				set_antmatch(post);
				set_ant(ANT_UP);								// move up...
				do{
					adc_in(tadc_buf);							// get ADC values
					if(tadc_buf[1] > IM_LOCK) im++;				// capture motor if locked
					else im = 0;
					if(im > IM_LOCK_LIM){
						set_ant(ANT_OFF);						// stop ant
						i = ATUNE_ERR;							// set error
					}
					wait(50);
					if((GPIO_PORTE_DATA_R & NSPARE) && (origin == TSWITCH)){ // if spare switch deactivated,
						i = ATUNE_ERR;							// abort
					}
				}while((GPIO_PORTA_DATA_R & ANTON) && (i != ATUNE_ERR) && (bchar != ESC));		// ...until pos = target
			}
		}else{
			post += SKID_UP;									// account for braking distance
			if(post >= antpos){

			}else{
				// move pos to poslow
				set_antmatch(post);
				set_ant(ANT_DN);								// move dn...
				do{
					adc_in(tadc_buf);							// get ADC values
					if(tadc_buf[1] > IM_LOCK) im++;				// capture motor if locked
					else im = 0;
					if(im > IM_LOCK_LIM){
						set_ant(ANT_OFF);						// stop ant
						i = ATUNE_ERR;							// set error
					}
					wait(50);
					if((GPIO_PORTE_DATA_R & NSPARE) && (origin == TSWITCH)){ // if spare switch deactivated,
						i = ATUNE_ERR;							// abort
					}
				}while((GPIO_PORTA_DATA_R & ANTON) && (i != ATUNE_ERR) && (bchar != ESC));		// ...until pos = target
			}
		}
		set_ant(ANT_OFF);										// stop motion
		wait(ANT_SETTLE);										// let ant settle
	}
	return i;
}

//-----------------------------------------------------------------------------
// mode_ic7k() performs a save or restore of the ic7k mode
//	ipl clears saved settings.
//	if restore requested with no save, abort
//	after save, radio is set to RTTY (keys radio with no modulation using CIV TX),
//		sets meter to LOW and AVE, and sets RF power to 15%
//-----------------------------------------------------------------------------
U8 mode_ic7k(U8 opcode){
	U8		i = 0;				// temp return
	char*	mptr = civbuf;		// temp ptr
	char	cbuf[15];			// temp buffer for BCD conv
	U8		j;					// msg reply length

	switch(opcode){
	default:
	case IC7K_IPL:
		icsave_mode = 0;				// initialize to not-set defaults
		icsave_pwr = 0;
		icsave_freq = 0;
		break;

	case IC7K_SAV:
		// get meter mode & set to low, no PEP:
		icsave_meter = meter_mode(METER_ITG);
		meter_mode(METER_PEPOFF);
		meter_mode(METER_LO);
		// get IC7K mode:
		cleanmsg2();
		j = putmsg2(civbuf, CIV_RMODE, 0xff, 0xffff);
		//       0 1 2 3 4 5 6 7
		// RCVD: FEFEE070040102FD
		if(validmsg2(mptr, j)){
			icsave_mode = *(mptr+5);
		}else{
			i = IC7K_ERR;
		}
		// get ic7k power
		cleanmsg2();
		j = putmsg2(civbuf, CIV_PWRC, CIV_PWRSC, 0xffff);
		//       0 1 2 3 4 5 6 7 8
		// RCVD: FEFEE070140A0033FD
		if(validmsg2(mptr, j)){
			icsave_pwr = ((U16)(*(mptr+6)) << 8) | (U16)*(mptr+7);
		}else{
			i = IC7K_ERR;
		}
		// get ic7k freq
		icsave_freq = getfreq_ic7k(mptr, cbuf);
		if(!icsave_freq){
			i = IC7K_ERR;
		}
		// set IC7K mode = RTTY:
		cleanmsg2();
		j = putmsg2(civbuf, CIV_SMODE, CIV_MODE_RTTY, 0xffff);
		if(!validmsg2(mptr, j)){
			i = IC7K_ERR;
		}
		// set IC7K pwr = 33 (12%):
		cleanmsg2();
		j = putmsg2(civbuf, CIV_PWRC, CIV_PWRSC, 0x0038);
		if(!validmsg2(mptr, j)){
			i = IC7K_ERR;
		}
		break;

	case IC7K_RES:
		if(icsave_freq == 0){
			i = IC7K_ERR;
		}else{
			// restore meter mode:
			meter_mode(icsave_meter & METER_PEPON);
			meter_mode(icsave_meter & METER_HI);
			// restore IC7K mode:
			cleanmsg2();
			j = putmsg2(civbuf, CIV_SMODE, icsave_mode, 0xffff);
			// restore IC7K pwr:
//			sprintf(civbuf,"p %u",icsave_pwr);
//			puts0(civbuf);
			cleanmsg2();
			j = putmsg2(civbuf, CIV_PWRC, CIV_PWRSC, icsave_pwr);
			icsave_meter = 0;
			icsave_mode = 0;
			icsave_pwr = 0;
			icsave_freq = 0;
		}
		break;
	}
	return i;
}

//-----------------------------------------------------------------------------
// getfreq_ic7k() reads the current opr freq of the ic7k
//-----------------------------------------------------------------------------
U32 getfreq_ic7k(char* mptr, char* cbuf){
	U32	ii = 0;			// temp
	U8	j;				// msg len

	cleanmsg2();
	// get ic7k freq
	j = putmsg2(civbuf, CIV_RFREQ, 0xff, 0xffff);
	//       0 1 2 3 4  5 6 7 8 9  0
	// RCVD: FEFEE07003 7043011400 FD
	if(validmsg2(civbuf, j)){
		sprintf(cbuf,"%02x%02x%02x%02x%02x",*(civbuf+9),*(civbuf+8),*(civbuf+7),*(civbuf+6),*(civbuf+5));
		sscanf(cbuf,"%u",&ii);
	}
	return ii;
}

//-----------------------------------------------------------------------------
// stack_ic7k() stacks or pulls last saved IC7K status (only one stack
//	layer supported).  This is mainly to support the CAL funtion where the
//	radio freq is changed during the several tune steps.
//-----------------------------------------------------------------------------
void stack_ic7k(U8 stackcmd){
	static	U8		meter;		// aux stacking regs for IC7K status
	static	U8		mode;
	static	U16		pwr;
	static	U32		freq;

	switch(stackcmd){
	case CIV_AUXPUSH:									// push saved to local stack
		meter = icsave_meter;
		mode = icsave_mode;
		pwr = icsave_pwr;
		freq = icsave_freq;
		break;

	case CIV_AUXPULL:									// pull saved from local stack
		icsave_meter = meter;
		icsave_mode = mode;
		icsave_pwr = pwr;
		icsave_freq = freq;
		break;

	default:
	case CIV_AUXIPL:									// init aux stack (clear)
		meter = 0;
		mode = 0;
		pwr = 0;
		freq = 0;
		break;
	}
}

//-----------------------------------------------------------------------------
// freq_ic7k() returns last saved IC7K freq
//-----------------------------------------------------------------------------
U32 freq_ic7k(void){

	return icsave_freq;
}

//-----------------------------------------------------------------------------
// ptt_ic7k() sets or itgs ic7k ptt
//-----------------------------------------------------------------------------
U8 ptt_ic7k(U8 opcode){
	U16		i;					// temp
	char*	mptr = civbuf;		// temp ptr
	U8		j; 					// msg len

	cleanmsg2();
	// construct CIV operand
	i = 0xff00 | opcode;
	// get IC7K mode:
	j = putmsg2(civbuf, CIV_TRC, CIV_TRSC, i);
	//       0 1 2 3 4 5 6 7
	// RCVD: FEFEE0701C000pFD
	if(validmsg2(mptr, j)){
		i = (U16)*(mptr+6);
	}
	return (U8)i;
}

//-----------------------------------------------------------------------------
// f_pos() returns interpolated frequency of the pos param based on the cal
//	table positions
//	returns 0xffffffff if error
//	Table is stored as:
//	Fhi, poshi,		// top of band 0
//	Flo, poslo,		// bottom of band 0
//	Fhi, poshi,		// top of band 1
//	Flo, poslo,		// bottom of band 1
//	 :     :
//	 :     :
//	Fhi, poshi,		// top of band (last)
//	Flo, poslo,		// bottom of band (last)
//-----------------------------------------------------------------------------
U32 f_pos(S32 pos){
	U8	mlen;		// temp max table length
	U8	i = 0;		// temp counter/flag
	U32	ii;
	U32	ff;			// temp freq
	float fa;		// temp float

	if(pos < 0) pos = 0;
	mlen = (cal_table(0xff) * NEXT_FRQ) - NEXT_FRQ;			// calc addr of last cal table entry
	if(pos < eerd(THIS_POS)){								// if pos is outside table, set default freq
		ff = eerd(0);
		i = 0xff;											// set abort flag
	}
	if(pos > eerd(mlen + THIS_POS)){						// if pos is outside table, set default freq
		ff = eerd(mlen);
		i = 0xff;											// set abort flag
	}
	if(!i){
		ii = eerd(i + THIS_POS);
		while((pos > ii) && (i <= mlen)){	// locate freq pair (band) in table that corresponds to pos
			i += NEXT_FRQ;
			ii = eerd(i + THIS_POS);
		}
		if(i <= mlen){
			i -= NEXT_FRQ;									// point to upper freq of band
			fa = (float)(pos - eerd(i + THIS_POS))/(float)(eerd(i + NEXT_POS) - eerd(i + THIS_POS));
			ff = eerd(i) - eerd(i + NEXT_FRQ);				// get position ratio to interpolate freq
			fa *= (float)ff;
			ff = eerd(i + THIS_FRQ) + (U32)fa;
		}else{
			ff = 0xffffffff;								// error
		}
	}
	return ff;
}

//-----------------------------------------------------------------------------
// pos_f() returns interpolated pos of the freq param based on the cal
//	table positions
//	returns 0xffffffff if error
//-----------------------------------------------------------------------------
S32 pos_f(U32 freq){
	U8	mlen;		// temp max length
	U8	i = 0;		// temp counter
	U32	ff;			// temp pos
	float fa;		// temp float

	mlen = (cal_table(0xff) * NEXT_FRQ) - NEXT_FRQ;			// get max table length * 2
	if(freq > eerd(THIS_FRQ)){								// if freq is outside table, set default pos
		ff = eerd(THIS_POS);
		i = 0xff;											// set abort flag
	}
	if(freq < eerd(mlen + THIS_FRQ)){						// if freq is outside table, set default pos
		ff = eerd(mlen);
		i = 0xff;											// set abort flag
	}
	if(!i){
		while((freq < eerd(i)) && (i <= mlen)){	// locate freq pair (band) in table that corresponds to pos
			i += NEXT_FRQ;
		}
		if(i <= mlen){
			i -= NEXT_FRQ;									// point to upper freq of band
			fa = (float)(freq - eerd(i + NEXT_FRQ))/(float)(eerd(i) - eerd(i + NEXT_FRQ));
			ff = eerd(i + NEXT_POS) - eerd(i + THIS_POS);	// get freq ratio to interpolate position
			fa *= (float)ff;
			ff = eerd(i + NEXT_POS) - (U32)fa;
		}else{
			ff = ANT_MATCH_DISABLE;							// error
		}
	}
	return ff;
}

//-----------------------------------------------------------------------------
// cal_valid() returns true if:
//	- freq entries of freq_list are in cal table
//	- pos entries start at >0 and always increase
//	- no pos entry > MAX_ANTPOS
//-----------------------------------------------------------------------------
U8 cal_valid(void){
	U8	mlen;			// temp max length
	U8	i = TRUE;		// temp return (deafault to valid)
	U8	j;				// temp eeprom addr
	U8	k;				// temp freq table index
	U32 ii = 0;			// last entry temp
	U32 jj = 0;			// temp

	mlen = cal_table(0xff);							// get max table length
	for(j=0, k=0; k<mlen; j+=2,k++){
		if(eerd(j) != cal_table(k)) i = FALSE;		// if freq not in table, set error
		jj = eerd(j + 1);							// get table position
		if(jj > MAX_ANTPOS) i = FALSE;				// if table pos > MAX, set error
		if(jj <= ii) i = FALSE;						// if current < last, set error
		ii = jj;									// save last for next
		}
	return i;
}

//-----------------------------------------------------------------------------
// cal_table() returns cal table frequency
//	if index = 0xff, returns length of table
//-----------------------------------------------------------------------------
U32 cal_table(U8 index){
	U8	i;			// temp
	U16	freq_list[] = {29000, 28005, 24985, 24895, 21445, 21005, 18163, 18073,
					   14345, 14005, 10145, 10105,  7295,  7005,  3995,  3505,
					   0};
	U32 ii;			// temp

	i = 0;											// count # items in table..
	while(freq_list[i++]);
	if(index == 0xff){
		ii = (U32)(i - 1);							// .. to pass back to caller
	}
	else{
		index >>= 1;								// divide by 2 to get list index
		if(index < i){
			ii = (U32)freq_list[index] * 1000;		// convert table entry to MHz
		}else{
			ii = 0;									// error, set no frequency
		}
	}
	return ii;
}

//-----------------------------------------------------------------------------
// posupper() returns pos of upper freq in band fop
//	returns 0 if freq not found
//-----------------------------------------------------------------------------
S32 posupper(U32 fop){
	U8	mlen;			// temp max length
	U8	j;				// temp eeprom addr
	U8	k;				// temp freq table index

	mlen = cal_table(0xff) << 1;					// get max table length
	j = 0;
	k = FALSE;
	do{
		if(eerd(j) < fop){							// find lower band freq in table
			k = TRUE;
		}else{
			j += 2;
		}
	}while((j < mlen) && !k);
	j -= 2;											// back-up to upper band freq
	if(k) return 0;
	else return (S32)eerd(j+1);
}

//-----------------------------------------------------------------------------
// poslower() returns pos of lower freq in band fop
//	returns 0 if freq not found
//-----------------------------------------------------------------------------
S32 poslower(U32 fop){
	U8	mlen;			// temp max length
	U8	j;				// temp eeprom addr
	U8	k;				// temp freq table index

	mlen = cal_table(0xff) << 1;					// get max table length
	j = 0;
	k = FALSE;
	do{
		if(eerd(j) < fop){							// find lower band freq in table
			k = TRUE;
		}else{
			j += 2;
		}
	}while((j < mlen) && !k);
	if(k) return 0;
	else return (S32)eerd(j+1);
}

//-----------------------------------------------------------------------------
// hfant_sel() sets/returns HF relay setting
//-----------------------------------------------------------------------------
char hfant_sel(char select){
	char	c;		// temp return

	switch(select){
	case '6':
		GPIO_PORTA_DATA_R &= ~N6MON;						// set 6M
		break;

	case 'h':
	case 'H':
		GPIO_PORTA_DATA_R |= N6MON;							// set HF
		break;
	}
	if(GPIO_PORTA_DATA_R & N6MON){							// construct HF/6M status string
		c = 'H';
	}else{
		c = '6';
	}
	wrwhib_ram((last_antsel & LASTASEL_HM) | (U32)c,&last_antsel);
//	while(~HIB_CTL_R & HIB_CTL_WRC);						// wait for HIBRAM ready
//	last_antsel = (last_antsel & LASTASEL_HM) | (U16)c;		// update HIBRAM storage
	return c;
}

//-----------------------------------------------------------------------------
// vuant_sel() sets/returns VHF/UHF relay setting
//-----------------------------------------------------------------------------
char vuant_sel(char select){
	char	c;		// temp return

	switch(select){
	case 'v':
	case 'V':
		GPIO_PORTA_DATA_R |= NUHFON;							// set VHF
		break;

	case 'u':
	case 'U':
		GPIO_PORTA_DATA_R &= ~NUHFON;							// set UHF
		break;
	}
	if(GPIO_PORTA_DATA_R & NUHFON){								// construct HF/6M status string
		c = 'V';
	}else{
		c = 'U';
	}
	wrwhib_ram((last_antsel & LASTASEL_VM) | ((U32)c << 8),&last_antsel);
//	while(~HIB_CTL_R & HIB_CTL_WRC);							// wait for HIBRAM ready
//	last_antsel = (last_antsel & LASTASEL_VM) | ((U16)c << 8);	// update HIBRAM storage
	return c;
}


//-----------------------------------------------------------------------------
// get_temp() returns temperature reading, chan = 0 is TA, chan = 1 is TH
//	res is:  0 = 0.5, 1 = 0.25, 2 = 0.125, 3 = 0.0625
//-----------------------------------------------------------------------------
float get_temp(U8 chan, U8 res){
	U8	i;					// temp resolution
	U16	k;					// raw data temp

	i = res;
	i <<= 5;
	k = (75 << res) + 75;										// tmeas(max) = 75 * 2^i (ms)
	switch(chan){
	case 0:
		I2C_Send2(ADDR_TSENS0, PTR_CONFIG, i);
		I2C_Send1(ADDR_TSENS0, PTR_TSENSE);
		wait(k);
		k = I2C_Recv2(ADDR_TSENS0);								// get tempA sense data
		break;

	case 1:
		I2C_Send2(ADDR_TSENS1, PTR_CONFIG, i);
		I2C_Send1(ADDR_TSENS1, PTR_TSENSE);
		wait(k);
		k = I2C_Recv2(ADDR_TSENS1);								// get tempH sense data
		break;
	}
	return temp_float(k);
}
