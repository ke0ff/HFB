/********************************************************************
 ************ COPYRIGHT (c) 2017 by ke0ff, Taylor, TX   *************
 *
 *  File name: ccmd.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  CCMD Command Interpreter source
 *
 *******************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
//#include <intrins.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "ccmd.h"

#include "cmd_fn.h"
#include "serial.h"
#include "srec.h"
#include "version.h"
#include "adc.h"
#include "I2C0.h"
#include "io.h"
#include "eeprom.h"

//=============================================================================
// local registers


//=============================================================================
// local Fn declarations


//=============================================================================
// CCMD entry point
//	Processes CCMD message in time-sliced state machine fasion
//=============================================================================
void process_CCMD(U8 cmd){
static	volatile U32	loopie;
static	volatile U8		err_cnt;
				char	c;
				char	d;
				char	ccbuf[100];
				char	msgstat;
	volatile	char	msgsrc;
				char*	ptr;
				float	fa;
				uint32_t ii;

	loopie++;
	if((cmd == IPL_CMD) || (err_cnt > 4)){		// do IPL init
		ccmd_timer = 0;
		loopie = 0;
		err_cnt = 0;
		init_tsip1();
		puts0("ccmd trace");
		return;
	}
	if(gotmsgn1()){
		// process ccmds
		ptr = ccbuf;
		gets1(ccbuf);
		msgstat = *ptr++;							// get msg status
		msgsrc = *ptr++;							// get msg source (not used yet)
		if((*ptr++ == HFB_ID) && !(msgstat & FRAME_CHKERR)){
			switch(*ptr++){
			case 'V':								// return SW version		<<<<<<<<<<<<<<<<
				ccmdSWvers(ccbuf);
				break;

			case 'W':								// reset power wd			<<<<<<<<<<<<<<<<
				pwr_wd(1);
				puts0("wdr");
				break;

			case 'O':								// force power off			<<<<<<<<<<<<<<<<
				if((*ptr == 'F') && (*(ptr+1) == 'F')) pwr_wd(0);
				break;

			case 'T':								// itg temperature			<<<<<<<<<<<<<<<<
													// T0 = ambient, T1 = HF heatsink
				fa = get_temp((*ptr)&1, 1);			// 0.25C resolution
				sprintf(ccbuf,"!HT%c %.1f",*ptr,fa);
				break;

			case 'M':								// set/itg meter mode		<<<<<<<<<<<<<<<<
				switch(*ptr){
				case 'P':
					meter_mode(METER_PEPON);
					break;

				case 'A':
					meter_mode(METER_PEPOFF);
					break;

				case '1':
					meter_mode(METER_HI);
					break;

				case '0':
					meter_mode(METER_LO);
					break;

				default:
					break;
				}
				if((meter_mode(METER_ITG) & METER_HI)) c = 'H';
				else c = 'L';
				if((meter_mode(METER_ITG) & METER_PEPON)) d = 'P';
				else d = 'A';
				sprintf(ccbuf,"!HM%c%c\n",c,d);			// ITG response
				break;

			case 'F':									// fan on/off/itg		<<<<<<<<<<<<<<<<
				if(*ptr){
					if(*ptr == '0'){
						GPIO_PORTA_DATA_R &= ~FANON;	// set fan off
					}else{
						get_fanrpm(1);					// init rpm sense
						GPIO_PORTA_DATA_R |= FANON;		// set fan on
					}
				}
				if(GPIO_PORTA_DATA_R & FANON){
					ii = get_fanrpm(0);
	//				fa = 30.0 * (float)SYSCLK / (float)ii;
	//				sprintf(ccbuf,"!HF %.0f\n",fa);
					// ii = 30 * SYSCLK / RPM
					// 1153846 = 30 * 50000000 / 1300
					ii = (30L * SYSCLK) / ii;
					sprintf(ccbuf,"!HF %d\n",(U16)ii);
				}else{
					sprintf(ccbuf,"!HF 0\n");
				}
				break;

			default:
//				sprintf(ccbuf,"~Herr\n");				// error response		<<<<<<<<<<<<<<<<
				ccbuf[0] = '\0';
				err_cnt += 1;
				break;
			}
			if(*ccbuf){
				puts1_dle(ccbuf, strlen(ccbuf));
			}
		}else{
			ptr--;
			puts0(ptr);
			if(msgstat & FRAME_CHKERR){
				puts0("chkerr");
				puts1_dle("HZ~~~\r", 6);
			}
		}
	}
}
