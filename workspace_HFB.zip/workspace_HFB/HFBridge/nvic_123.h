/********************************************************************
 ************ COPYRIGHT (c) 2017 by KE0FF, Taylor, TX   *************
 *
 *  File name: nvic_123.h
 *
 *  Module:    Control
 *
 *  Summary:   bit-map defines for Tiva TM4C123 NVIC registers
 *
 *******************************************************************/

#ifndef NVIC_H_
#define NVIC_H_
												// NVIC_EN0
#define	NVIC_EN0_GPIO_PORTA			0x00000001	// 00{	GPIO Port A
#define	NVIC_EN0_GPIO_PORTB			0x00000002	// 01	GPIO Port B
#define	NVIC_EN0_GPIO_PORTC			0x00000004	// 02	GPIO Port C
#define	NVIC_EN0_GPIO_PORTD			0x00000008	// 03	GPIO Port D
#define	NVIC_EN0_GPIO_PORTE			0x00000010	// 04{	GPIO Port E
#define	NVIC_EN0_UART0				0x00000020	// 05	UART0 Rx and Tx
#define	NVIC_EN0_UART1				0x00000040	// 06	UART1 Rx and Tx
#define	NVIC_EN0_SSI0				0x00000080	// 07	SSI0 Rx and Tx
#define	NVIC_EN0_I2C0				0x00000100	// 08{	I2C0 Master and Slave
#define	NVIC_EN0_PWM0FAULT			0x00000200	// 09	PWM0 Fault
#define	NVIC_EN0_PWM00				0x00000400	// 10	PWM0 Generator 0
#define	NVIC_EN0_PWM01				0x00000800	// 11	PWM0 Generator 1
#define	NVIC_EN0_PWM02				0x00001000	// 12{	PWM0 Generator 2
#define	NVIC_EN0_QENC0				0x00002000	// 13	Quadrature Encoder 0
#define	NVIC_EN0_ADC0SEQ0			0x00004000	// 14	ADC0 Sequence 0
#define	NVIC_EN0_ADC0SEQ1			0x00008000	// 15	ADC0 Sequence 1
#define	NVIC_EN0_ADC0SEQ2			0x00010000	// 16{	ADC0 Sequence 2
#define	NVIC_EN0_ADC0SEQ3			0x00020000	// 17	ADC0 Sequence 3
#define	NVIC_EN0_WDOG				0x00040000	// 18	Watchdog timer
#define	NVIC_EN0_TIMER0A			0x00080000	// 19	Timer 0 subtimer A
#define	NVIC_EN0_TIMER0B			0x00100000	// 20{	Timer 0 subtimer B
#define	NVIC_EN0_TIMER1A			0x00200000	// 21	Timer 1 subtimer A
#define	NVIC_EN0_TIMER1B			0x00400000	// 22	Timer 1 subtimer B
#define	NVIC_EN0_TIMER2A			0x00800000	// 23	Timer 2 subtimer A
#define	NVIC_EN0_TIMER2B			0x01000000	// 24{	Timer 2 subtimer B
#define	NVIC_EN0_COMP0				0x02000000	// 25	Analog Comparator 0
#define	NVIC_EN0_COMP1				0x04000000	// 26	Analog Comparator 1
//									0x08000000	// 27	reserved
#define	NVIC_EN0_SYSCNTL			0x10000000	// 28{	System Control (PLL, OSC, BO)
#define	NVIC_EN0_FLASH				0x20000000	// 29	FLASH Control
#define	NVIC_EN0_GPIO_PORTF			0x40000000	// 30	GPIO Port F
//									0x80000000	// 31	reserved
												// NVIC_EN1
//									0x00000001	// 00{	reserved
#define	NVIC_EN1_UART2				0x00000002	// 01	UART2 Rx and Tx
#define	NVIC_EN1_SSI1				0x00000004	// 02	SSI1 Rx and Tx
#define	NVIC_EN1_TIMER3A			0x00000008	// 03	Timer 3 subtimer A
#define	NVIC_EN1_TIMER3B			0x00000010	// 04{	Timer 3 subtimer B
#define	NVIC_EN1_I2C1				0x00000020	// 05	I2C1 Master and Slave
#define	NVIC_EN1_QEI1				0x00000040	// 06	QEI1
#define	NVIC_EN1_CAN0				0x00000080	// 07	CAN0
#define	NVIC_EN1_CAN1				0x00000100	// 08{	CAN1
//									0x00000200	// 09	reserved
//									0x00000400	// 10	reserved
#define	NVIC_EN1_HIB				0x00000800	// 11	HIB
#define	NVIC_EN1_USB0				0x00001000	// 12{	USB0
#define	NVIC_EN1_PWM3				0x00002000	// 13	PWM Generator 3
#define	NVIC_EN1_DMAXFR				0x00004000	// 14 	uDMA Software Transfer
#define	NVIC_EN1_DMAERR				0x00008000	// 15	uDMA Error
#define	NVIC_EN1_ADC0SEQ0			0x00010000	// 16{	ADC1 Sequence 0
#define	NVIC_EN1_ADC0SEQ1			0x00020000	// 17	ADC1 Sequence 1
#define	NVIC_EN1_ADC0SEQ2			0x00040000	// 18	ADC1 Sequence 2
#define	NVIC_EN1_ADC0SEQ3			0x00080000	// 19	ADC1 Sequence 3
//									0x00100000	// 20{	reserved
//									0x00200000	// 21	reserved
//									0x00400000	// 22	reserved
//									0x00800000	// 23	reserved
//									0x01000000	// 24{	reserved
#define	NVIC_EN1_SSI2				0x02000000	// 25	SSI2
#define	NVIC_EN1_SSI3				0x04000000	// 26	SSI3
#define	NVIC_EN1_UART3				0x08000000	// 27	UART3 Rx and Tx
#define	NVIC_EN1_UART4				0x10000000	// 28{	UART4 Rx and Tx
#define	NVIC_EN1_UART5				0x20000000	// 29	UART5 Rx and Tx
#define	NVIC_EN1_UART6				0x40000000	// 30	UART6 Rx and Tx
#define	NVIC_EN1_UART7				0x80000000	// 31	UART7 Rx and Tx
												// NVIC_EN2
//									0x00000001	// 00{	reserved
//									0x00000002	// 01	reserved
//									0x00000004	// 02	reserved
//									0x00000008	// 03	reserved
#define	NVIC_EN2_I2C2				0x00000010	// 04{	I2C2 Master and Slave
#define	NVIC_EN2_I2C3				0x00000020	// 05	I2C3 Master and Slave
#define	NVIC_EN2_TIMER4A			0x00000040	// 06	Timer 4 subtimer A
#define	NVIC_EN2_TIMER4B			0x00000080	// 07	Timer 4 subtimer B
//									0x00000100	// 08{	reserved
//									0x00000200	// 09	reserved
//									0x00000400	// 10	reserved
//									0x00000800	// 11	reserved
//									0x00001000	// 12{	reserved
//									0x00002000	// 13	reserved
//									0x00004000	// 14	reserved
//									0x00008000	// 15	reserved
//									0x00010000	// 16{	reserved
//									0x00020000	// 17	reserved
//									0x00040000	// 18	reserved
//									0x00080000	// 19	reserved
//									0x00100000	// 20{	reserved
//									0x00200000	// 21	reserved
//									0x00400000	// 22	reserved
//									0x00800000	// 23	reserved
//									0x01000000	// 24{	reserved
//									0x02000000	// 25	reserved
//									0x04000000	// 26	reserved
//									0x08000000	// 27	reserved
#define	NVIC_EN2_TIMER5A			0x10000000	// 28{	Timer 5 subtimer A
#define	NVIC_EN2_TIMER5B			0x20000000	// 29	Timer 5 subtimer B
#define	NVIC_EN2_WTIMER0A			0x40000000	// 30	WTimer 0 subtimer A
#define	NVIC_EN2_WTIMER0B			0x80000000	// 31	WTimer 0 subtimer B
												// NVIC_EN3
#define	NVIC_EN3_WTIMER1A			0x00000001	// 00{	WTimer 1 subtimer A
#define	NVIC_EN3_WTIMER1B			0x00000002	// 01	WTimer 1 subtimer B
#define	NVIC_EN3_WTIMER2A			0x00000004	// 02	WTimer 2 subtimer A
#define	NVIC_EN3_WTIMER2B			0x00000008	// 03	WTimer 2 subtimer B
#define	NVIC_EN3_WTIMER3A			0x00000010	// 04{	WTimer 3 subtimer A
#define	NVIC_EN3_WTIMER3B			0x00000020	// 05	WTimer 3 subtimer B
#define	NVIC_EN3_WTIMER4A			0x00000040	// 06	WTimer 4 subtimer A
#define	NVIC_EN3_WTIMER4B			0x00000080	// 07	WTimer 4 subtimer B
#define	NVIC_EN3_WTIMER5A			0x00000100	// 08{	WTimer 5 subtimer A
#define	NVIC_EN3_WTIMER5B			0x00000200	// 09	WTimer 5 subtimer B
#define	NVIC_EN3_SYSEXCEP			0x00000400	// 10	System Exception
#define	NVIC_EN3_HIMLED				0x00000800	// 11	reserved
#define	NVIC_EN3_HIMIR				0x00001000	// 12{	reserved
#define	NVIC_EN3_I2C8				0x00002000	// 13	reserved
#define	NVIC_EN3_I2C9				0x00004000	// 14	reserved
#define	NVIC_EN3_GPIO_PORTT			0x00008000	// 15	reserved
#define	NVIC_EN3_FAN1				0x00010000	// 16{	reserved
//									0x00020000	// 17
//									0x00040000	// 18
//									0x00080000	// 19
//									0x00100000	// 20{
//									0x00200000	// 21
//									0x00400000	// 22
//									0x00800000	// 23
//									0x01000000	// 24{
//									0x02000000	// 25
//									0x04000000	// 26
//									0x08000000	// 27
//									0x10000000	// 28{
//									0x20000000	// 29
//									0x40000000	// 30
//									0x80000000	// 31
												// NVIC_EN4
//									0x00000001	// 00{
//									0x00000002	// 01
//									0x00000004	// 02
//									0x00000008	// 03
//									0x00000010	// 04{
//									0x00000020	// 05
#define	NVIC_EN4_PWM10				0x00000040	// 06	PWM1 Generator 0
#define	NVIC_EN4_PWM11				0x00000080	// 07	PWM1 Generator 1
#define	NVIC_EN4_PWM12				0x00000100	// 08{	PWM1 Generator 2
#define	NVIC_EN4_PWM13				0x00000200	// 09	PWM1 Generator 3
#define	NVIC_EN4_PWM1FAULT			0x00000400	// 10	PWM1 Fault

#endif /* NVIC_H_ */
