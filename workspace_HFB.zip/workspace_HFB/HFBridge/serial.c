/********************************************************************
 ************ COPYRIGHT (c) 2014 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the serial I/O module for the HFBridge
 *             protocol converter.  Handles UART0, UART1, and UART2 I/O
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    07-30-14 jmh:  creation date
 *
 *******************************************************************/

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"
#include "stdio.h"
#include "serial.h"
#include "cmd_fn.h"
#include "nvic_123.h"

//------------------------------------------------------------------------------
// Define Statements
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Local Variable Declarations
//-----------------------------------------------------------------------------

// xmodem control flags & regs
U8  xmode;						// xmodem transfer enable flag, if == 1, getchr
								//		is primary interface to xmodem protocol
U8  xcrc;						// crc checksum enable
U8  xtxdr;						// tx data ready flag
U8  xrxdr;						// rx data ready flag
#define XM_PACKETLEN (1+2+128+1) // length of checksum packet (SOH,N,~N,128 data bytes,CHKS)
#define	XBUF_MAX 135			// max# xmodem buffer bytes
char xmbuf[XBUF_MAX];			// xmodem data buffer
U8   xmptr;						// xmodem buf pointer
#define XM_DATASTART 2          // start of data payload in xmbuf
#define XM_DATAEND (128+2)      // end of data payload in xmbuf (one past end)
#define	XM_TX_DATASRT 3			// TX xm pointers
#define	XM_TX_DATAEND (XM_TX_DATASRT + 128)

// UART0 control flags & regs (DEBUG CLI I/O)
U8  TI0B;						// UART0 TI0 reflection (set by interrupt)
#define RXD0_BUFF_END 40		// CLI rx buff len
#define RXD1_BUFF_END 200		// CCMD rx buff len
#define RXD2_BUFF_END 40		// CIV rx buff len
#define TXD_BUFF_END 30			// tx buffs
#define TXD1_BUFF_END 100		// tx1 buff

S8   rxd_buff[RXD0_BUFF_END];	// rx data buffer
U8   rxd_hptr;					// rx buf head ptr
U8   rxd_tptr;					// rx buf tail ptr
U8   rxd_stat;					// rx buff status

// UART1 (CCMD I/O, RS485)
U8   rxd1_buff[RXD1_BUFF_END];	// rx1 data buffer
U8   rxd1_hptr;					// rx1 buf head ptr
U8   rxd1_tptr;					// rx1 buf tail ptr
U8   rxd1_stat;					// rx1 buff status
U8   frm1_buff[RXD1_BUFF_END];	// rx1 frame buffer
U8   rxd1_state;				// rx1 tsip state
U8   rxd1_dle_count;			// rx1 tsip dle counter
U8   rxd1_lastc;				// rx1 tsip last chr reg
U8   rxd1_msgcnt;				// tsip message counter
U8   txd1_buff[TXD1_BUFF_END];	// tx1 data buffer
U8   txd1_hptr;					// tx1 buf head ptr
U8   txd1_tptr;					// tx1 buf tail ptr
U8   txd1_stat;					// tx1 buff status
U8   txd1_lastc;				// rx1 last-chr-sent reg

// UART2 (CIV I/O)
U8   rxd2_buff[RXD2_BUFF_END];	// rx2 data buffer
U8   rxd2_hptr;					// rx2 buf head ptr
U8   rxd2_tptr;					// rx2 buf tail ptr
U8   rxd2_stat;					// rx2 buff status
U8   txd2_buff[TXD_BUFF_END];	// tx2 data buffer
U8   txd2_hptr;					// tx2 buf head ptr
U8   txd2_tptr;					// tx2 buf tail ptr
U8   txd2_stat;					// tx2 buff status
U8   txd2_lastc;				// rx2 last-chr-sent reg

//-----------------------------------------------------------------------------
// Local Fn Declarations
//-----------------------------------------------------------------------------

char process_xrx(U8 state_cmd);
char getchr_b(void);
char gotchr_b(void);
char do_txeot(void);
U32 config_uart0(U32 baud);
void jam_wait(void);
void txstart1(void);

//********************//
// UART Init routines //
//********************//

//-----------------------------------------------------------------------------
// initserial() initializes serial buffers and fn state machines
//-----------------------------------------------------------------------------
void initserial(void){

    TI0B = 1;
    rxd_hptr = 0;
    rxd_tptr = 0;
    rxd_stat = 0;
    rxd1_hptr = 0;
    rxd1_tptr = 0;
    rxd1_stat = 0;
    frm1_buff[0] = FRAME_SRT;
    txd2_hptr = 0;
    txd2_tptr = 0;
//    txd1_stat = 0;
    rxd2_hptr = 0;
    rxd2_tptr = 0;
    rxd2_stat = 0;
    txd2_stat = 0;					// tx2 status

    init_uart0(115200L);
	process_xrx(RX_STATE_INIT);
	xmode = FALSE;
	handshake = FALSE;				// xon/xoff enable
	xoffsent = FALSE;				// xoff sent
	init_uart1(115200L);
    init_uart2(19200L);
}

/****************
 * init_uart inits UART0 to (baud), N81
 */
U32 init_uart0(U32 baud)
{
	U32	i;

	SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R0;			// enable UART0 peripheral
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R0;			// enable PA clock
	GPIO_PORTA_AFSEL_R |= 0x0003L;						// connect UART0 RX & TX to PA0 & PA1
	GPIO_PORTA_PCTL_R &= 0xFFFFFF00L;					// enable UART0 function
	GPIO_PORTA_PCTL_R |= 0x0011L;
	GPIO_PORTA_DIR_R |= 0x0002;							// txd = out
	GPIO_PORTA_DEN_R |= 0x0003;							// RXD = TXD = digital
	for(i=0;i<100000;i++);
	return config_uart0(baud);							// config UART0
}

/****************
 * config_uart0 inits UART0 to (baud), N81
 */
U32 config_uart0(U32 baud)
{
	U32	IR;
	U32	i;

	UART0_CTL_R &= 0xfffffffeL;							// disable UART
	UART0_CTL_R &= 0xffff33ffL;							// disable HS, leave TE and RE alone
	IR = (uint32_t)PIOCLK * 4L;							// IR = (sysclk * 64) / (16 * baud)
	IR /= baud;											//    = sysclk * 4 /baud
	UART0_IBRD_R &= 0xffff0000L;
	UART0_IBRD_R = (IR>>6) & 0xffff;
	UART0_FBRD_R &= 0xffffffc0L;
	UART0_FBRD_R |= IR & 0x3fL;
	UART0_CC_R = UART_CC_CS_PIOSC;						// set PIOSC as UART source
	UART0_LCRH_R |= 0x0060L;							// 8 bits
	UART0_IM_R &= 0xfffce000L;							// set UART0 to int on RX
	UART0_IM_R |= 0x0010L;
	UART0_CTL_R |= 0x0300L;								// set TE and RE
	UART0_CTL_R |= 0x0001L;								// enable UART
	for(i=0;i<100000;i++);								// delay a bit...
	return IR;
}

//-----------------------------------------------------------------------------
// process_xrx() processes RX xmodem cmds & xmodem state machine
//	useage is for system to call process_xrx(RX_STATE_INIT) to begin xmodem rcv.
//	next, call process_xrx(RX_STATE_PROC) until XMOD_DR is returned.  If XMOD_ABRT
//		or XMOD_ERR is returned, xfer has been aborted and flow should return to
//      the CLI.  XMOD_DONE indicates that the transmitter has finished sending
//      data and there is no more data to process (e.g., EOT received).
//	Once XMOD_DR is signalled, data is available from the xmbuf[] array using xmptr
//      and xmptr == XM_DATAEND to signal end of data buffer.
//	When the XMbuffer is empty, the system should call process_xrx(RX_STATE_PKAK)
//	Generally, the receiver will reach the end of useable data before the end
//		of the xmodem buffer (due to the padding that xmodem uses to keep packets
//		the same size).  The end of data is usually the terminating record
//		of an Srecord or Intel Hex file, but could also be when a CNTL-Z (EOF)
//		is encountered unexpectedly in the xmodem data stream (only true since
//		this appl doesn't support binary transfers).  When the system reaches
//		its end-of-file point (either a terminating record, or CNTL-Z), it
//      should call xrx_querry(RX_STATE_PACK) repeatedly until XMOD_DONE is
//      returned.
//	Finally, once XMOD_DONE is received, call xrx_querry(RX_STATE_CLEAR) to
//		terminate the xmodem transfer.  xrx_querry(RX_STATE_CLEAR) must also be
//		called after a return of XMOD_ABORT or XMOD_ERR.
//-----------------------------------------------------------------------------
char process_xrx(U8 state_cmd){
// state machine defines
#define	XRX_1			0x01			// state: wait for start of packet
#define	XRX_DATA		0x02			// state: get packet (N to checksum)
#define	XRX_GOTPACK		0x03			// state: got packet, data ready
#define XRX_ABORT		0x04			// state: abort xfr

	static	U8		rx_state;			// state maching state reg
	static	U8		xtries;				// retry counter
	static	char	pacN;				// ded-reconing packet count
	static	U8		byte_count;			// packet data byte counter
	static	U8		firstpack;			// first packet flag

	    	U16		checksum;			// crc checksum (16 bit) or additive checksum (8 bit)
	    	U16		chktemp;			// packet checksum (16 bit) temp reg
			U8		i;					// por loop var
			char	c;					// character temp reg
			char	c2;					// temp
			char	xrx_status = XMOD_NULL;	// got data return flag

	if(state_cmd == RX_STATE_INIT){
		xmode = TRUE;									// turn on xmodem reception
		xtries = ACKTRIES;								// init statics for start of packet reception
		pacN = 1;										// packet# starts @ 1
		xcrc = TRUE;									// start with crc
		xrxdr = FALSE;									// no data ready signal to getchr
		rx_state = XRX_1;								// set entry state
		xm_timer = 0;									// clear activity timeout timer
		firstpack = TRUE;								// enable first packet logic
		return xrx_status;
	}
	if(state_cmd == RX_STATE_CLEAR){
		xmode = FALSE;									// clear xmodem reception
        xrx_status = XMOD_DONE;	
		return xrx_status;
	}
	if(state_cmd == RX_STATE_QERY){
        if((rx_state == XRX_GOTPACK) && (xmptr < XM_DATAEND)){
            xrx_status = XMOD_DR;
        }	
		return xrx_status;
	}
	switch(rx_state){
		default:
			rx_state = XRX_ABORT;						// default state, abort
			xrx_status = XMOD_ERR;
			break;
		
		case XRX_1:
			if(xm_timer == 0){							// if chr timeout:
				xm_timer = XM_TO;						// reset timer
				if(firstpack){							// for first packet,
					if(--xtries == 0){
						xcrc = FALSE;					// cancel crc chksum after retries exhausted
						xtries = ACKTRIES;				// reset retry limit
					}
					if(xcrc){
						putchar_b('C');					// send crc start request
					}else{
						if(xtries == 0){
							rx_state = XRX_ABORT;		// if 2nd retry cycle exhausted, abort
							xrx_status = XMOD_ERR;
						}else{
							putchar_b(NAK);				// send sum chksum start request
						}
					}
				}else{									// for all other packets,
					if(--xtries == 0){
						rx_state = XRX_ABORT;			// if retries exhausted, abort
						xrx_status = XMOD_ERR;
					}else{
						putchar_b(NAK);					// if timeout, send NAK
					}
				}
			}else{
				c = getchr_b();							// look for chr
				switch(c){
					case CAN:							// if cancel, abort
						rx_state = XRX_ABORT;
						xm_timer = ONESEC;
						break;
					
					case EOT:							// if TX done, set done on this end
						putchar_b(AKN);
						xrx_status = XMOD_DONE;
						xmode = FALSE;
						break;

					case SOH:							// if start of packet,
						rx_state = XRX_DATA;			// go get entire packet
 						byte_count = XM_PACKETLEN - 1;  // yes, init packet byte count (minus SOH)
						if(xcrc) byte_count++;			// if crc, add another byte
 						xmptr = 0;						// init data pointer
						xm_timer = XM_TO;
						break;
				}										// all other chrs ignored
			}
			break;
		
		case XRX_DATA:
			if(xm_timer == 0){
				rx_state = XRX_1;						// if timeout waiting for data, restart packet
			}else{
				if(gotchr_b()){							// wait until there is received data
					c = getchr_b();
					xmbuf[xmptr++] = c;					// store data in buffer
					if(--byte_count == 0){				// update byte count, if end of data, go look for chksum,
						// validate packet
						c2 = ~((U8)xmbuf[1]);
						if(xmbuf[0] == c2){
 							if(xmbuf[0] == (pacN - 1)){	// seq# = last, discard and ACK
 								putchar_b(AKN);
 								rx_state = XRX_1;
								xm_timer = XM_TO;						
 							}else{
								checksum = 0;
								for(i=XM_DATASTART;i<XM_DATAEND;i++){
									if(xcrc){
										checksum = calcrc(xmbuf[i], checksum, XPOLY); // if crc, update crcsum
									}else{
										checksum += (U16)xmbuf[i]; // else do checksum
										checksum &= 0xff;
									}
								}
								if(xcrc){
									chktemp = ((U16)xmbuf[130] << 8) | ((U16)xmbuf[131] & 0xff);
								}else{
									chktemp = ((U16)xmbuf[130]) & 0xff;
								}
								if(chktemp == checksum){
									rx_state = XRX_GOTPACK; // packet received, go to data ready idle state,
									xrx_status = XMOD_DR;
									xrxdr = TRUE;
									xmptr = XM_DATASTART; // point to start of data
								}else{
									rx_state = XRX_1;	// seq# and ~seq# test failed, NAK/retry
									xm_timer = 0;
								}
							}
						}else{
							rx_state = XRX_1;			// seq# and ~seq# test failed, NAK/retry
							xm_timer = 0;
						}
					}
				}
			}
			break;
		
		case XRX_GOTPACK:								// stay here until system empties data buffer and ends packet
			xrx_status = XMOD_DR;							// return data ready
			if(state_cmd == RX_STATE_PACK){				// if system sends packet ackn signal, send ACK, update seq#,
				putchar_b(AKN);							// and recycle for next packet
				pacN++;
				firstpack = FALSE;
				rx_state = XRX_1;
				xm_timer = XM_TO;
				xtries = ACKTRIES;						// reset retry limit		
				xrx_status = XMOD_PKAK;					// return packet ack'd
			}
			break;
			
		case XRX_ABORT:									// xm_timer is chr received timer for abort,
			if(xm_timer == 0){							// no chr received for 1 sec is cancellation success
				if(gotchr_b()){							// since chrs received, we aren't cancelled yet,
					while(gotchr_b()) getchr_b();		// clear out rx buffer,
					putchar_b(CAN);						// send cancel,
					xm_timer = ONESEC;					// set chr clearing timeout,
					xrx_status = XMOD_ERR;				// return error until abort is qualified
				}else{
					xrx_status = XMOD_ABORT;			// signal abort success
				}
			}	
			break;
	}
	return xrx_status;									// return status signal
}

//-----------------------------------------------------------------------------
// process_xtx() processes TX xmodem cmds & xmodem state machine
//	useage is for system to call process_xtx(0, TX_STATE_INIT) to begin xmodem
//		TX. '0' is not transmited.
//	next, call process_xtx(chr, TX_STATE_PROC) with data until last data byte
//		has been sent. Finally, call process_xtx(CNTL-Z, TX_STATE_LAST) until
//		XMOD_DONE, XMOD_ERR, or XMOD_ABORT is returned.
//
//	If XMOD_ABRT is returned, xfer has been aborted and flow should return to
//      the CLI w/ err msg.  XMOD_DONE indicates that the TX was successful.
//-----------------------------------------------------------------------------
char process_xtx(char dc, U8 state_cmd){
// state machine defines
#define	XTX_SRTWAIT		0x01			// state: wait for start of packet
#define	XTX_BUILD		0x02			// state: build packet
#define XTX_ABORT		0x03			// state: abort xfr
#define XTX_DONE		0x04			// state: xfr complete

	static	U8		tx_state;			// state maching state reg
	static	char	pacN;				// ded-reconing packet count

			U8		xtries;				// retry counter
	    	U16		checksum;			// crc checksum (16 bit) or additive checksum (8 bit)
			U8		i;					// loop var
			U8		xmbufend;			// temp end buf pointer
			char	c;					// character temp reg
			char	xtx_status = XMOD_NULL;	// got data return flag

	if(state_cmd == TX_STATE_INIT){
		xmode = TRUE;									// turn on xmodem
		xtries = ACKTRIES;								// init statics for start of packet reception
		pacN = 1;										// packet# starts @ 1
		xm_timer = ONEMIN;								// set activity timeout timer
		tx_state = XTX_SRTWAIT;							// set entry state
		xmptr = 3;										// start of xmodem data
		return xtx_status;
	}
	if(state_cmd == TX_STATE_CLEAR){
		xmode = FALSE;									// clear xmodem
        xtx_status = XMOD_DONE;
		tx_state = XTX_DONE;
		return xtx_status;
	}
	switch(tx_state){
		case XTX_SRTWAIT:
			xmbuf[xmptr++] = dc;
			do{
				c = getchr_b();
				switch(c){								// process start of session response from receiver
					case NAK:
						xcrc = FALSE;					// normal response (checksum)
						c = AKN;
						break;

					case 'C':
						xcrc = TRUE;					// CRC response
						c = AKN;
						break;

					default:
						if((c == CAN) || (c == ESC)) c = CAN; // abort response
						break;
				}
			}while((c != CAN) && (c != AKN));
			if(c == CAN){
				tx_state = XTX_ABORT;					// process abort
				xmode = FALSE;
			}else{
				tx_state = XTX_BUILD;					// go to build packet state...
			}
			break;

		case XTX_BUILD:
			if(state_cmd == TX_STATE_LAST){
				if(xmptr == XM_TX_DATASRT){				// buffer empty, don't need to send data
					do_txeot();							// send EOT
					xmode = FALSE;						// disable xmodem
		    	    xtx_status = XMOD_DONE;				// set done status
					tx_state = XTX_DONE;
					return xtx_status;					// break out of fn here
				}else{
					do{
						xmbuf[xmptr++] = dc;			// fill buffer with chr
					}while(xmptr < XM_TX_DATAEND);
				}
			}else{
				xmbuf[xmptr++] = dc;					// put chr into buffer
			}
			if(xmptr == XM_TX_DATAEND){
				xmbuf[0] = SOH;
				xmbuf[1] = pacN;
				xmbuf[2] = ~pacN;
				if(xcrc){
					checksum = 0;						// calculate CRC
					for(i = XM_TX_DATASRT; i < XM_TX_DATAEND; i++){
						checksum = calcrc(xmbuf[i], checksum, XPOLY);
					}
					xmbuf[XM_TX_DATAEND] = (U8)(checksum >> 8);
					xmbuf[XM_TX_DATAEND+1] = (U8)(checksum & 0xff);
					xmbufend = XM_TX_DATAEND+2;
				}else{
					checksum = 0;						// calculate checksum
					for(i = XM_TX_DATASRT; i < XM_TX_DATAEND; i++){
						checksum += xmbuf[i];
					}
					xmbuf[XM_TX_DATAEND] = (U8)(checksum & 0xff);
					xmbufend = XM_TX_DATAEND+1;
				}
				do{
					for(i = 0; i < xmbufend; i++){		// send packet
						putchar_b(xmbuf[i]);
					}
					xm_timer = XM_TO;
					i = TRUE;
					xtries = ACKTRIES;
					do{
						c = getchr_b();					// wait for response
						switch(c){
							case CAN:
								xtries = 1;				// force exit
							case NAK:
							case AKN:
								i = FALSE;
								break;

							default:
								break;
						}
						if(xm_timer == 0){				// timed out
							i = FALSE;
							c = '\0';
						}
					}while(i);
					xtries--;
				}while((c == NAK) && (xtries != 0));	// tried out or nak'd
				if(xtries != 0){
					pacN++;								// packet sent, ready for next
					xmptr = XM_TX_DATASRT;
				}else{
					tx_state = XTX_ABORT;				// error, tried out
					xmode = FALSE;
				}
				if((state_cmd == TX_STATE_LAST) && xmode){ // send EOT to finish
					do_txeot();
					xmode = FALSE;
					tx_state = XTX_DONE;
				}
			}
			break;

		case XTX_ABORT:
			xtx_status = XMOD_ABORT;					// respond with abort
			break;

		case XTX_DONE:
			xtx_status = XMOD_DONE;						// respond with done
			break;

		default:
			tx_state = XTX_DONE;						// default to done
			xmode = FALSE;
			break;
	}
	return xtx_status;
}

//-----------------------------------------------------------------------------
// is_xmode() returns t/f of xmode.  This is an external call to request
//	local status info.
//-----------------------------------------------------------------------------
char is_xmode(void){

	char c = FALSE;

	if(xmode) c = TRUE;
	return c;
}

//-----------------------------------------------------------------------------
// do_txeot() sends TX EOT
//-----------------------------------------------------------------------------
char do_txeot(void){

	U8	xtries;
	char c;

	xtries = ACKTRIES + 1;						// set try counter (add 1 because we use it right off the bat)
	xm_timer = 0;								// start with timer = 0
	do{
		if(xm_timer == 0){						// if timer == 0,
			xm_timer = XM_TO;					// reset timer
			xtries--;							// update tries
			putchar_b(EOT);						// send EOT
		}
		c = getchr_b();							// get response
		if(c == NAK) xm_timer = 0;				// if NAK, use timer to signal
	}while((c != AKN) && (xtries != 0));		// do untio AKN or no more tries left
	xmode = FALSE;								// disable xmodem
	c = FALSE;									// default to error return
	if(xtries != 0) c = TRUE;					// no error return
	return c;
}

//-----------------------------------------------------------------------------
// calcrc() calculates incremental crcsum using supplied poly
//	(xmodem poly = 0x1021)
//-----------------------------------------------------------------------------
U16 calcrc(char c, U16 oldcrc, U16 poly){

	U16 crc;
	U8	i;
	
	crc = oldcrc ^ ((U16)c << 8);
	for (i = 0; i < 8; ++i){
		if (crc & 0x8000) crc = (crc << 1) ^ poly;
		else crc = crc << 1;
	 }
	 return crc;
}

//-----------------------------------------------------------------------------
// set_baud() sets baud rate to passed value (if supported).  If rate is valid,
//	return TRUE, else FALSE.  0 = 115,200 baud
//-----------------------------------------------------------------------------
char set_baud(U32 baud){

	char c = FALSE;
	
	switch(baud){
		case 9600L:
		case 19200L:
		case 38400L:
		case 57600L:
		case 115200L:
			config_uart0(baud);
			c = TRUE;
			break;

		case 0L:
			config_uart0(115200L);
			c = TRUE;
			break;
	}
	return c;
}

//-----------------------------------------------------------------------------
// putchar (UART0) serial output with xmodem layering
//	does cr/lf translation if not in xmode
//	xmodem transmit state machine fn (process_xtx()) is inserted here
//-----------------------------------------------------------------------------
char putchar0(char c){

	if(xmode){
		process_xtx(c, TX_STATE_PROC);
		if(!xmode) bchar = ESC;
	}else{
		// output cr if c = \n		// no xmodem
		if(c == '\n'){
		    wait_reg0(&UART0_FR_R, UART_FR_TXFF, CHR_WAT0);	// wait up for fifo to clear
//			while((UART0_FR_R & 0x0020) == 0x0020);
			UART0_DR_R = '\r';
		}
		// output character
	    wait_reg0(&UART0_FR_R, UART_FR_TXFF, CHR_WAT0);	// wait up for fifo to clear
//		while((UART0_FR_R & 0x0020) == 0x0020);
		UART0_DR_R = c;
	}
	return (c);
}

//-----------------------------------------------------------------------------
// putchar_b (UART0) base serial output (no xmodem layering)
//	no character translation or additions
//	TI0B is tx empty flag mirror
//-----------------------------------------------------------------------------
char putchar_b(char c){

	// output character
    wait_reg0(&UART0_FR_R, UART_FR_TXFF, CHR_WAT0);	// wait up for fifo to clear
//	while((UART0_FR_R & 0x0020) == 0x0020);
	UART0_DR_R = c;
	return c;
}

//-----------------------------------------------------------------------------
// putdch(), UART0
//	strips control chars from output
//-----------------------------------------------------------------------------
char putdch(char c){

	if((c >= ' ') && (c <= '~')){
		putchar0(c);
	}
	return (c);
}

//-----------------------------------------------------------------------------
// puthex(), UART0
//	displays param as ascii hex
//-----------------------------------------------------------------------------
U8 puthex(U8 dhex){

	char c;

	c = (dhex >> 4) + '0';
	if(c > '9') c += 'A' - '9' - 1;
	putchar0(c);
	c = (dhex & 0x0f) + '0';
	if(c > '9') c += 'A' - '9' - 1;
	putchar0(c);
	return (dhex);
}

//-----------------------------------------------------------------------------
// getchr looks for chr @ port0 rx.  If none, return '\0'
//	maps into xmodem layer if xmode == TRUE 
//	uses rollover buffer rxd_buff[] which is filled in the UART0 interrupt
//-----------------------------------------------------------------------------
char getchr(void){

	char c = '\0';
	char x;

	if(xmode){
        x = process_xrx(RX_STATE_PROC);
		if(x == XMOD_DR){
			if(xmptr < XM_DATAEND){
				c = xmbuf[xmptr++];
			}
			if(xmptr == XM_DATAEND){
                process_xrx(RX_STATE_PACK);
			}
		}
	}else{
		if(rxd_tptr != rxd_hptr){
			c = rxd_buff[rxd_tptr++];
			if(rxd_tptr >= RXD0_BUFF_END){
				rxd_tptr = 0;
			}
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotchr looks for chr in UART0 rx buf.  If none, return FALSE, else return TRUE
//	maps into xmodem layer if xmode == TRUE
//-----------------------------------------------------------------------------
char gotchr(void){

	char c = FALSE;			// return val
	char j;					// temp

	if(xmode){
		do{
			j = process_xrx(RX_STATE_PROC);
			switch(j){
				case XMOD_DR:
				case XMOD_ABORT:
				case XMOD_ERR:
				case XMOD_DONE:
					c = TRUE;
					break;
			}
		}while(!c);
    }else{
	    if(rxd_tptr != rxd_hptr){
            c = TRUE;
    	}
    }
	return c;
}

//-----------------------------------------------------------------------------
// getchr_b looks for chr @ UART0 rx.  If none, return '\0'
//	waits for a chr and returns (no xmodem traps)
//-----------------------------------------------------------------------------
char getchr_b(void){

	char c = '\0';

	if(rxd_tptr != rxd_hptr){
		c = rxd_buff[rxd_tptr++];
		if(rxd_tptr >= RXD0_BUFF_END){
			rxd_tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotchr_b looks for chr in UART0 rx buf.  If none, return FALSE,
//	else return TRUE (no xmodem traps
//-----------------------------------------------------------------------------
char gotchr_b(void){

	char c = FALSE;

	if(rxd_tptr != rxd_hptr){
		c = TRUE;
	}
	return c;
}

//-----------------------------------------------------------------------------
// puts0() does puts to UART0
//-----------------------------------------------------------------------------
int puts0(const char *string){

	while(*string){
		putchar0(*string++);
	}
	putchar0('\n');
	return 0;
}

//-----------------------------------------------------------------------------
// putsx0() does puts as ascii hex to UART0
//-----------------------------------------------------------------------------
int putsx0(const char *string, U8 len){
	U8	i = len;	// temp counter

	while(i){
		puthex(*string++);
		i--;
	}
	putchar0('\n');
	return 0;
}

//-----------------------------------------------------------------------------
// putss() does puts w/o newline
//-----------------------------------------------------------------------------
int putss(const char *string){

	while(*string){
		putchar0(*string++);
	}
	return 0;
}

//-----------------------------------------------------------------------------
// putsN() does puts to UART0 converting all cntl codes to "$xx"
//-----------------------------------------------------------------------------
int putsN(const char *string){

	while(*string){
		if((*string < ' ') || (*string > 0x7e)){
			putchar0('$');
			puthex(*string++);
		}else{
			putchar0(*string++);
		}
	}
	putchar0('\n');
	return 0;
}

//-----------------------------------------------------------------------------
// getch00 checks for input @ RX0.  If no chr, wait forever.
//	waits for a chr and returns.  Note: Processor spends most of its idle
//	time waiting in this fn.
//	looks for input in rxd_buff[] which is filled in the UART0 interrupt
//-----------------------------------------------------------------------------
char getch00(void){

	char c;

	while(rxd_tptr == rxd_hptr){
		process_IO(0);					// process system I/O
	}
	c = rxd_buff[rxd_tptr++];
	if(rxd_tptr == RXD0_BUFF_END){
		rxd_tptr = 0;
	}
	return c;
}

//==================== UART1 Fns =================================
// CCMD I/O
// Uses TSIP protocol (DLE/ETX)
/****************
 * init_uart inits UART1 to (baud), N81
 */
U32 init_uart1(U32 baud)
{
	U32	i;

	SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R1;		// enable UART peripheral
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R1;		// enable PB clock
	GPIO_PORTB_AFSEL_R |= 0x0003L;					// connect UART RX & TX to PB0 & PB1
	GPIO_PORTB_PCTL_R &= 0xFFFFFF00L;				// enable UART function
	GPIO_PORTB_PCTL_R |= 0x0011L;
	GPIO_PORTB_DIR_R |= 0x0002;						// txd = out
	GPIO_PORTB_DEN_R |= 0x0003;						// RXD = TXD = digital
	init_tsip1();									// init tsip machine
	for(i=0;i<100000;i++);
	return config_uart1(baud);						// config UART
}

/****************
 * config_uart1 inits UART1 to (baud), N81
 */
U32 config_uart1(U32 baud){
	U32	IR;
	U32	i;

	UART1_CTL_R &= 0xfffffffeL;						// disable UART
	UART1_CTL_R &= 0xffff33ffL;						// disable HS, leave TE and RE alone
	IR = (uint32_t)PIOCLK * 4L;						// IR = (sysclk * 64) / (16 * baud)
	IR /= baud;										//    = sysclk * 4 /baud
	UART1_IBRD_R &= 0xffff0000L;
	UART1_IBRD_R = (IR>>6) & 0xffff;
	UART1_FBRD_R &= 0xffffffc0L;
	UART1_FBRD_R |= IR & 0x3fL;
	UART1_CC_R = UART_CC_CS_PIOSC;					// set PIOSC as UART source
	UART1_LCRH_R |= 0x0060L;						// 8 bits
	UART1_IM_R &= 0xfffce000L;						// set UART to int on RX
	UART1_IM_R |= UART_IM_TXIM | UART_IM_RXIM;		// enable RX and TX interrupt
	UART1_CTL_R |= UART_CTL_RXE | UART_CTL_TXE;		// set TE and RE
	UART1_CTL_R |= UART_CTL_UARTEN;					// enable UART
	for(i=0;i<100000;i++);							// delay a bit...
	return IR;
}

/****************
 * init_tsip1 inits tsip rcv logic.  Clears buffers and counters
 */
void init_tsip1(void){

	NVIC_DIS0_R = 0x0040L;							// disable UART1 intr
	rxd1_state = TSIP_IDLE;							// rx1 tsip state: idle starts the rcv process
	rxd1_dle_count = 0;								// rx1 tsip dlecnt: clear
	rxd1_lastc = 0;									// rx1 tsip last chr reg: clear
	rxd1_msgcnt = 0;								// rx1 message counter: clear
	frm1_buff[0] = FRAME_SRT;						// set start of new frame
	rxd1_hptr = 0;									// init pointers
	rxd1_tptr = 0;
	txd1_hptr = 0;
	txd1_tptr = 0;
	NVIC_EN0_R = 0x0040L;							// enable UART1 intr
}

//-----------------------------------------------------------------------------
// txstatus1 (UART1) returns TRUE if DIR1 == 1 (is in TX mode), else FALSE
//-----------------------------------------------------------------------------
char txstatus1(void){
	char	c = FALSE;	// temp

	if(GPIO_PORTA_DATA_R & DIR1){					// if RS485 TX enabled:
		c = TRUE;
	}
	return c;
}

//-----------------------------------------------------------------------------
// txstart1 (UART1) starts serial buffered output
//-----------------------------------------------------------------------------
void txstart1(void){
	char	c;		// temp

    GPIO_PORTA_DATA_R |= DIR1;						// enable TX on 485 xcvr;
	c = txd1_buff[txd1_tptr];						// get 1st chr from txbuff
	if(++txd1_tptr >= TXD1_BUFF_END){				// advance tail pointer
		txd1_tptr = 0;								// wrap-around if needed
	}
    wait_reg0(&UART1_FR_R, UART_FR_TXFF, CHR_WAT1);	// fault-tolerant wait for fifo to clear
	UART1_DR_R = c;


	while(txd1_tptr != txd1_hptr);
	wait(5);
    GPIO_PORTA_DATA_R &= ~DIR1;							// return 485 xcvr to RX
    return;
}

//-----------------------------------------------------------------------------
// putchar1 (UART1) serial output
//	no cr/lf translation
//-----------------------------------------------------------------------------
char putchar1(char c){

	// put chr into txbuff
	txd1_buff[txd1_hptr] = c;
	if(++txd1_hptr >= TXD1_BUFF_END){				// advance tail pointer
		txd1_hptr = 0;								// wrap-around if needed
	}
	if(txd1_tptr == txd1_hptr){
		txd1_stat = TXD_ERR;						// set overflow error
	}
	return c;

/*	// output character
    wait_reg0(&UART1_FR_R, UART_FR_TXFF, CHR_WAT1);	// fault-tolerant wait for fifo to clear
//	while(UART1_FR_R & UART_FR_TXFF);
	UART1_DR_R = c;									// send chr
	return (c);*/
}

//-----------------------------------------------------------------------------
// getchr1 looks for chr @ port1 rx.  If none, return '\0'
//	uses circular buffer rxd1_buff[] which is filled in the UART1 interrupt
//-----------------------------------------------------------------------------
char getchr1(void){

	char c = '\0';

	if(rxd1_tptr != rxd1_hptr){						// if head != tail,
		c = rxd1_buff[rxd1_tptr++];					// get chr from circ-buff and update tail ptr
		if(rxd1_tptr >= RXD1_BUFF_END){				// process tail wrap-around
			rxd1_tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotchr1 looks for chr in UART1 rx buf.  If none, return FALSE, else return TRUE
//	must pass the counter to the msg chr index (first chr = 0).
//-----------------------------------------------------------------------------
char gotchr1(U8 chrnum){
	char c = FALSE;			// return val, default to "no chr"

    if((rxd1_tptr != rxd1_hptr) && rxd1_msgcnt){	// if (head != tail) && there is at least 1 msg..
    	if((!chrnum) || (!frm1_buff[rxd1_tptr])){	// ..AND, (if the first chr of the msg) OR (if not the start of the next msg)
    		c = TRUE;								// .. set chr ready to get flag
    	}
	}
	return c;
}

//-----------------------------------------------------------------------------
// goteom1 returns the eom chr that is in UART1 frm buf.
//-----------------------------------------------------------------------------
U8 goteom1(void){

	return frm1_buff[rxd1_tptr];					// pass the EOM buff status
}

//-----------------------------------------------------------------------------
// gotmsgn1 returns the rcvd msg count.
//-----------------------------------------------------------------------------
U8 gotmsgn1(void){

	return rxd1_msgcnt;								// pass the msg count status
}

//-----------------------------------------------------------------------------
// gets1() does gets from UART1 buffers (post TSIP)
//	On entry, string points to start of destination.  On exit, string points
//	to end of dest string + 1.
//-----------------------------------------------------------------------------
char* gets1(char *string){
	U8	i = 0;
	char chks = 0;
	char c;
	char* strp;

	strp = string++;								// save start of string, save room for status
	if(rxd1_msgcnt){								// if there is at least 1 message in the buffer..
		while(gotchr1(i++)){						// ..and as long as there are chrs in rx1 buffer..
			c = getchr1();
			chks += c;
			*string++ = c;							// ..then, transfer rx1 buffer to string
		}
		*string-- = '\0';							// set end of string (point to frame status after placing the null)
		*strp = goteom1();							// get eom & chks status, put at start
		if(chks) *strp |= FRAME_CHKERR;
		NVIC_DIS0_R = NVIC_EN0_UART1;				// disable UART1 intr
		rxd1_msgcnt--;								// decrement msg count
		NVIC_EN0_R =  NVIC_EN0_UART1;				// enable UART in the NVIC
	}
	return string;									// return pointer to (end of dest)
}

//-----------------------------------------------------------------------------
// puts1_dle() sends (len) bytes of *string to UART1 using DLE/ETX protocol
// Uses TSIP protocol (DLE/ETX):
//	<DLE> <id> <data payload> <DLE> <ETX>
//		<DLE> = 0x10
//		<id>  = cmd id byte (any value except <DLE> or <ETX>)
//		<ETX> = 0x03
//		<data payload> = any string of bytes, any length (including 0).
//			Any data byte that is <DLE> must be preceded by another DLE
//			(DLE stuffing).
//	*string points to <id> <data payload>, max combined length 255 bytes.
//		Note: This length restriction is imposed solely by the U8 size of the
//		len param.
//-----------------------------------------------------------------------------
int puts1_dle(char *string, U8 len){
	char c = 0;
	U8	i;
	char chks = SOURCE_ID;					// init checksum

    putchar1(DLE);							// construct tsip message ... DLE first
    putchar1(SOURCE_ID);					// place source ID
    for(i=0; i<len; i++){					// place data
		c = *string++;
		chks += c;							// accumulate checksum
		if(c == DLE) putchar1(c);			// do DLE stuffing
		putchar1(c);
	}
    chks = (~chks) + 1;						// make checksum = 2's compliment
	if(chks == DLE) putchar1(chks);			// place checksum with DLE stuff
	putchar1(chks);
    putchar1(DLE);							// place end of message
    putchar1(ETX);
	txstart1();								// start TX
	return 0;
}

//-----------------------------------------------------------------------------
// putss1() does puts1 w/o TSIP wrapper
//-----------------------------------------------------------------------------
int putss1(char *string){

	while(*string){
		putchar1(*string++);
	}
	txstart1();								// start TX
	return 0;
}

//==================== UART2 Fns =================================
// CIV I/O
/****************
 * init_uart inits UART0 to (baud), N81
 */
U32 init_uart2(U32 baud){
	U32	i;

	SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R2;		// enable UART peripheral
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R3;		// enable PD clock
	GPIO_PORTD_AFSEL_R |= 0x00C0L;					// connect UART RX & TX to PD6 & PD7
	GPIO_PORTD_PCTL_R &= 0xFFFFFF00L;				// enable UART function
	GPIO_PORTD_PCTL_R |= 0x11000000L;
	GPIO_PORTD_DIR_R |= 0x0080;						// txd = out
	GPIO_PORTD_DEN_R |= 0x00C0;						// RXD = TXD = digital
	for(i=0;i<100000;i++);
	return config_uart2(baud);						// config UART
}

/****************
 * config_uart2 inits UART2 to (baud), N81
 */
U32 config_uart2(U32 baud){
	U32	IR;
	U32	i;

	UART2_CTL_R &= 0xfffffffeL;						// disable UART
	UART2_CTL_R &= 0xffff33ffL;						// disable HS, leave TE and RE alone
	IR = (uint32_t)PIOCLK * 4L;						// IR = (sysclk * 64) / (16 * baud)
	IR /= baud;										//    = sysclk * 4 /baud
	UART2_IBRD_R &= 0xffff0000L;
	UART2_IBRD_R = (IR>>6) & 0xffff;
	UART2_FBRD_R &= 0xffffffc0L;
	UART2_FBRD_R |= IR & 0x3fL;
	UART2_CC_R = UART_CC_CS_PIOSC;					// set PIOSC as UART source
	UART2_LCRH_R |= 0x0060L;						// 8 bits
	UART2_IM_R &= 0xfffce000L;						// set UART0 to int on RX
	UART2_IM_R |= 0x0010L;
	UART2_CTL_R |= 0x0300L;							// set TE and RE
	UART2_CTL_R |= 0x0001L;							// enable UART
	for(i=0;i<100000;i++);							// delay a bit...
	return IR;
}

//-----------------------------------------------------------------------------
// putchar2 (UART2) serial output
//	no cr/lf translation
//-----------------------------------------------------------------------------
char putchar2(char c){

	// output character
    wait_reg0(&UART2_FR_R, UART_FR_TXFF, (10*CHR_WAT2));	// F-T wait for fifo to clear
//	while((UART2_FR_R & UART_FR_TXFF) == UART_FR_TXFF);
    txd2_stat |= TXD_CHRS;									// set chr sent flag
	txd2_lastc = c;											// store chr to LCS reg
	UART2_DR_R = c;											// send chr to UART
	return (c);
}

//-----------------------------------------------------------------------------
// getchr2 looks for chr @ port2 rx.  If none, return '\0'
//	uses circular buffer rxd2_buff[] which is filled in the UART2 interrupt
//-----------------------------------------------------------------------------
char getchr2(void){
	char c = '\0';			// pre-clear chr return

	if(rxd2_tptr != rxd2_hptr){						// if head != tail,
		c = rxd2_buff[rxd2_tptr++];					// get chr from buffer and update tail ptr
		if(rxd2_tptr >= RXD2_BUFF_END){				// process tail wrap-around
			rxd2_tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotchr2 looks for chr in UART2 rx buf.  If none, return FALSE, else return TRUE
//-----------------------------------------------------------------------------
char gotchr2(void){
	char c = FALSE;			// pre-clear return val (no chr)

    if(rxd2_tptr != rxd2_hptr){						// if head != tail, there is data to be had
        c = TRUE;									// set data present return status
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotmsg2 looks for an EOM terminated msg in UART2 rx buf.  If no EOM, return FALSE, else return TRUE
//-----------------------------------------------------------------------------
char gotmsg2(void){
	char c = FALSE;			// pre-clear return val (no chr)
	U8	i;					// temp tptr

    if(rxd2_tptr != rxd2_hptr){						// if head != tail, there is data to be had
    	i = rxd2_tptr;								// copy the tail ptr
    	do{
    		if(rxd2_buff[i++] == CIV_EOM) c = TRUE;	// look for an EOM (return TRUE if one is found)
    		if(i >= RXD2_BUFF_END){					// process tail wrap-around
    			i = 0;
    		}
    	}while((i != rxd2_hptr) && !c);				// keep looking until EOM is found or end of buffer
	}
	return c;
}

//-----------------------------------------------------------------------------
// cleanmsg2 cleans CIV buffer
//	this will NOT clean a message that is in the process of being received,
//	only full messages will be removed.
//-----------------------------------------------------------------------------
void cleanmsg2(void){

	while(gotmsg2()){								// for as long as a message is present..
		while(getchr2() != CIV_EOM);				// ..clean the msg from the buffer (discard)
	}
}

//-----------------------------------------------------------------------------
// puts2() does puts (w/o nl) to UART1
//	string is pointer to data to send, sent_string is filled with a copy of the
//	sent data to validate the sent data and locate the response
//-----------------------------------------------------------------------------
int puts2(const char *string){

	U8	retry = 0;			// retry counter
    U8	i = 0;				// init tx chr pointer
	int c = 0;				// init chr counter

	txd2_stat = TXD_SND;								// clear status flags, set sending
	do{
		txd2_buff[i++] = *string;						// copy str to TX buffer
		c++;											// update chr counter
	}while((*string++ != CIV_EOM) && (i < TXD_BUFF_END));	// until EOM is reached
	if(i >= TXD_BUFF_END){
		txd2_stat |= TXD_ERR;							// set buffer (overrun)
	}else{
	    txd2_hptr = i - 1;								// head points to last chr
		do{
	    	txd2_stat &= ~TXD_ERR;						// clear err
			if(retry){
				wait(10);								// retry wait
			}
			txd2_stat &= ~TXD_JAMMER;					// clear jam error
		    txd2_tptr = 0;								// tail points to start
		    while(!(txd2_tptr > txd2_hptr) && !(txd2_stat & TXD_ERR)){	// while buffer !empty && no txerr
				putchar2(txd2_buff[txd2_tptr++]);		// send data to UART & advance ptr
				uart2timer = CIV_TIMEOUT;				// set time limit
		    	while((txd2_stat & TXD_CHRS) && uart2timer); // wait for sent chr to be rcvd or timeout
			    if(!uart2timer){
			    	txd2_stat |= TXD_ERR;				// set err (timeout)
			    }else{
			    	if(txd2_stat & TXD_ERR){							// if error, is most likely a colission
						uart2timer = CIV_JAMOUT;						// set time limit
						do{
							if(txd2_stat & TXD_JAMMER){
								uart2timer = CIV_JAMOUT;				// reset timeout
								txd2_stat &= ~TXD_JAMMER;				// clear jammer detect
							}
						}while(uart2timer);								// wait for chr to clear or timeout
						txd2_stat &= ~TXD_JAMMER;						// clear error
			    	}
			    }
		    }
		}while((txd2_stat & TXD_ERR) && (retry++ < CIV_RETRY_LIM)); // if error, retry until limit reached
	}
	if(txd2_stat & TXD_ERR) c = 0;						// set error return
	txd2_stat &= ~TXD_SND;								// clear sending
	return c;											// return chr count
}

//-----------------------------------------------------------------------------
// gets2() does gets from UART1.  copies input to string
//-----------------------------------------------------------------------------
char* gets2(char *string){
	char	c = 0;				// temp chr
	char*	rptr = string;		// working pointers

	while(gotchr2() && (c != CIV_EOM)){
		c = getchr2();								// retrieve chr from buffer
			*rptr++ = c;							// pass rcvd data to dest string until no more chrs
	}
	*rptr = CIV_EOM;								// add fail-safe EOM (if EOM is 1st chr of response == error)
	return rptr;
}

//-----------------------------------------------------------------------------
// getmsg2() does message gets from UART1.  copies input to string and returns length
//-----------------------------------------------------------------------------
U8 getmsg2(char *string){
	char	c = 0;				// temp chr
	U8		i = 0;				// temp count
	char*	rptr = string;		// working pointers

	while(gotchr2() && (c != CIV_EOM)){
		c = getchr2();								// retrieve chr from buffer
			*rptr++ = c;							// pass rcvd data to dest string until no more chrs
			i++;
	}
	*rptr = CIV_EOM;								// add fail-safe EOM (if EOM is 1st chr of response == error)
	return i;
}

//-----------------------------------------------------------------------------
// putmsg2() sends CIV msg, returns length of reply which is stored to destptr
//	cmd is always used.
//	if scmd is not used, it must be 0xff
//	freq is multi use:
//	if freq == 0xffff, it is not used
//	if freq > 65536, it is a freq param
//	if freq == 0xffxx, bits [7:0] are sent as 1 packed BCD digit
//	else, bits 15:0 sent as-is
//-----------------------------------------------------------------------------
U8 putmsg2(char *destptr, U8 cmd, U8 scmd, U32 freq){
	char*	q = destptr;	// ptr to start of dest buffer
	char*	aptr = destptr;	// save start of dest string
	char*	bptr;			// temp ptr
	char	cbuf[15];		// temp buffer for BCD conv
	char	c;				// temps
	U16		i;
	U8		j;

	*q++ = CIV_PREA;								// assemble CIV message
	*q++ = CIV_PREA;
	*q++ = CIV_RADDR;								// radio addr
	*q++ = CIV_HADDR;								// cntlr addr
	*q++ = cmd; 									// cmd
	if(scmd != 0xff){
		*q++ = scmd; 								// scmd
	}
	if(freq > 65535){								// data is frequency (VFO)
		sprintf(cbuf,"%010u",freq);					// convert freq to ascii decimal
		bptr = cbuf;
		while(*bptr++);								// find end of arg
		bptr -= 2;									// back-up to last digit
		while(bptr >= cbuf){
			c = asc_hex(*bptr--);					// convert 2 ascii decimals to packed BCD byte
			c |= asc_hex(*bptr--) << 4;
			*q++ = c;								// store to dest
		}
	}else{
		i = (U16)freq;								// reduce bit overhead
		if(i != 0xffff){
			if((i & 0xff00) == 0xff00){
				*q++ = (char)(i & 0xff);			// store 1 sig digit to dest
			}else{
				*q++ = (char)(i >> 8);				// convert 2 ascii decimals to packed BCD byte
				*q++ = (char)(i & 0xff);
			}
		}
	}
	*q++ = CIV_EOM;									// end of message
	puts2(aptr);									// send message
	uart2timer = CIV_MSGWAIT;						// set time limit
	while(!gotmsg2() && uart2timer);				// wait for msg or timeout
	j = getmsg2(aptr);								// get rcvd
	return j;										// return pointer to start of response
}

//-----------------------------------------------------------------------------
// validmsg2() checks response msg at msgptr for validity, returns true if
//	message passes general formatting checklist
//-----------------------------------------------------------------------------
char validmsg2(char *msgptr, U8 len){
	char	i = TRUE;	// temp rtrn

	if(*msgptr != CIV_PREA) i = FALSE;				// if no preamble, set error
	if(*(msgptr+1) != CIV_PREA) i = FALSE;
	if(*(msgptr+4) == CIV_NG) i = FALSE;			// if NG response, set error
	if(*(msgptr+len) != CIV_EOM) i = FALSE;			// if no EOM, set error
	return i;
}

//==================== UART INTRPT Fns =================================

//-----------------------------------------------------------------------------
// rxd_intr() UART rx intr (CLI I/O).  Captures RX data and places into
//	circular buffer
//-----------------------------------------------------------------------------
void rxd_intr(void){
	char c;			// temp

	if(!(UART0_RIS_R & UART_RIS_RXRIS)){			// if intrpt is NOT rxd,
													// clear ALL intr flags and abort ISR
		UART0_ICR_R = UART_ICR_9BITIC|UART_ICR_OEIC|UART_ICR_BEIC|UART_ICR_PEIC|UART_ICR_FEIC|UART_ICR_RTIC|UART_ICR_TXIC|UART_ICR_CTSMIC;
		return;
		}
	while(!(UART0_FR_R & UART_FR_RXFE)){			// process RXD chrs
		c = UART0_DR_R;
		if(c == ESC) bchar = ESC;					// if ESC, set global escape reg
		rxd_buff[rxd_hptr++] = c;					// feed the buffer
		if(rxd_hptr >= RXD0_BUFF_END){
			rxd_hptr = 0;							// wrap buffer ptr
		}
		if(rxd_hptr == rxd_tptr){
			rxd_stat |= RXD_ERR;					// buffer overrun, set error
		}
	}
	UART0_ICR_R = UART_ICR_RXIC;					// clear RXD intr flag
	return;
}

//-----------------------------------------------------------------------------
// rxd1_intr() UART1 rx intr (CCMD I/O - TSIP).  Captures RX data and places
//	into circular buffer.  Also handles pre-processed TX data.
//	NOTE:
//	rxd1buff[], frm1_buff[], rxd1_state, rxd1_tptr, rxd1_hptr, rxd1_stat,
//	rxd1_msgcnt, rxd1_dlecnt, and rxd1_lastc are all defined as file-local
//	variables to allow local function access.
//-----------------------------------------------------------------------------
// This ISE gathers data from the UART1 peripheral and pre-processes the stream to
//	strip TSIP protocols so that the raw data is presented to the application layer.
//	Uses TSIP protocol (DLE/ETX):
//
//	<DLE> <id> <data payload> <DLE> <ETX>
//
//		<DLE> = 0x10
//		<id>  = cmd id byte (any value except <DLE> or <ETX>)
//		<ETX> = 0x03
//		<data payload> = any string of bytes, any length (including 0).
//			Any data byte that is <DLE> must be preceded by another DLE
//			(DLE stuffing).
//		<ETX> is valid iff (prev chr == DLE) && (DLE count, not including 1st DLE, is odd)
//
//	rxd1_buff[] holds the raw data, and a headptr and tailptr track the data through
//	the circular buffer construct.
//	In addition, a second circular buffer, frm1_buff[] holds frame and error
//	locators (FRAME_SRT and FRAME_ERR).  These locators appear at the pointer location
//	that corresponds to the 1st byte of the corresponding message and thus serve to
//	identify the start of an individual message.  If another FRAME locator is encountered
//	before the head pointer, the end of the frame, by inference, is the previous pointer
//	location.  Uses same head/tail ptr as rxd1_buff[].
//	Note: while FRAME_ERR indicates the start of the next frame, the error is associated
//	with the previous frame.
//	rxd1_msgcnt counts the number of completed frames and should be used to regulate
//	frame extraction.  This is done by the following procedure: When rxd1_stat == RXD_TSIPRDY,
//	extract a frame and decrement rxd1_msgcnt (decrement must be bracketed by masking of
//	UART1 intr).  If rxd1_msgcnt == zero, clear RXD_TSIPRDY.
//	if a lone DLE appears without an adjacenet ETX, the SW will flag an RXD_TSIPERR and
//	terminate the current frame with a FRAME_ERR locator.  Reception will then begin
//	assuming that the lone DLE is the start of a new frame.
//
//	TX data is processed from a head/tail tx buffer.  putchar1() fills the buffer, and
//	txstart1() starts the TX process by setting the DE GPIO (allows RS485 driver to TX)
//	and then sending the first chr from the buffer.
//	When the last chr in the buffer is sent, the ISR clears the DE GPIO (puts RS485 back
//	into RX).  This system only allows one message to be sent at a time, so the message layer
//	must call txstatus1() to see if the message is done sending.

void rxd1_intr(void){
	char	c;			// uart temp
	U8		hptr_old;	// old head ptr

	// if intrpt is NOT rxd or TXD:
	if(UART1_RIS_R & (UART_ICR_9BITIC|UART_ICR_OEIC|UART_ICR_BEIC|UART_ICR_PEIC|UART_ICR_FEIC|UART_ICR_RTIC|UART_ICR_CTSMIC)){
		// clear ALL intr flags and abort intr
		UART1_ICR_R = UART_ICR_9BITIC|UART_ICR_OEIC|UART_ICR_BEIC|UART_ICR_PEIC|UART_ICR_FEIC|UART_ICR_RTIC|UART_ICR_CTSMIC;
		return;
	}
	if((UART1_RIS_R & UART_ICR_TXIC)){							// if intrpt is TXD:
		if(txd1_tptr == txd1_hptr){								// if nothing to send:
//		    GPIO_PORTA_DATA_R &= ~DIR1;							// return 485 xcvr to RX
		}else{
			UART1_DR_R = txd1_buff[txd1_tptr];					// send next buffer byte
			if(++txd1_tptr >= TXD1_BUFF_END){					// advance tail pointer
				txd1_tptr = 0;									// wrap-around if needed
			}
		}
		UART1_ICR_R = UART_ICR_TXIC;							// clear TXD intr flag
	}
	if((UART1_RIS_R & UART_ICR_RXIC)){							// if intrpt is RXD:
		while(!(UART1_FR_R & UART_FR_RXFE)){					// process RXD chrs
			c = UART1_DR_R;
			switch(rxd1_state){
			case TSIP_IDLE:										// idle, look for 1st DLE
				if(c == DLE){
					rxd1_state = TSIP_START;					// DLE found: advance state,
					rxd1_lastc = 0;								// set lastc,
					rxd1_dle_count = 0;							// and init DLE count
				}
				break;

			case TSIP_START:
			case TSIP_RUN:										// running, look for valid ETX and unstuff DLEs, all else goes to *string
				if((c == ETX) && (rxd1_lastc == DLE)){ //&& (rxd1_dle_count & 0x01)
					rxd1_stat |= RXD_TSIPRDY;					// signal rcv complete
					rxd1_msgcnt++;								// increment message counter
					rxd1_state = TSIP_IDLE;						// reset to start
				}else{
					if(((c == DLE) && (rxd1_lastc == DLE)) || (c != DLE)){
						if((rxd1_lastc == DLE) && (c != DLE)){
							rxd1_stat |= RXD_TSIPERR;			// Flag an error
							frm1_buff[rxd1_hptr] = FRAME_ERR;	// set start of new frame to tag err position
							rxd1_msgcnt++;						// increment message counter
							break;								// break out of switch
						}
						if(rxd1_state == TSIP_START){			// if first chr of msg, preserve pre-stored SOM status
							rxd1_state = TSIP_RUN;				// change of state signals not first chr of msg on subsequent passes
						}else{
							frm1_buff[rxd1_hptr] = FRAME_CLR;	// else not 1st chr of msg, store clear status
						}
						hptr_old = rxd1_hptr;					// save head ptr in case of error
						rxd1_buff[rxd1_hptr++] = c;				// feed the buffer (place RXD chr into buffer) and update ptr
						if(rxd1_hptr >= RXD1_BUFF_END){
							rxd1_hptr = 0;						// wrap buffer ptr
						}
						if(rxd1_hptr == rxd1_tptr){				// test for buffer overrun
							rxd1_stat |= RXD_ERR;				// buffer overrun, set error
							rxd1_hptr = hptr_old;				// throw away most recent chr (restore head ptr)
						}
						frm1_buff[rxd1_hptr] = FRAME_SRT;		// pre-set start of next frame
						if(c == DLE){							// update dlecnt
							rxd1_dle_count += 1;
							rxd1_lastc = 0;						// lastc invalid after unstuffed DLE
						}else{
							rxd1_lastc = c;						// update lastc
						}
					}else{
						rxd1_dle_count += 1;					// chr is a DLE,
						rxd1_lastc = c;							// update lastc
					}
				}
				break;
			}
		}
		UART1_ICR_R = UART_ICR_RXIC;					// clear RXD intr flag
	}
}

//-----------------------------------------------------------------------------
// rxd2_intr() UART2 rx intr (CIV I/O).  Captures RX data and places into
//	circular buffer
//-----------------------------------------------------------------------------
void rxd2_intr(void){
	char c;

	if(!(UART2_RIS_R & UART_RIS_RXRIS)){			// if intrpt is NOT rxd,
													// clear ALL intr flags and abort ISR
		UART2_ICR_R = UART_ICR_9BITIC|UART_ICR_OEIC|UART_ICR_BEIC|UART_ICR_PEIC|UART_ICR_FEIC|UART_ICR_RTIC|UART_ICR_TXIC|UART_ICR_CTSMIC;
		return;
		}
	if(!(UART2_FR_R & UART_FR_RXFE)){				// process RXD chrs:
		c = UART2_DR_R;								// get chr
	}
	if(txd2_stat & TXD_SND){
		if(c == CIV_JAM){
			txd2_stat |= TXD_JAMMER;				// set JAMMER flag
		}
		if(txd2_stat & TXD_CHRS){
			txd2_stat &= ~TXD_CHRS;					// clear chr sending flag
			if(txd2_lastc != c){					// if not == last sent, set err
				txd2_stat |= TXD_CERR | TXD_ERR;	// set error
			}
		}
	}else{
		rxd2_buff[rxd2_hptr++] = c;					// feed the buffer
		if(rxd2_hptr >= RXD2_BUFF_END){
			rxd2_hptr = 0;							// wrap buffer ptr
		}
		if(rxd2_hptr == rxd2_tptr){
			rxd2_stat |= RXD_ERR;					// buffer overrun, set error
		}
	}
	UART2_ICR_R = UART_ICR_RXIC;					// clear RXD intr flag
	return;
}
