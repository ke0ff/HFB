/********************************************************************
 ************ COPYRIGHT (c) 2015 by ke0ff, Taylor, TX   *************
 *
 *  File name: io.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for io.c
 *
 *  Project scope revision history:
 *    03-22-15 jmh:  creation date
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>

#ifndef IO_H
#define IO_H
#endif

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------
// meter Fn #defines
#define	METER_PEPON			0x80
#define	METER_PEPOFF		0x40
#define	METER_HI			0x01
#define	METER_LO			0x00
#define	METER_ITG			0xff
#define	METER_PEPHI			(METER_PEPON | METER_HI)
#define	METER_PEPLO			(METER_PEPON | METER_LO)

// CIV save/restore Fn
#define	IC7K_IPL			0xff		// save/restore IC7K init
#define	IC7K_SAV			0x00		// save/restore IC7K save
#define	IC7K_RES			0x01		// save/restore IC7K restore
#define	IC7K_ERR			0xfe		// save/restore err flag

// CIV radio cmds
#define	CIV_RMODE			0x04		// civ read mode
#define	CIV_SMODE			0x06		// civ set mode
#define	CIV_RFREQ			0x03		// civ read freq
#define	CIV_SFREQ			0x05		// civ set freq
#define	CIV_PWRC			0x14		// civ power cmd
#define	CIV_PWRSC			0x0a		// civ power sub-cmd
#define	CIV_TRC				0x1c		// civ ptt cmd
#define	CIV_TRSC			0x00		// civ ptt sub-cmd
#define	CIV_MODE_RTTY		0x04		// civ RTTY mode

// CIV aux stack cmds
#define	CIV_AUXIPL			0x00		// aux status stack - init
#define	CIV_AUXPUSH			0x01		// aux status stack - push to aux
#define	CIV_AUXPULL			0x02		// aux status stack - pull from aux

// PTT cmds
#define	IC7K_PTT0			0x00		// unkey radio
#define	IC7K_PTT1			0x01		// key radio
#define	IC7K_PTTITG			0xff		// itg PTT

// tune
#define	ATUNE_ERR			0xfe		// tune operation error
#define	ATUNE_DONE			0x00		// tune operation complete
#define	ATUNE_UP			0x01		// tune antup
#define	ATUNE_DN			0x02		// tune antdn
#define	ATUNE_AUTO			0x03		// tune autodir
#define	ATUNE_DIRSW			0x80		// direction changed flag
#define	MINPWR_WAIT			1000		// max time to wait for min power level (ms)
#define	MINPWR_FWD			1000		// raw ADC value for minimum FWD pwr (P = 12 * value/1400 (W) = 8.5W)
#define	MINPWR_STOP			381			// limit of 1000R/F for immmediate stop, 381 = 2:1 SWR
#define	IM_LOCK				(U16)((24 * 4096)/33)	// raw ADC value for locked rotor threshold (2.4A)
#define	RF_VALID			1000		// max valid 1000R/F ratio
#define	IM_LOCK_LIM			10			// # consecutive samples to recognize im = locked
#define	MINPWR_CNT_LIM		4			// # consecutive samples to recognize best match reached
#define	MIN_HYST			82			// hysteresis limit for determining if past dip (2% of ADC full scale)
#define	MAX_ANTPOS			103000		// max allowed ant pos
#define	THIS_FRQ			0
#define	THIS_POS			1
#define	NEXT_FRQ			2
#define	NEXT_POS			3
#define	ANT_SETTLE			500			// settle wait period (ms)
#define	CAL_TABLE_ADDR		0			// addr of start of cal table in EEPROM
#define	MINPWR_STOP_ADDR	0x40		// addr of power stop limit variable
#define	RPWR_MAX			0xf0000000	// abs max rev pwr value
#define	TUNE_DEADBAND_ADDR	0x41		// addr of tune deadband variable
#define	TUNE_DEADBAND		100000		// default value of tune deadband variable
#define STOP_TIME			120			// (ms) motor reversal time delay to stop (emperically determined)
#define	SKID_DN				159			// stop overrun, down (emperically determined)
#define	SKID_UP				139			// stop overrun, up (emperically determined)
#define	TSWITCH				0			// tune blind origin IDs
#define	TCLI				1
#define	TCCMD				2
#define	LASTASEL_HM			0xff00		// mask off HF/6M select byte
#define	LASTASEL_VM			0x00ff		// mask off VHF/UHF select byte
#define	PCT_MAX				5			// #tune loops (50ms ea) to go past dip

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// io.c Fn prototypes
//-----------------------------------------------------------------------------
U8 meter_mode(U8 mtrcmd);
U8 set_ant(U8 cmd);
void ant_poswait(S32 pos);
U8 tune_ant(U8 tunecmd, U16 pwr_thresh);
U8 tune_blind(U32 force_freq, U8 origin);
U8 mode_ic7k(U8 opcode);
void stack_ic7k(U8 stackcmd);
U32 freq_ic7k(void);
U8 ptt_ic7k(U8 opcode);
U32 f_pos(S32 pos);
S32 pos_f(U32 freq);
U8 cal_valid(void);
U32 cal_table(U8 index);
S32 posupper(U32 fop);
S32 poslower(U32 fop);
U32 getfreq_ic7k(char* mptr, char* cbuf);
char hfant_sel(char select);
char vuant_sel(char select);
float get_temp(U8 chan, U8 res);

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
