/********************************************************************
 ************ COPYRIGHT (c) 2017 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This is the main code file for the HF Bridge Controller application.
 *  This device controls HF antenna movements, RF relay selections, LRU power,
 *  and general I/O functions.
 *
 *  The host system is a Tiva EK-TM4C123XL LaunchPad Evaluation Module that
 *  has interface circuits to connect the various sub-systems.  There is also
 *  an after-mkt low-loss coin-cell switch attached to the booster board along
 *  with several additional connections to accommodate the power control and
 *  hibernation systems.
 *
 *  The PC serial connection runs at 115.2 Kbaud via the LP ICDI JTAG I.F.
 *  and USB serial port (using UART0).
 *
 *  Project scope revision history:
 *    <VERSION 0.62>
 *    06-12-23 jmh:   Included code (in Process_IO()) to trap LDG Tuner LED status and send non-TSIP
 *    					messages to eACU.
 *    <VERSION 0.61>
 *    01-02-23 jmh:   Fan is now powered on/off automatically when the HF rig is on/off.
 *    <VERSION 0.6>
 *    11-03-22 jmh:  Corrected CIV I/O routines and added auto-antenna-relay control.
 *                   Changed auto-off/HF power off WD timer to 3 sec
 *                   Added IPL read of radio frequency with relay update
 *    <VERSION 0.5>
 *    03-03-17 jmh:  Added several ccmd functions (W/O/T/M/F).
 *    				 Changed HF power off delay to 5 sec.
 *    				 Added power on wd reset fn (called from ccmd).  Keeps power on as long
 *    				 	as a "W" ccmd is received at least once every 5 sec.
 *    <VERSION 0.4>
 *    09-22-15 jmh:  Added code to ProcessIO() to track fan speed and auto-off if below
 *    					a pre-set limit.  ??? Needs a flag to push fan error to ACU ***
 *    <VERSION 0.3>
 *    05-17-15 jmh:  Added LOWRG, PEPM, and FANON to HIBRAM.  These GPIOs are saved just
 *    				  before hibernate, and restored on reset.  *** Need to validate before
 *    				  restore ***.
 *    <VERSION 0.2>
 *    04-04-15 jmh:  Added skeleton for CCMD I/O.  Just returns SW version for now.
 *    				  process_CCMD() is called from process_IO() and handles CCMDs.
 *    				  Will be organized as a state machine entity to process CCMDs without
 *    				  tying up CPU time.
 *    				 converted CCMD UART code to use a TX buffer:
 *    				  * added 100 chr TX buffer, head, tail pointers, and status reg
 *    				  * modified UART1 intr code to trap TX intrpt and process tx buffer
 *    				  * modified putchar1() to stroe to buffer instead of uart DR
 *    				  * added txstart1() to send 1st chr of tx buffer
 *    04-03-15 jmh:  Tested & tweaked blind_tune() and associated sub-Fns.
 *    				 Coded set and restore for HIB values (last pos, freq, antpos,
 *    				  antaccum, and antsel (V/H).
 *    				 old fansw now triggers blind_tune to ic7k fop.  CMDS are:
 *    				  ant up, dn, or blind tune.
 *    03-22-15 jmh:  Pulled all I/O fns and moved to io.c.  Added eeprom.c for
 *    				  EEPROM init and rd/wr Fns.  Tweaked pll_init() to follow
 *    				  datasheet instructions more closely (PLL was not initializing).
 *    				 Added AT CLI fn to perform an ant tune/cal for 10-80M.
 *    03-21-15 jmh:  Enabled PLL (baudclk and ADC run off of PIOSC).
 *					 CLI fns allow debug testing of all basic functions.
 *    03-14-15 jmh:  Added TSIP send/rcv fns for UART1
 *    03-11-15 jmh:  revamped timer periphs.  Timer1 added as IC for fanopr input
 *    01-01-15 jmh:  added motor stop code to adjust commutation count when using
 *    				  reverse-to-stop mode.
 *    10-21-14 jmh:  pwm is configured.  Drives RGB LED to flash a cyclic, "I'm alive"
 *    				  color pattern.
 *    10-19-14 jmh:  basic HIB control: on if HFON is active, off 10 sec after HFON = off
 *    				 MANTA and MANTB are echoed to ANTON and ANTDN outputs
 *    				 FANON is always on
 *    				 LED flashes "I'm alive"
 *    				 comparators are configured, C0 outputs on PF0, C1 does not output.
 *    10-12-14 jmh:  added HIB controls and power-off CLI function.
 *    10-01-14 jmh:  creation date
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    10-01-14 jmh:  creation date
 *
 *******************************************************************/

//-----------------------------------------------------------------------------
// main.c
//  Receives CLI entries and dispatches to the command line processor.  The SW
//	system controls the DUT power supply and communicates via a bit-banged SPI.
//  UART0 is used for user interface and data download at 115,200 baud
//	(with xon/xoff handshaking).
//
//  CLI is a simple maintenance/debug port with the following core commands:
//      VERS - interrogate SW version.
//		P    - Power off.
//		See "cmd_fn.c" for details
//
//  Interrupt Resource Map:
//		Timer0 int captures motor commutation pulses for counting.
//		Timer1 int captures the fan operate signal (allowing RPM measurement)
//      Timer2 int provides 1ms, count-down-from-N-and-halt application timers
//      UART0 is host CLI serial port (via the ICDI USB<->SERIAL circuit)
//      UART1 is RS-485 CCMD serial port (115200b)
//      UART2 is the ICOM CIV serial port
//
//  I/O Resource Map:
//      See "init.h"
//
//	Phase I SW: Basic functions:
//	1) Power control: System power is controlled by the HFON signal.  HFON active edge
//		will activate power through the HIB module.  System SW monitors HFON and signals
//		the HIB to deactivate power if HFON is off for more than 10 sec.
//	2) Basic antenna control: act as a simple repeater for the MANTA and MANTB inputs.
//		If possible, monitor Im and halt antenna when locked rotor is detected.
//		SPARE input (old fan switch) signals auto-tune (blind)
//	3) FANON is active whenever system power is on.
//		If possible, monitor temps and turn on fan when heatsink > ambient + threshold
//			if on and heatsink < Ta + Tthresh, start timer to turn off after 5 minutes
//
//	Phase II SW: Application functions:
//	CCMD processing: RS-485 commands operate the HFB functions
//		1) ANT TUNE (u/d/s/a/b), no param returns status
//		2) Fan (1/0), no param retrurns status
//		3) Relay control (u/v/h/6/a), no param retrurns status
//		4) temp read: returns raw Tj, Ta, and Ths values
//		5) Power off: forces power off cycle
//		6) Read LRU status
//		7) CIV telnet: allows CIV control strings to be sent/rcvd by remt host
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
// compile defines

#define MAIN_C
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <string.h>
#include "init.h"
#include "typedef.h"
#include "version.h"
#include "serial.h"
#include "cmd_fn.h"
#include "tiva_init.h"
#include "I2C0.h"
#include "adc.h"
#include "io.h"
#include "eeprom.h"
#include "ccmd.h"

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//  see init.h for main #defines
#define	MAX_REBUF	4		// max # of rebufs
#define	MAX_BARS	7		// max # of led bars
#define	GETS_INIT	0xff	// gets_tab() static initializer signal
#define DAC_LDAC 20			// dac spi defines
#define DAC_PWRUP 21
#define DAC_CLR 22

//-----------------------------------------------------------------------------
// Local Variables
//-----------------------------------------------------------------------------

// Processor I/O assignments
//bitbands
#define DUT_ON  (*(volatile uint32_t *)(0x40058000 + (0x04 * 4)))
#define DUT_OFF (*(volatile uint32_t *)(0x40058000 + (0x08 * 4)))
#define DUT_SCK (*(volatile uint32_t *)(0x40058000 + (0x10 * 4)))
#define DUT_D   (*(volatile uint32_t *)(0x40058000 + (0x20 * 4)))
#define DUT_Q   (*(volatile uint32_t *)(0x40058000 + (0x40 * 4)))
#define DUT_CS  (*(volatile uint32_t *)(0x40058000 + (0x80 * 4)))

//-----------------------------------------------------------------------------
// Global variables (extern conditionals are in init.h)
//-----------------------------------------------------------------------------
U16		ic7ktimer; 						// ic7k action timer
U16		uart2timer; 					// uart2 (CIV) protocol timer
U16		app_timer1ms;					// app timer
U16		xm_timer;						// xmodem timer
U16		antstop_timer;					// ant stop-wait timer
U16		ccmd_timer;						// ccmd timer
U16		fan_timer;						// fan speed sample timer
char	bchar;							// break character trap register - traps ESC ascii chars entered at terminal
char	swcmd;							// software command flag
S8		handshake;						// xon/xoff enable
S8		xoffsent;						// xoff sent
S32		antpos;							// antenna position tracking counter
S32		antaccum;						// antenna position accumulator (total steps traveled)
S8		mot_stop;						// motor stop mode (motor is in reverse to stop)

//-----------------------------------------------------------------------------
// Local variables in this file
//-----------------------------------------------------------------------------
U32		abaud;							// 0 = 115.2kb (the default)
U8		iplt0;							// timer0 ipl (initial program load) flag
S32		antmatch;						// antenna position match reg
U8		iplt2;							// timer2 ipl flag
U16		waittimer;						// gp wait timer
U16		hfon_timer;						// hf power wait timer
U16		debounce1_timer;				// debounce#1 timer
S8		err_led_stat;					// err led status
uint8_t		idx;
#define	MAXFIDX 16						// length of fan_oper buffer
uint32_t	fanopr_captim[MAXFIDX];		// fan_oper capture time holding buffer
U16		ipl;							// initial power on state
U8		hib_access;						// HIB intrpt lock-out flag
#define	HIB_APPL	0					// HIB is being accessed by application
#define	HIB_INTR	1					// HIB may be accessed by intrpt

//-----------------------------------------------------------------------------
// Local Prototypes
//-----------------------------------------------------------------------------

char *gets_tab(char *buf, char *save_buf[3], int n);

//*****************************************************************************
// main()
//  The main function runs a forever loop in which the main application operates.
//	Prior to the loop, Main performs system initialization, boot status
//	announcement, and main polling loop.  The loop also calls CLI capture/parse fns.
//	The CLI maintains and processes re-do buffers (4 total) that are accessed by the
//	TAB key.  Allows the last 4 valid command lines to be recalled and executed
//	(after TAB'ing to desired recall command, press ENTER to execute, or ESC to
//	clear command line).
//	Autobaud rate reset allows user to select alternate baudarates after reset:
//		115,200 baud is default.  A CR entered after reset at 57600, 38400,
//		19200, or 9600 baud will reset the system baud rate and prompt for user
//		acceptance.  Once accepted, the baud rate is frozen.  If rejected, baud rate
//		returns to 115200.  The first valid command at the default rate will also
//		freeze the baud rate.  Once frozen, the baud rate can not be changed until
//		system is reset.
//*****************************************************************************
int
main(void)
{
	volatile uint32_t ui32Loop;
//	uint32_t i;
    uint8_t bar_state = 0;			// indicates the current LED state (0-7)
//    uint8_t	tempi;					// tempi
    char	buf[80];				// command line buffer
    char	rebuf0[80];				// re-do buffer#1
    char	rebuf1[80];				// re-do buffer#2
    char	rebuf2[80];				// re-do buffer#3
    char	rebuf3[80];				// re-do buffer#4
    char	got_cmd = FALSE;		// first valid cmd flag (freezes baud rate)
    U8		argn;					// number of args
    char*	cmd_string;				// CLI processing ptr
    char*	args[ARG_MAX];			// ptr array into CLI args
    char*	rebufN[4];				// pointer array to re-do buffers
    U16		offset = 0;				// srecord offset register
    U16		cur_baud = 0;			// current baud rate

	antmatch = ANT_MATCH_DISABLE;							// disable match
    iplt0 = 1;												// init timer0
    iplt2 = 1;												// init timer1
    ipl = proc_init();										// initialize the processor I/O
    mot_stop = 0;											// init stop mode = off
    rebufN[0] = rebuf0;										// init CLI re-buf pointers
	rebufN[1] = rebuf1;
	rebufN[2] = rebuf2;
	rebufN[3] = rebuf3;
	while(iplt2);											// wait for timer to finish intialization
	if(!(ipl & IPL_HIBINIT)){								// if HIB not initialized...
		ipl |= hib_init(1);									// ...finish the HIB init
	}else{
		wait(600);											// else, pad a bit of delay for POR to settle..
	}
	I2C_Init();												// init I2C system
	get_fanrpm(1);											// init fan rpm measurement
	dispSWvers(); 											// display reset banner
	wait(10);												// a bit of delay..
	rebuf0[0] = '\0';										// clear cmd re-do buffers
	rebuf1[0] = '\0';
	rebuf2[0] = '\0';
	rebuf3[0] = '\0';
	bcmd_resp_init();										// init bcmd response buffer
	wait(10);												// a bit more delay..
	while(gotchr()) getchr();								// clear serial input in case there was some POR garbage
	gets_tab(buf, rebufN, GETS_INIT);						// initialize gets_tab()
	process_IO(IPL_CMD);									// init process_io
	process_CCMD(IPL_CMD);
	// pull HIBRAM storage into operating regs..
	antpos = antposhib;										// ..ant pos
	antaccum = antaccumhib;									// .. ant pos accum
	vuant_sel((U16)((last_antsel >> 8) & 0xff));			// ..restore VHF/UHF ant select
	hfant_sel((U16)(last_antsel & 0xff));					// ..restore HF/6M ant select
	sprintf(buf,"STAT: %08x",last_stat);					// debug display
	puts0(buf);
    GPIO_PORTD_DATA_R = (GPIO_PORTD_DATA_R & ~LOWRG) | (last_stat & LOWRG); // restore RF pwr range
    GPIO_PORTA_DATA_R = (GPIO_PORTA_DATA_R & ~FANON) | (last_stat & FANON); // restore fan status
    GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~PEPM) | (last_stat & PEPM);	// restore PEP status
	hib_access = HIB_INTR;									// enable intr access to HIB RAM
	swcmd = 0;												// init SW command
	// main loop
    while(swcmd != SW_ESC){
		putchar_b(XON);
		buf[0] = '\0';
		if(ipl & IPL_HIBERR) putss("HIBerr>");				// HIB err prompt
		else putss("hfb>");									// prompt
    	if(bar_state > MAX_BARS) bar_state = 0;
		cmd_string = gets_tab(buf, rebufN, 80); 			// get cmd line & save to re-do buf
		if(!got_cmd){										// if no valid commands since reset, look for baud rate change
			if(cur_baud != abaud){							// abaud is signal from gets_tab() that indicates a baud rate change
				if(set_baud(abaud)){						// try to set new baud rate
					puts0("");								// move to new line
					dispSWvers();							// display reset banner & prompt to AKN new baud rate
					while(gotchr()) getchr();				// clear out don't care characters
					putss("press <Enter> to accept baud rate change: ");
					while(!gotchr());						// wait for user input
					puts0("");								// move to new line
					if(getchr() == '\r'){					// if input = CR
						cur_baud = abaud;					// update current baud = new baud
						got_cmd = TRUE;						// freeze baud rate
					}else{
						set_baud(0);						// input was not a CR, return to default baud rate
						cur_baud = abaud = 0;
					}
				}else{
					abaud = cur_baud;						// new baud rate not valid, ignore & keep old rate
				}
			}else{
				got_cmd = TRUE;								// freeze baud rate (@115.2kb)
			}
		}
		argn = parse_args(cmd_string,args);					// parse cmd line
		if(x_cmdfn(argn, args, &offset)) got_cmd = TRUE;	// process cmd line, set got_cmd if cmd valid
    }
    return 0;
}

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// gets_tab puts serial input into buffer, UART0.
//-----------------------------------------------------------------------------
// Main loop for command line input.
// waits for a chr and puts into buf.  If 1st chr = \t, copy re-do buf into
//  cmdbuf and cycle to next re-do buf.  if more than n chrs input, nul term buf,
//	disp "line too long", and return.  if \n or \r, copy buf to save_buf & return
//  returns buf (pointer).
//	if n == 0xff, initialize statics and exit.
//
//	11/08/13: Modified to support 4 (MAX_REBUF) rolling cmd save buffers
//	11/15/13: Modified to support auto-baud detect on CR input
//		For the following, each bit chr shown is one bit time at 115200 baud (8.68056us).
//			s = start bit (0), p = stop bit (1), x = incorrect stop, i = idle (1), bits are ordered  lsb -> msb:
//	 the ascii code for CR = 10110000
//			At 115.2kb, CR = s10110000p = 0x0D
//
//			At 57.6 kb, CR = 00110011110000000011 (1/2 115.2kb)
//			@115.2, this is: s01100111ps00000001i = 0xE6, 0x80
//
//			At 38.4 kb, CR = 000111000111111000000000000111 (1/3 115.2kb)
//			@115.2, this is: s00111000p11111s00000000xxxiii = 0x1c, 0x00
//
//			At 19.2 kb, CR = 000000111111000000111111111111000000000000000000000000111111 (1/6 115.2kb)
//			@115.2, this is: s00000111piis00000111piiiiiiiis00000000xxxxxxxxxxxxxxxiiiiii = 0xE0, 0xE0, 0x00
//
//			At 9600 b,  CR = 000000000000111111111111000000000000111111111111111111111111000000000000000000000000000000000000000000000000111111111111 (1/12 115.2kb)
//			@115.2, this is: s00000000xxxiiiiiiiiiiiis00000000xxxiiiiiiiiiiiiiiiiiiiiiiiis00000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxiiiiiiiiiiii = 0x00, 0x00, 0x00
//
//		Thus, @ 57.6 kb, a CR = 0xE6 followed by 0x80
//			  @ 38.4 kb, a CR = 0x1C followed by 0x00
//			  @ 19.2 kb, a CR = 0xE0 followed by 0xE0 (plus a 0x00)
//			  @ 9600 b, a  CR = 0x00 followed by 0x00 (plus a 0x00)
//
//		NOTE: gets_tab is only used for command line input and thus should not
//		see non-ascii data under normal circumstances.

char *gets_tab(char *buf, char *save_buf[], int n)
{
	char	*cp;
	char	*sp;
	char	c;
	int		i = 0;
	static	U8   rebuf_num;
	static	U8	 last_chr;

//	if((rebuf_num >= MAX_REBUF) || (n == GETS_INIT)){ 		// n == 0xff is static initializer signal
	if(n == GETS_INIT){ // n == 0xff is static initializer signal
		rebuf_num = 0;										// init recall buffer pointer
		last_chr = 0xff;									// init to 0xff (not a valid baud select identifier chr)
		return buf;											// skip rest of Fn
	}
    cp = buf;
    sp = save_buf[rebuf_num];
    do{
        c = getch00();
        switch(c){
			case 0xE0:										// look for 19.2kb autoselect
				if(last_chr == 0xE0){
					abaud = 19200L;
					c = '\r';
				}
				break;

			case 0x00:										// look for 38.4kb or 9600b autoselect
				if(last_chr == 0x1C){
					abaud = 38400L;
					c = '\r';
				}else{
					if(last_chr == 0x00){
						abaud = 9600L;
						c = '\r';
					}
				}
				break;

			case 0x80:										// look for 57.6kb autoselect
				if(last_chr == 0xE6){
					abaud = 57600L;
					c = '\r';
				}
				break;

            case '\t':
				if(i != 0){									// if tab, cycle through saved cmd buffers
					do{
						i--;								// update count/point
						cp--;
						if((*cp >= ' ') && (*cp <= '~')){
							putchar0('\b');					// erase last chr if it was printable
							putchar0(' ');
							putchar0('\b');
						}
					}while(i != 0);
					cp = buf;								// just in case we got out of synch
				}
				//copy saved string up to first nul, \n, or \r
				if(--rebuf_num == 0xff){
					rebuf_num = MAX_REBUF - 1;
				}
				sp = save_buf[rebuf_num];
				while((*sp != '\0') && (*sp != '\r') && (*sp != '\n')){
					putdch(*sp);
					*cp++ = *sp++;
					i++;
				}
                break;

            case '\b':
            case 0x7f:
                if(i != 0){									// if bs & not start of line,
                    i--;									// update count/point
                    cp--;
                    if((*cp >= ' ') && (*cp <= '~')){
                        putchar0('\b');						// erase last chr if it was printable
                        putchar0(' ');
                        putchar0('\b');
                    }
                }
                break;

            case '\r':										// if cr, nul term buf & exit
            case '\n':										// if nl, nul term buf & exit
                i++;
                *cp++ = c;
                break;

            case ESC:										// if esc, nul buf & exit
                cp = buf;
                c = '\r';									// set escape condition
				i = 0;
                break;

            default:
                i++;
                *cp++ = c;									// put chr in buf
                putdch(c);									// no cntl chrs here
                break;
        }
		last_chr = c;										// set last chr
    } while((c != '\r') && (c != '\n') && (i < n));			// loop until c/r or l/f or buffer full
	if(i >= n){
		puts0("!! buffer overflow !!");
		*buf = '\0';										// abort line
	}else{
		puts0("");											// echo end of line to screen
		*cp = '\0';											// terminate command line
		if((*buf >= ' ') && (*buf <= '~')){					// if new buf not empty (ie, 1st chr = printable),
			strncpy(save_buf[rebuf_num], buf, n);			// copy new buf to save
			if(++rebuf_num >= MAX_REBUF) rebuf_num = 0;
		}
	}
    return buf;
}

//-----------------------------------------------------------------------------
// process_IO() processes system I/O
//-----------------------------------------------------------------------------
void process_IO(U8 flag){
#define	EGE_IDLE	0
#define EGE_DET		1
#define	MAX_RPM_ARRAY	4

			char buf[20];			// debug buff
	static	U8	gpio_edge;			// gpio edge detect reg
	static	U8	gpio_state;			// gpio edge state reg
	static	U8	manfl;				// manual trigger trap (does edge detect on man inputs)
	static	U32	rpm_ave[MAX_RPM_ARRAY];			// fan rpm average array
	static	U8	rpm_index;			// fan index
	static	U8	rpm_cycling;		// average matrix active
			U8	i;					// temp U8
	volatile U32	ii;				// temp U32
	static	U8	ledstat;			// LDG tuner led holding reg.

	// process IPL init
	if(flag == IPL_CMD){									// perform init/debug fns
		hfon_timer = PWR_WD_TIME;
		manfl = 0xff;
		gpio_state = EGE_IDLE;
		gpio_edge = ~GPIO_PORTD_DATA_R;
		mode_ic7k(IC7K_IPL);								// init CIV Fns
		stack_ic7k(CIV_AUXIPL);
		GPIO_PORTA_DATA_R &= ~FANON;						// set fan off
		get_fanrpm(1);										// init rpm sense
		for(i=0; i<MAX_RPM_ARRAY; i++){
			rpm_ave[i] = 0;
		}
		rpm_index = 0;
		rpm_cycling = 0;									// disable speed checks until ave array full
		fan_timer = 3000;									// set initial sample period
//		process_CCMD(IPL_CMD);								// process CCMD inputs
		Process_CIV(IPL_CMD);								// process CIV status
		ledstat = 0xff;										// force LED update
		return;
	}
	// process LDG tuner status LEDs
    if(GPIO_PORTE_DATA_R != ledstat){
    	ledstat = GPIO_PORTE_DATA_R;
    	buf[0] = 'T';
    	buf[1] = 'U';
    	buf[2] = '0' + ((ledstat & (TUN_RED|TUN_GRN)) >> 4);
    	buf[3] = '\r';
    	buf[4] = '\0';
    	putss1(buf);
    }
	// process power on/off status
	if(~GPIO_PORTD_DATA_R & NHFON){							// if HF is on, keep holding the WD timer (keep system on even if ACU is AWOL)
		hfon_timer = PWR_WD_TIME;
		if(!(GPIO_PORTA_DATA_R & FANON)){					// turn fan on if off
			get_fanrpm(1);									// init rpm sense
			GPIO_PORTA_DATA_R |= FANON;						// set fan on
		}
	}else{
		if((hfon_timer == 0) && !(GPIO_PORTB_DATA_R & WAKE)){ // if off timer && wake == 0, do off
			ii = (U32)((GPIO_PORTD_DATA_R & LOWRG) | (GPIO_PORTA_DATA_R & FANON) | (GPIO_PORTB_DATA_R & PEPM));
			wrwhib_ram(ii,&last_stat); // save GPIO status
			sprintf(buf,"STAT: %08x",last_stat);			// debug display
			puts0(buf);
			putss("Power-off..");
			GPIO_PORTA_DATA_R &= ~FANON;					// set fan off
			wait(10);										// give the UART time to finish
			ii = HIB_CTL_R;
			HIB_CTL_R |= HIB_CTL_HIBREQ;					// initiate hibernate
			wait(3000);										// delay abt 3 sec to give PS time to discharge
			putss("..failed.\nsw>");						// if we get here, it didn't work
		}
	}
	// process manual switch up/dn status
	i = (~GPIO_PORTD_DATA_R & (NMANTA | NMANTB)) >> 1;
	if(i != manfl){
		manfl = i;											// update edge trap
		switch(i){
		case MANOFF:										// turn off (if on)
			if(GPIO_PORTA_DATA_R & ANTON){
				set_ant(ANT_OFF);
				putss("ANT OFF\nsw>");
			}
			break;

		case MANUP:											// do up
			set_ant(ANT_UP);
			putss("ANT UP\nsw>");
			break;

		case MANDN:											// do dn
			set_ant(ANT_DN);
			putss("ANT DN\nsw>");
			break;

		default:											// error trap, do off
			set_ant(ANT_OFF);
			putss("ANT OFF\nsw>");
			break;
		}
	}
	// process manual switch blind tune status
	i = GPIO_PORTE_DATA_R;									// get port
	switch(gpio_state){
	case EGE_IDLE:
		if((i & NSPARE) != gpio_edge){
			debounce1_timer = 30;							// debounce 30 ms
			gpio_state = EGE_DET;							// set next state...
		}
		break;

	case EGE_DET:
		if((i & NSPARE) == gpio_edge){
			debounce1_timer = 0;
			gpio_state = EGE_IDLE;							// abort, return to idle.
		}
		if(!debounce1_timer){
			gpio_edge = i;									// update edge reg
			if(~i & NSPARE){								// if spare switch...
				tune_blind(0,TSWITCH);
				putss("blind tune\nsw>");					// debug
			}
			gpio_state = EGE_IDLE;							// abort, return to idle.
		}
		break;
	}
	// check fan speed for underspeed.  Shut off fan if < MIN_FANRPM for 2 sec
	if((GPIO_PORTA_DATA_R & FANON) && (fan_timer == 0)){
		rpm_ave[rpm_index++] = get_fanrpm(0);				// get fan rpm in timer units
		if(rpm_index >= MAX_RPM_ARRAY){
			rpm_index = 0;									// cycle index
			rpm_cycling = 1;								// enable average checking
		}
		if(rpm_cycling){
			for(i=0, ii=0; i<MAX_RPM_ARRAY; i++){			// calculate average
				ii += rpm_ave[i];
			}
			ii /= 4;
			if(ii < MIN_FANRPM){							// if below limit,
				GPIO_PORTA_DATA_R &= ~FANON;				// turn off fan
			}
		}
		fan_timer = 500;									// reset sample period
	}
	process_CCMD(IDLE_CMD);									// process CCMD inputs
	Process_CIV(IDLE_CMD);									// process CIV status
}

//-----------------------------------------------------------------------------
// wrwhib_ram() writes a word to the HIBRAM array
//-----------------------------------------------------------------------------
void wrwhib_ram(U32 data, volatile U32* addr){

	hib_access = HIB_APPL;									// lock out intr access
	while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
	*addr = data;											// write new data
	hib_access = HIB_INTR;									// enable intr access
}

//-----------------------------------------------------------------------------
// wrhib_ram() writes a databyte to the HIBRAM array using a byte address
//-----------------------------------------------------------------------------
void wrhib_ram(uint8_t data, uint8_t addr){
	uint8_t	i;							// temp
	volatile uint32_t* pii;				// Vu32 pointer
	uint32_t	dd = (uint32_t)data;	// temp data
	uint32_t	ee;						// temp data
	uint32_t	maskdd = 0x000000ff;	// mask

	pii = &HIB_DATA_R;										// get base pointer
	pii += addr >> 2;										// point to desired word addr
	ee = *pii;												// get existing data
	i = addr & 0x03;										// get byte addr
	while(i){												// align byte and mask
		dd <<= 8;
		maskdd <<= 8;
		i--;
	}
	ee &= ~maskdd;											// mask existing data
	ee |= dd;												// combine new daata
	hib_access = HIB_APPL;									// lock out intr access
	while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
	*pii = ee;												// write new data
	hib_access = HIB_INTR;									// enable intr access
}

//-----------------------------------------------------------------------------
// rdhib_ram() reads a databyte from the HIBRAM array using a byte address
//-----------------------------------------------------------------------------
uint8_t rdhib_ram(uint8_t addr){
	uint8_t	i;						// temp
	volatile uint32_t* pii;			// Vu32 pointer
	uint32_t	ee;					// temp data

	pii = &HIB_DATA_R;										// get base pointer
	pii += addr >> 2;										// point to desired word addr
	while(~HIB_CTL_R & HIB_CTL_WRC);						// pause until HIBRAM is ready
	ee = *pii;												// get existing data
	i = addr & 0x03;										// get byte addr
	while(i){												// align byte to uint8_t
		ee >>= 8;
		i--;
	}
	ee &= 0xff;
	return (uint8_t)ee;
}

//-----------------------------------------------------------------------------
// waitpio() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//	loops through process_IO during wait period.
//-----------------------------------------------------------------------------
void waitpio(U16 waitms){
//	U32	i;

//	i = 545 * (U32)waitms;
    waittimer = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer != 0) process_IO(IDLE_CMD);
}

//-----------------------------------------------------------------------------
// wait() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//-----------------------------------------------------------------------------
void wait(U16 waitms)
{
//	U32	i;

//	i = 545 * (U32)waitms;
    waittimer = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer != 0);
}

//-----------------------------------------------------------------------------
// wait2() does quick delay pace
//-----------------------------------------------------------------------------
void wait2(U16 waitms)
{
	U32	i;

	i = 10 * (U32)waitms;
    waittimer = waitms;
    for(;i!=0;i--);		// patch
//    while(waittimer != 0);
}

//-----------------------------------------------------------------------------
// wait_reg0() waits for (delay timer == 0) or (regptr* & clrmask == 0)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg0(volatile uint32_t *regptr, uint32_t clrmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & clrmask) != 0));
    if(waittimer == 0) timout = TRUE;
    return timout;
}

//-----------------------------------------------------------------------------
// wait_reg1() waits for (delay timer == 0) or (regptr* & setmask == setmask)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg1(volatile uint32_t *regptr, uint32_t setmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & setmask) != setmask));
    if(waittimer == 0) timout = TRUE;
    return timout;
}
//-----------------------------------------------------------------------------
// pwr_wd() resets power on timer
//-----------------------------------------------------------------------------
void pwr_wd(U8 c){

	if(c){
		hfon_timer = PWR_WD_TIME;			// reset 5 second timeout to power off
	}else{
		hfon_timer = 0;						// force power off
	}
	return;
}
//-----------------------------------------------------------------------------
// get_antpos() returns current ant pos value or re-initializes if cmd != 0
//-----------------------------------------------------------------------------
S32 get_antpos(U8 cmd){

	if(cmd){
		antpos = 0;
		antaccum = 0;
	    iplt0 = 1;							// re-init timer0
	}
	return antpos;
}

//-----------------------------------------------------------------------------
// set_antmatch() sets or returns current ant pos match value
//-----------------------------------------------------------------------------
S32 set_antmatch(S32 matchval){

	if(matchval != 0){
		antmatch = matchval;
	}
	return antmatch;
}

//-----------------------------------------------------------------------------
// get_antaccum() returns current ant accum value or re-initializes if cmd != 0
//-----------------------------------------------------------------------------
S32 get_antaccum(void){

	return antaccum;
}

//-----------------------------------------------------------------------------
// getipl() returns current ipl flags value
//-----------------------------------------------------------------------------
U16 getipl(void){

	return ipl;
}

//-----------------------------------------------------------------------------
// get_fanrpm() returns average of current fan RPM timer value taken from
//	timer buffer (fanopr_captim[]).
//	Average discards any values that cross the overflow boundary (this is
//	typically one per buffer).
//
//	Assuming 2 pulses per rev, the RPM is found from:
//	RPM = (30.0 * (float)SYSCLK) / (float)fanopr_captim(ave)
//-----------------------------------------------------------------------------
uint32_t get_fanrpm(U8 cmd){

	uint8_t		i;
	uint8_t		j;
	uint8_t		k;
	uint32_t	ii = 0;
	uint32_t	ji;
	uint32_t	ki;

	if(cmd){
		for(i=0; i<MAXFIDX; i++){
			fanopr_captim[i] = 0;
		}
	}else{
		TIMER1_IMR_R &= ~TIMER_IMR_CAEIM;							// disable capture interrupt
		if(idx > (MAXFIDX-1)){
			k = 0;
		}else{
			k = idx;
		}
		for(i=0, j=0; i<(MAXFIDX-1); i++){
			ji = fanopr_captim[k];
			if(k < (MAXFIDX - 1)){
				ki = fanopr_captim[k+1];
			}else{
				ki = fanopr_captim[0];
			}
			if(ki > ji){
				ii += ki - ji;
				j++;
			}
			if(++k > (MAXFIDX - 1)) k = 0;
		}
		TIMER1_IMR_R |= TIMER_IMR_CAEIM;							// enable capture interrupt
		ii /= (uint32_t)j;
	}
	return ii;
}

//-----------------------------------------------------------------------------
// Timer0_ISR
//-----------------------------------------------------------------------------
//
// Called when timer0A capture event is detected:
//	This event is from the commutation detector and signals a possible
//	 commutation event.  Due to the inherently noisy nature of the commutation
//	 process, this interrupt attempts to evaluate and reject noise pulses based
//	 on the time from last pulse.  For the BM5D motor, the estimated max
//	 frequency of valid commutation pulses is 3500Hz.  This ISR rejects any pulse
//	 that is less than 1/4 of 1/3500 sec in duration.
//	 for every valid RE pulse, the antpos register is incremented or decremented
//	 based on the status of the NANTDN GPIO (PORTA).
//   With the implementation of the reverse-to-stop motor control, the stop mode
//   must be taken into account when counting commutation pulses.  During stop,
//   the motor is reversed, but is still turning in the opposite direction.  Thus,
//   the count polarity determined by the combination of motor direction, and stop
//   status...if (dir ^ stop) == 0, polarity is (-), if (dir ^ stop) == 1, polarity
//   is (+).
//
//-----------------------------------------------------------------------------

void Timer0_ISR(void)
{
	static	U32	tlast_re;		// last timer, RE
	static	U32	tlast_fe;		// last timer, FE
	U32		captim;				// capture time holding reg

	TIMER0_ICR_R = TIMER_ICR_CAECINT;				// clear intr
	captim = TIMER0_TAR_R;							// grab time of edge
	TIMER0_TAILR_R = 0;								// clear timer
	if(iplt0){										// if flag is set, initialize for a new movement cycle
		tlast_re = captim;							// capture last RE
/*		TIMER0_CTL_R &= ~(TIMER_CTL_TAEN);			// disable timer
		TIMER0_CTL_R = (TIMER0_CTL_R & ~TIMER_CTL_TAEVENT_M) | TIMER_CTL_TAEVENT_NEG; // set FE for next
		TIMER0_CTL_R |= (TIMER_CTL_TAEN);			// enable timer*/
		iplt0 = 0;
		return;
	}
	if(GPIO_PORTB_DATA_R & T0P0){					// if RE...			(TIMER0_CTL_R & ~TIMER_CTL_TAEVENT_M){		// if FE
		if((captim - tlast_fe) > TMIN){				// if timing valid, accept
			tlast_re = captim;
/*			TIMER0_CTL_R &= ~(TIMER_CTL_TAEN);		// disable timer
			TIMER0_CTL_R |= TIMER_CTL_TAEVENT_NEG;	// set FE for next
			TIMER0_CTL_R |= (TIMER_CTL_TAEN);		// enable timer*/
			antaccum++;								// update cumulative counter
			if((GPIO_PORTA_DATA_R & NANTDN) ^ mot_stop){
				antpos--;							// NANTDN == 1 is dn
			}else{
				antpos++;							// NANTDN == 0 is up
			}
		}
	}else{											// else do FE
		if((captim - tlast_re) > TMIN){				// if timing valid, accept
			tlast_fe = captim;
/*			TIMER0_CTL_R &= ~(TIMER_CTL_TAEN);		// disable timer
			TIMER0_CTL_R &= ~TIMER_CTL_TAEVENT_M;	// set RE for next
			TIMER0_CTL_R |= (TIMER_CTL_TAEN);		// enable timer*/
		}
	}
	if(antmatch == antpos){							// if position == match,
		mot_stop = NANTDN;									// set stop flag (feeds timer int)
		GPIO_PORTA_DATA_R = GPIO_PORTA_DATA_R ^ NANTDN;		// reverse motor
		antstop_timer = STOP_TIME;							// set stop timer
		antmatch |= ANT_MATCH_DISABLE;						// disable match
	}
	if(!(~HIB_CTL_R & HIB_CTL_WRC) || !hib_access){	// skip HIBRAM if not ready
		antposhib = antpos;							// update HIBRAM storage
	}
}

//-----------------------------------------------------------------------------
// Timer1_ISR
//-----------------------------------------------------------------------------
//
// Called when timer1A capture event is detected:
//	This event is from the fan oper signal.  This signal toggles twice for each
//	fan revolution.  The timing from one edge to the next can be used to calc
//	the fan rotation speed.
//
//	RPM = 60 * timer_rate / (2N)
//
//		timer_rate = SYSCLK / PS
//		N = timer value (fanopr_captim)
//	Reduces to:
//	RPM = (30 * SYSCLK / PS) / fanopr_captim
//
//-----------------------------------------------------------------------------

void Timer1_ISR(void)
{

	if(idx >= MAXFIDX) idx = 0;
	fanopr_captim[idx] = TIMER1_TAR_R;			// grab time of edge
	idx += 1;
	TIMER1_ICR_R = TIMER_ICR_CAECINT;			// clear intr
}

//-----------------------------------------------------------------------------
// Timer2_ISR
//-----------------------------------------------------------------------------
//
// Called when timer2 A overflows (NORM mode):
//	intended to update app timers @ 1ms per lsb
//	also drives RGB "I'm alive" LED.  The LED transitions through the color
//	wheel in a way that can be modified by the #defines below. RATE, PERIOD,
//	and START values may be adjusted to taylor the color transitions,
//	transition rate, and cycle period.
//
//-----------------------------------------------------------------------------

void Timer2_ISR(void)
{
static	U16	prescale;				// prescales the ms rate to the LED update rate
static	U16	period_counter;			// counts the LED cycle period (ms)
static	S16	ired;					// PWM compare holding regs (RGB)
static	S16	iblu;
static	S16	igrn;
static	S16	deltar;					// delta DC holding regs (RGB)
static	S16	deltag;
static	S16	deltab;
static	U8	cycflag;				// cycle control flag
#define	PWM_RATE_RED	4			// delta duty cycle values (RGB) (this is added/subtracted to/fr the DCreg every 10ms)
#define	PWM_RATE_GRN	6
#define	PWM_RATE_BLU	8
#define	LED_PERIOD		3000		// sets length of LED cycle (ms)
#define	LED_GRN_STRT	500			// sets start of green sub-cycle (ms)\___ red starts at 0ms
#define	LED_GRN_FLG		0x01		// green cycle started bitmap
#define	LED_BLU_STRT	1000		// sets start of blue sub-cycle (ms) /
#define	LED_BLU_FLG		0x02		// blue cycle started bitmap

	GPIO_PORTD_DATA_R ^= PORTD_SPR5;		// toggle debug pin
	TIMER2_ICR_R = TIMER2_MIS_R;
	if((iplt2) || (++period_counter > LED_PERIOD)){	// if flag is set, perform ipl initialization
		prescale = 0;								// also, do this every LED cycle
		ired = PWM_ZERO - 1;
		igrn = PWM_ZERO - 1;
		iblu = PWM_ZERO - 1;
       	PWM1_2_CMPB_R = ired;				// set PWM compare regsiters (sets duty cycle)
       	PWM1_3_CMPA_R = iblu;
       	PWM1_3_CMPB_R = igrn;
		deltar = -PWM_RATE_RED;
		deltag = 0;
		deltab = 0;
		period_counter = 0;
		iplt2 = 0;
		cycflag = 0;
	}
    if(++prescale > SEC10MS){				// prescale sets PWM update period = 10ms
    	if((period_counter > LED_GRN_STRT) && !(cycflag & LED_GRN_FLG)){
    		deltag = -PWM_RATE_GRN;			// start green
    		cycflag |= LED_GRN_FLG;			// set cycle started GRN
    	}
    	if((period_counter > LED_BLU_STRT) && !(cycflag & LED_BLU_FLG)){
    		deltab = -PWM_RATE_BLU;			// start blue
    		cycflag |= LED_BLU_FLG;			// set cycle started BLU
    	}
    	ired += deltar;						// adjust the LED PWM values
    	igrn += deltag;
    	iblu += deltab;
    	if(ired < PWM_MAX){					// if red is max, start back to to zero
    		ired = PWM_MAX;
    		deltar = PWM_RATE_RED;
    	}
    	if(ired >= PWM_ZERO){				// if red is past zero, set to 0 and set delta to 0
    		ired = PWM_ZERO-1;
    		deltar = 0;
    	}
    	if(igrn < PWM_MAX){					// if grn is max, start back to to zero
    		igrn = PWM_MAX;
    		deltag = PWM_RATE_GRN;
    	}
    	if(igrn >= PWM_ZERO){				// if grn is past zero, set to 0 and set delta to 0
    		igrn = PWM_ZERO-1;
    		deltag = 0;
    	}
    	if(iblu < PWM_MAX){					// if blu is max, start back to to zero
    		iblu = PWM_MAX;
    		deltab = PWM_RATE_BLU;
    	}
    	if(iblu >= PWM_ZERO){				// if blu is past zero, set to 0 and set delta to 0
    		iblu = PWM_ZERO-1;
    		deltab = 0;
    	}
       	PWM1_2_CMPB_R = ired;				// set PWM compare regsiters (sets duty cycle)
       	PWM1_3_CMPA_R = igrn;
       	PWM1_3_CMPB_R = iblu;
        prescale = 0;
    }
    if (ic7ktimer != 0){					// update radio timer
    	ic7ktimer--;
    }
    if (uart2timer != 0){					// update CIV timer
    	uart2timer--;
    }
    if (app_timer1ms != 0){					// update app timer
        app_timer1ms--;
    }
    if (waittimer != 0){					// update wait timer
        waittimer--;
    }
    if (xm_timer != 0){						// update xmodem timer
        xm_timer--;
    }
    if (hfon_timer != 0){					// update hfon timer
        hfon_timer--;
    }
    if (debounce1_timer != 0){				// update debounce#1 timer
    	debounce1_timer--;
    }
    if (ccmd_timer != 0){					// update CCMD timer
    	ccmd_timer--;
    }
    if (fan_timer != 0){					// update fan speed sample timer
    	fan_timer--;
    }
    if (antstop_timer != 0){				// ant stop-wait timer
    	if(--antstop_timer == 0){			// when timer hits zero,
    		GPIO_PORTA_DATA_R &= ~ANTON;	// turn off motor
    		mot_stop = 0;					// clear stop flag (only happens once per halt)
    	}
    }
	GPIO_PORTD_DATA_R ^= PORTD_SPR5;		// toggle debug pin
}
//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------

